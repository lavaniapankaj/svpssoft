<?php

return [

    'myloader' => env('APP_URL') . '/public/images/loader3.gif',
    'mylogo' => env('APP_URL') . '/public/images/logo_svps_chirawa.png',
    'mysignature' => env('APP_URL') . '/public/admin/images/principle_signature.png',

    'admin' => env('APP_URL') . '/public/images/Admin_tps.jpg',
    'fee' => env('APP_URL') . '/public/images/fee_tps.jpg',
    'marks' => env('APP_URL') . '/public/images/marks_tps.jpg',
    'student' => env('APP_URL') . '/public/images/student_tps.jpg',
    'inventory' => env('APP_URL') . '/public/images/stationary.png',

    'blank' => env('APP_URL') . '/public/images/photo.jpg',
    'favIcon' => env('APP_URL') . '/public/images/android-chrome-192x192.png',


];
