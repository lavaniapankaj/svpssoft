<?php $__env->startSection('sub-content'); ?>
    <div class="container">
        <?php if(Session::has('success')): ?>
            <?php $__env->startSection('scripts'); ?>
                <script>
                    swal("Good job!", "<?php echo e(Session::get('success')); ?>", "success").then(() => {
                        location.reload();
                    });
                </script>
            <?php $__env->stopSection(); ?>
        <?php endif; ?>

        <?php if(Session::has('error')): ?>
            <?php $__env->startSection('scripts'); ?>
                <script>
                    swal("Oops...", "<?php echo e(Session::get('error')); ?>", "error");
                </script>
            <?php $__env->stopSection(); ?>
        <?php endif; ?>
        <div class="row justify-content-center">
            <div class="col-md-14">
                <div class="card">
                    <div class="card-header">
                        <?php echo e('Fee Entry'); ?>


                    </div>
                    <div class="card-body">
                        <a href="<?php echo e(route('fee.fee-entry.academic')); ?>" class="btn btn-sm btn-primary">Academic Fee Entry</a>
                        <a href="<?php echo e(route('fee.fee-entry.transport')); ?>" class="btn btn-sm btn-primary">Transport Fee Entry</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('fee.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\svps-project\resources\views/fee/fee_entry/index.blade.php ENDPATH**/ ?>