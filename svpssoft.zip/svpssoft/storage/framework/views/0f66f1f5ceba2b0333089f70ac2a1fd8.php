<?php $__env->startSection('sub-content'); ?>
    <div class="container">

        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">
                        <?php echo e('SMS Panel'); ?>

                        <a href="<?php echo e(route('admin.sms-panel.index')); ?>" class="btn btn-warning btn-sm"
                            style="float: right;">Back</a>

                    </div>
                    <div class="card-body">
                        <form id="date-form">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="form-group col-md-6">
                                    <label for="class_id" class="mt-2">Class <span class="text-danger">*</span></label>

                                    <select name="class" id="class_id"
                                        class="form-control <?php $__errorArgs = ['class'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                        <option value="">Select Class</option>
                                        <?php if(count($classes) > 0): ?>
                                            <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($key); ?>"
                                                    <?php echo e(request()->get('class_id') == $key ? 'selected' : ''); ?>>
                                                    <?php echo e($class); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php else: ?>
                                            <option value="">No Class Found</option>
                                        <?php endif; ?>
                                    </select>
                                    <?php $__errorArgs = ['class'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback form-invalid fw-bold"
                                            role="alert"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                </div>


                                <div class="form-group col-md-6">
                                    <label for="section_id" class="mt-2">Section <span
                                            class="text-danger">*</span></label>
                                    <input type="hidden" id="initialSectionId"
                                        value="<?php echo e(request()->get('section_id') ?? ''); ?>">
                                    <select name="section" id="section_id"
                                        class="form-control <?php $__errorArgs = ['section'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                        <option value="">Select Section</option>

                                    </select>
                                    <?php $__errorArgs = ['section'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback form-invalid fw-bold"
                                            role="alert"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="row">
                                <div class="form-group col-md-12">
                                    <label for="floatingTextarea2">Message</label>
                                    <textarea class="form-control <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="message" placeholder="Enter Message"
                                        id="floatingTextarea2" style="height: 100px" required></textarea>
                                </div>
                                <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback form-invalid fw-bold"
                                        role="alert"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="mt-3">
                                <button type="button" id="show-details" class="btn btn-primary">
                                    Show Details</button><span><img src="<?php echo e(config('myconfig.myloader')); ?>" alt="Loading..."
                                        class="loader" id="loader" style="display:none; width:10%;"></span>
                            </div>

                        </form>

                        <div id="std-container" class="mt-4">
                            <form action="" id="std-form">
                                <table class="table table-responsible">
                                    <input type="hidden" name="current_session" value='' id="current_session">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th>Name</th>
                                                <th>Mobile Number</th>
                                                <th>Select</th>
                                            </tr>
                                        </thead>
                                        <tbody>

                                        </tbody>
                                    </table>
                                    <div class="mt-3">
                                        <button type="submit" id="send-sms" class="btn btn-primary">Send Message</button>
                                    </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('admin-scripts'); ?>
    <script>
        $(document).ready(function() {
           function fetchSections(classIds) {
                const sectionId = $('#section_id');
                loader.show();
                let allSectionIds = [];
                $.ajax({
                    url: siteUrl + '/sections',
                    type: 'GET',
                    dataType: 'JSON',
                    data: {
                        class_id: classIds
                    },
                    success: function(data) {
                        sectionId.empty();
                        $.each(data.data, function(id, name) {
                             allSectionIds.push(id);

                        });
                        sectionId.append('<option value="' + allSectionIds.join(',') +

                                '" selected>All Section</option>');

                        $.each(data.data, function(id, name) {
                                sectionId.append('<option value="' + id + '">' + name + '</option>');
                        });
                    },
                    complete: function() {
                        loader.hide();
                    },
                    error: function(data) {
                            console.error('Error fetching sections:', data.responseJSON ? data.responseJSON.message : 'Unknown error');
                    }

                });

            }
            $('#class_id').change(function () {
                fetchSections($(this).val());
            });
            $('#std-form').hide();
            $('#show-details').on('click', function() {
                const classId = $('#class_id').val();
                const sectionId = $('#section_id').val();
                const sessionId = $('#current_session').val();
                loader.show();
                if (classId && sectionId && sessionId) {
                    $('#std-form').show();
                    $.ajax({
                        url: '<?php echo e(route('stdNameFather.get')); ?>',
                        type: 'GET',
                        data: {
                            class_id: classId,
                            section_id: sectionId,
                            session_id: sessionId,
                        },
                        success: function(students) {
                            let stdHtml = '';
                            $.each(students, function(index, std) {

                                stdHtml += `<tr>
                            <td>
                                ${std.student_name}
                            </td>
                            <td>${std.f_mobile ?? ''}</td>
                            <td>
                                <input type="checkbox" name="status" value="1" class="status-checkbox" data-index="${index}" checked>
                            </td>
                            </tr>`;
                            });

                            $('#std-container table tbody').html(stdHtml);
                        },
                        complete: function() {

                            loader.hide();
                        },
                        error: function(xhr) {
                            console.error(xhr.responseText);
                        }
                    });

                }
            });
            $('#session_id, #class_id').change(function() {
                $('#std-form').hide();
            });
            $('#sms-send').click(function() {
                // Show a confirmation message
                Swal.fire({
                    title: 'Send SMS',
                    text: 'Are you sure you want to send SMS to the selected students?',
                    icon: 'question',
                    showCancelButton: true,
                    confirmButtonText: 'Yes, send SMS',
                    cancelButtonText: 'No, cancel',
                }).then((result) => {
                    if (result.isConfirmed) {
                        // Call the API to send the SMS
                        // Replace the following URL with the actual API endpoint
                        $.ajax({
                            url: '/api/send-sms',
                            type: 'POST',
                            data: {
                                // Collect the necessary data for sending the SMS, such as student details
                            },
                            success: function(response) {
                                // Show a success message
                                Swal.fire({
                                    title: 'SMS Sent',
                                    text: 'SMS has been sent to the selected students.',
                                    icon: 'success',
                                });
                            },
                            error: function(xhr, status, error) {
                                // Show an error message
                                Swal.fire({
                                    title: 'Error',
                                    text: 'Failed to send SMS. Please try again later.',
                                    icon: 'error',
                                });
                            }
                        });
                    }
                });
            });

        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/webcalht/public_html/svpssoft/resources/views/admin/smspanel/index.blade.php ENDPATH**/ ?>