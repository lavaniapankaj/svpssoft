<?php $__env->startSection('sub-content'); ?>
    <div class="container">
        <?php if(Session::has('success')): ?>
            <?php $__env->startSection('scripts'); ?>
                <script>
                    swal("Good job!", "<?php echo e(Session::get('success')); ?>", "success").then(() => {
                        $('#std-form').hide();
                        location.reload();
                    });
                </script>
            <?php $__env->stopSection(); ?>
        <?php endif; ?>

        <?php if(Session::has('error')): ?>
            <?php $__env->startSection('scripts'); ?>
                <script>
                    swal("Oops...", "<?php echo e(Session::get('error')); ?>", "error");
                </script>
            <?php $__env->stopSection(); ?>
        <?php endif; ?>
        <div class="row justify-content-center">
            <div class="col-md-14">
                <div class="card">
                    <div class="card-header">
                        <?php echo e('Student Details Class Wise'); ?>

                        <a href="<?php echo e(route('student.st-report.index')); ?>" class="btn btn-warning btn-sm"
                            style="float: right;">Back</a>

                    </div>
                    <div class="card-body">
                        <form id="class-section-form" method="GET">

                            <div class="row">
                                <div class="form-group col-md-6">
                                    <label for="class_id" class="mt-2">Class <span class="text-danger">*</span></label>
                                    <input type="hidden" id="initialClassId"
                                        value="<?php echo e(old('initialClassId', request()->get('class_id') !== null ? request()->get('class_id') : '')); ?>">
                                    <select name="class" id="class_id"
                                        class="form-control <?php $__errorArgs = ['class'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                        <option value="">Select Class</option>
                                    </select>
                                    <?php $__errorArgs = ['class'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback form-invalid fw-bold"
                                            role="alert"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    <img src="<?php echo e(config('myconfig.myloader')); ?>" alt="Loading..." class="loader"
                                        id="loader" style="display:none; width:10%;">
                                </div>


                                <div class="form-group col-md-6">
                                    <label for="section_id" class="mt-2">Section <span
                                            class="text-danger">*</span></label>
                                    <input type="hidden" id="initialSectionId"
                                        value="<?php echo e(old('initialSectionId', request()->get('section_id') !== null ? request()->get('section_id') : '')); ?>">
                                    <select name="section" id="section_id"
                                        class="form-control <?php $__errorArgs = ['section'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                        <option value="">Select Section</option>

                                    </select>
                                    <input type="hidden" name="current_session" value='' id="current_session">
                                    <?php $__errorArgs = ['section'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback form-invalid fw-bold"
                                            role="alert"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                            </div>

                            <div class="mt-3">
                                <button type="button" id="show-report" class="btn btn-primary"> Show Details</button>
                                <span class="text-danger fw-bold" id="no-data"></span>
                            </div>

                        </form>
                        <div class="row table mt-2" id="report-table">
                            <div class="table-responsive" id="st-table">

                                <table id="report-excel" class="table table-striped table-bordered">
                                    <thead>

                                        <tr>
                                            <th>Rollno.</th>
                                            <th>Class</th>
                                            <th>Section</th>
                                            <th>Admission Date</th>
                                            <th>SRNO</th>
                                            <th>Name</th>
                                            <th>Father's Name</th>
                                            <th>Mother's Name</th>
                                            <th>Grand Father's Name</th>
                                            <th>DOB</th>
                                            <th>Address</th>
                                            <th>Contact 1</th>
                                            <th>Contact 2</th>
                                            <th>Gender</th>
                                            <th>Religion</th>
                                            <th>Category</th>
                                        </tr>
                                    </thead>
                                    <tbody>


                                    </tbody>

                                </table>
                            </div>
                            <div id="std-pagination"></div>
                            <button id="download-csv" type="button"
                                class="btn btn-primary mt-2 col-md-3 d-grid gap-2 col-6 mx-auto">Download Excel</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('std-scripts'); ?>
    <script>
        var initialClassId =
            '<?php echo e(old('initialClassId', request()->get('class_id') !== null ? request()->get('class_id') : '')); ?>';
        var initialSectionId =
            '<?php echo e(old('initialSectionId', request()->get('section_id') !== null ? request()->get('section_id') : '')); ?>';
        getClassSection(initialClassId, initialSectionId);


        $(document).ready(function() {
            var loader = $('#loader');
            var reportTable = $('#report-table');
            var paginationContainer = $('#std-pagination');
            reportTable.hide();
            $('#no-data').hide();
            $('#class-section-form').validate({
                rules: {
                    class: {
                        required: true,
                    },
                    section: {
                        required: true,
                    },
                },
                messages: {
                    class: {
                        required: "Please select a class.",
                    },
                    section: {
                        required: "Please select a section.",
                    },
                },
            });

            function stdDetails(page) {
                var classId = $('#class_id').val();
                var sectionId = $('#section_id').val();
                var sessionId = $('#current_session').val();
                if (classId && sectionId && sessionId) {
                    reportTable.show();
                    loader.show();
                    $.ajax({
                        url: '<?php echo e(route('stdNameFather.get')); ?>',
                        type: 'GET',
                        dataType: 'JSON',
                        data: {
                            class_id: classId,
                            section_id: sectionId,
                            session_id: sessionId,
                            page: page,
                        },
                        success: function(students) {
                            let stdHtml = '';
                            if (students.data.length > 0) {
                                let admissionDatePromises = students.data.map(student => {
                                    return admissionDateGet(student.srno).then(
                                        admissionDate => {
                                            return `<tr>
                                                        <td>${student.rollno ?? ''}</td>
                                                        <td>${student.class_name ?? ''}</td>
                                                        <td>${student.section_name ?? ''}</td>
                                                        <td>${admissionDate || student.admission_date || ''}</td>
                                                        <td>${student.srno ?? ''}</td>
                                                        <td>${student.student_name ?? ''}</td>
                                                        <td>${student.f_name ?? ''}</td>
                                                        <td>${student.m_name ?? ''}</td>
                                                        <td>${student.g_f_name ?? ''}</td>
                                                        <td>${student.dob ?? ''}</td>
                                                        <td>${student.address ?? ''}</td>
                                                        <td>${student.f_mobile ?? ''}</td>
                                                        <td>${student.m_mobile ?? ''}</td>
                                                        <td>${(student.gender == 1 ? 'Male' : (student.gender == 2 ? 'Female' : (student.gender == 3 ? "Other's" : ''))) ?? ''}</td>
                                                        <td>${(student.religion == 1 ? 'Hindu' : (student.religion == 2 ? 'Muslim' : (student.religion == 3 ? 'Christian' : 'Sikh'))) ?? ''}</td>
                                                        <td>${(student.category == 1 ? 'General' : (student.category == 2 ? 'OBC' : (student.category == 3 ? 'SC' : (student.category == 4 ? 'ST' : 'BC')))) ?? ''}</td>
                                                    </tr>`;
                                        });
                                });

                                // Wait for all admission dates to be fetched
                                Promise.all(admissionDatePromises).then(rows => {
                                    stdHtml = rows.join('');
                                    $('#st-table table tbody').html(stdHtml);
                                    updatePaginationControls(students);
                                });
                            } else {
                                stdHtml = `<tr><td colspan="16">No Student Found</td></tr>`;
                                $('#st-table table tbody').html(stdHtml);
                            }
                        },
                        complete: function() {
                            loader.hide();
                        },
                        error: function(xhr) {
                            alert(
                                'An error occurred while fetching the student data. Please try again.'
                            );
                            console.error(xhr.responseText);
                        }
                    });
                }
            }
            $('#show-report').click(function() {
                if ($('#class-section-form').valid()) {
                    let page = 1;
                    stdDetails(page);
                }
            });

            function getExcelReport(p = 1) {

                let classId = $('#class_id').val();
                let sectionId = $('#section_id').val();
                let sessionId = $('#current_session').val();
                let page = p;

                const exportUrl = "<?php echo e(route('student.student-report-class-wise-excel')); ?>?class_id=" +
                classId + "&section_id=" + sectionId + "&session_id=" + sessionId + "&page=" + page;
                window.location.href = exportUrl;

            }
            let currentPage = 1;
            $(document).on('click', '#std-pagination .page-link', function() {
                currentPage = $(this).data('page');
            });
            $('#download-csv').on('click', function() {
                getExcelReport(currentPage);
            });



        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('student.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\svps-project\resources\views/student/std_report/index.blade.php ENDPATH**/ ?>