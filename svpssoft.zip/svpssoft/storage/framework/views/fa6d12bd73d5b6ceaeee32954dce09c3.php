<?php $__env->startSection('styles'); ?>
    
<?php $__env->stopSection(); ?>
<?php $__env->startSection('sub-content'); ?>
    <div class="container">

        <div class="row justify-content-center">
            <div class="col-md-10">
                <div class="card">
                    <div class="card-header"><?php echo e(__('Print Fee Slip')); ?>

                        <a class="btn btn-warning btn-sm" style="float: right;" onclick="history.back()">Back</a>
                    </div>

                    <div class="card-body">
                        <div class="row" id="tables">
                            <!-- Left Receipt -->
                            <div class="col-md-6 mb-4">
                                <div class="card shadow-sm">
                                    <div class="card-body">
                                        <div class="text-center mb-3">
                                            <h4 class="mb-0">St. Vivekanand <?php echo e($school); ?></h4>
                                            <p class="small mb-0">(Managed by Helping Hands Society (Regd.))</p>
                                            <p class="small mb-0">(An English Medium Upper Primary School)</p>
                                            <p class="small mb-0">Near Kabir Teela, Chirawa, JJN (Raj.)</p>
                                            <p class="small mb-0">Ph. 01596 - 220877, 9829059133, 9414080877</p>
                                            <p class="small mb-0">Email: svpscrw@yahoo.com, www.svpschirawa.com</p>
                                        </div>
                                        <div class="row mb-3">
                                            <div class="col-6">
                                                <p class="mb-0"><strong>Receipt No.:</strong> <?php echo e($recp_no); ?></p>
                                            </div>
                                            <div class="col-6 text-end">
                                                <p class="mb-0"><strong>Date:</strong> <?php echo e($date); ?></p>
                                            </div>
                                        </div>

                                        <p class="mb-3">
                                            From <strong><?php echo e($name); ?></strong> <?php echo e($gender == 1 ? 'S/o' : 'D/o'); ?> <strong>SH. <?php echo e($father_name); ?></strong> Class <strong><?php echo e($class); ?></strong>
                                            Class Section <strong><?php echo e($section); ?></strong> Received with thanks of a sum of Rs. <strong><?php echo e($total); ?>/-</strong>
                                            (Rupees <strong><?php echo e($wordstotal); ?> only</strong>) on account of <?php echo e($fee_of); ?> for session <strong><?php echo e($session); ?></strong>
                                        </p>

                                        <div class="text-end mt-4">
                                            <p class="mb-0">(Authorised Signatory)</p>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- Right Receipt (Duplicate) -->
                            <div class="col-md-6 mb-4">
                                <div class="card shadow-sm">
                                    <div class="card-body">
                                        <div class="text-center mb-3">
                                            <h4 class="mb-0">St. Vivekanand <?php echo e($school); ?></h4>
                                            <p class="small mb-0">(Managed by Helping Hands Society (Regd.))</p>
                                            <p class="small mb-0">(An English Medium Upper Primary School)</p>
                                            <p class="small mb-0">Near Kabir Teela, Chirawa, JJN (Raj.)</p>
                                            <p class="small mb-0">Ph. 01596 - 220877, 9829059133, 9414080877</p>
                                            <p class="small mb-0">Email: svpscrw@yahoo.com, www.svpschirawa.com</p>
                                        </div>

                                        <div class="row mb-3">
                                            <div class="col-6">
                                                <p class="mb-0"><strong>Receipt No.:</strong> <?php echo e($recp_no); ?></p>
                                            </div>
                                            <div class="col-6 text-end">
                                                <p class="mb-0"><strong>Date:</strong> <?php echo e($date); ?></p>
                                            </div>
                                        </div>

                                        <p class="mb-3">
                                            From <strong><?php echo e($name); ?></strong> <?php echo e($gender == 1 ? 'S/o' : 'D/o'); ?> <strong>SH. <?php echo e($father_name); ?></strong> Class <strong><?php echo e($class); ?></strong>
                                            Class Section <strong><?php echo e($section); ?></strong> Received with thanks of a sum of Rs. <strong><?php echo e($total); ?>/-</strong>
                                            (Rupees <strong><?php echo e($wordstotal); ?> only</strong>) on account of <?php echo e($fee_of); ?> for session <strong><?php echo e($session); ?></strong>
                                        </p>

                                        <div class="text-end mt-4">
                                            <p class="mb-0">(Authorised Signatory)</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="mt-3">
                            <button type="button" id="print-receipt" class="btn btn-primary print-receipt">Print</button>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('fee-scripts'); ?>
    <script>
        $(document).ready(function() {
            $('.print-receipt').click(function() {
                $('#tables').print();
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('fee.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\svps-project\resources\views/fee/fee_entry/print_fee_slip.blade.php ENDPATH**/ ?>