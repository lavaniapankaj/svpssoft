<?php $__env->startSection('sub-content'); ?>
    <div class="container">

        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header"><?php echo e(__('Student Report (Transport/ without Transport)')); ?>

                        <a href="<?php echo e(route('admin.reports')); ?>" class="btn btn-warning btn-sm" style="float: right;">Back</a>
                    </div>

                    <div class="card-body">
                        <form action="" method="get" id="class-form">
                            <div class="row mt-2">
                                <div class="form-group col-md-6">
                                    <label for="class_id" class="mt-2">Class <span class="text-danger">*</span></label>
                                    <input type="hidden" name="current_session" value='' id="current_session">
                                    <input type="hidden" id="initialClassId" name="initialClassId"
                                        value="<?php echo e(old('initialClassId', request()->get('class_id') !== null ? request()->get('class_id') : '')); ?>">
                                    <select name="class_id" id="class_id"
                                        class="form-control mx-1 <?php $__errorArgs = ['class_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                        <option value="">All Class</option>
                                    </select>
                                    <?php $__errorArgs = ['class_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback form-invalid fw-bold" role="alert">
                                            <?php echo e($message); ?>

                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    <img src="<?php echo e(config('myconfig.myloader')); ?>" alt="Loading..." class="loader"
                                        id="loader" style="display:none; width:10%;">
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="section_id" class="mt-2">Section <span
                                            class="text-danger">*</span></label>
                                    <select name="section_id" id="section_id" class="form-control mx-1" required>
                                        <option value="">All Sections</option>
                                    </select>
                                    <span class="invalid-feedback form-invalid fw-bold" role="alert"></span>

                                    <img src="<?php echo e(config('myconfig.myloader')); ?>" alt="Loading..." class="loader"
                                        id="loader" style="display:none; width:10%;">
                                </div>

                            </div>
                            <div class="row">
                                <div class="form-group col-md-6">
                                    <label for="transport" class="mt-2">Transport<span class="text-danger">*</span></label>
                                    <select name="transport" id="transport" class="form-control mx-1" required>
                                        <option value="0,1">All</option>
                                        <option value="1">Transport Occupied</option>
                                        <option value="0">Transport not Occupied</option>
                                    </select>
                                    <span class="invalid-feedback form-invalid fw-bold" role="alert"></span>
                                </div>
                            </div>

                            <div class="mt-3">
                                <button class="btn btn-primary" type="button" id="show-report">Show Report</button>
                            </div>
                        </form>


                        <div class="super-div1 mt-4">
                            <table class="table table-sm">
                                <thead>
                                    <tr>
                                        <th>R.N.</th>
                                        <th>REGNO</th>
                                        <th>Class</th>
                                        <th>Section</th>
                                        <th>Name</th>
                                        <th>Father's Name</th>
                                        <th>DOB</th>
                                        <th>Address</th>
                                        <th>Mobile No.</th>
                                    </tr>
                                </thead>
                                <tbody id="report-body1">
                                </tbody>
                            </table>
                            <div id="std-pagination"></div>
                            <div class="export-div">
                                <button type="button" class="btn btn-info" id="export-button1">Export</button>
                            </div>
                        </div>

                    </div>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('admin-scripts'); ?>
    <script>
        $(document).ready(function() {
            getClassDropDownWithAll();

            $('.super-div1').hide();

            function getReport(page = 1) {
                let sessionId = $('#current_session').val();
                let classId = $('#class_id').val();
                let sectionId = $('#section_id').val();
                let transportId = $('#transport').val();
                if ($('#class-form').valid()) {
                    $('.super-div1').show();
                    $.ajax({
                        url: '<?php echo e(route('admin.reports.reportTransportWise')); ?>',
                        type: 'GET',
                        dataType: 'JSON',
                        data: {
                            session_id: sessionId,
                            class: classId,
                            section: sectionId,
                            transport: transportId,
                            page: page

                        },
                        success: function(response) {
                            let tableHtml = '';
                            $.each(response.data.data, function(index, studentData) {
                                tableHtml += `
                                        <tr>
                                            <td>${studentData.rollno}</td>
                                            <td>${studentData.srno}</td>
                                            <td>${studentData.class_name}</td>
                                            <td>${studentData.section_name}</td>
                                            <td>${studentData.student_name}</td>
                                            <td>${studentData.f_name}</td>
                                            <td>${studentData.dob}</td>
                                            <td>${studentData.address}</td>
                                            <td>${studentData.student_mobile}</td>
                                        </tr>`;

                            });
                            $('#report-body1').html(tableHtml);
                            updatePaginationControls(response.data);
                        },
                        complete: function() {

                            loader.hide();
                        },
                        error: function(data, xhr) {
                            var message = data.responseJSON.message;
                            $('.cdate-error').hide().html('');
                            if (message.date) {
                                $('.cdate-error').show().html(message.date);
                            }
                            console.log(xhr);

                        },
                    });
                }
            }



            $('#show-report').click(function() {
                getReport();

            });

            $('#class_id, #transport, #section_id').change(function() {
                $('.super-div1').hide();

            });

            $(document).on('click', '#std-pagination .page-link', function(e) {
                e.preventDefault();
                let page = $(this).data('page');
                getReport(page);
            });

            $('#export-button1').on('click', function() {
                const session = $('#current_session').val();
                const classId = $('#class_id').val();
                const sectionId = $('#section_id').val();
                const transportId = $('#transport').val();

                const exportUrl = "<?php echo e(route('admin.reports.exportReportByTransportWise')); ?>?session_id=" +
                    session +
                    "&class=" + classId + "&section=" + sectionId + "&transport=" + transportId;
                window.location.href = exportUrl;
            });



        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/webcalht/public_html/svpssoft/resources/views/admin/reports/transport_details_report.blade.php ENDPATH**/ ?>