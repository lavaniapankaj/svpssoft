<?php $__env->startSection('sub-content'); ?>
    <div class="container">

        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header"><?php echo e(__('New Admission Report By Religion')); ?>

                        <a href="<?php echo e(route('admin.reports.newAdmissionReport')); ?>" class="btn btn-warning btn-sm"
                            style="float: right;">Back</a>
                    </div>

                    <div class="card-body">

                        <div class="row mt-2">
                            <div class="form-group col-md-6">
                                <label for="session_id" class="mt-2">Session <span class="text-danger">*</span></label>
                                <input type="hidden" id="initialSesstionId"
                                    value="<?php echo e(old('session_id', isset($data) ? $data->id : '')); ?>">
                                <select name="session_id" id="session_id"
                                    class="form-control <?php $__errorArgs = ['session_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                    <option value="">Select session</option>
                                </select>
                                <?php $__errorArgs = ['session_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback form-invalid fw-bold" role="alert">
                                        <?php echo e($message); ?>

                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <img src="<?php echo e(config('myconfig.myloader')); ?>" alt="Loading..." class="loader" id="loader"
                                    style="display:none; width:10%;">
                            </div>
                            <div class="form-group col-md-6">
                                <label for="class_id" class="mt-2">Class <span class="text-danger">*</span></label>
                                <input type="hidden" name="current_session" value='' id="current_session">
                                <input type="hidden" id="initialClassId" name="initialClassId"
                                    value="<?php echo e(old('initialClassId', request()->get('class_id') !== null ? request()->get('class_id') : '')); ?>">
                                <select name="class_id" id="class_id"
                                    class="form-control mx-1 <?php $__errorArgs = ['class_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                    <option value="">All Class</option>
                                </select>
                                <?php $__errorArgs = ['class_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback form-invalid fw-bold" role="alert">
                                        <?php echo e($message); ?>

                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <img src="<?php echo e(config('myconfig.myloader')); ?>" alt="Loading..." class="loader" id="loader"
                                    style="display:none; width:10%;">
                            </div>
                        </div>

                        <div class="mt-3">
                            <button class="btn btn-primary" type="button" id="show-report">Report (New & Old)</button>
                            <button class="btn btn-primary" type="button" id="show-report-new"
                                value='NewAdmissionOnly'>Report (New Admission Only)</button>
                        </div>

                        <div class="super-div">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th></th>
                                        <th></th>
                                        <th>Hindu</th>
                                        <th>Muslim</th>
                                        <th>Christian</th>
                                        <th>Sikh</th>

                                    </tr>
                                </thead>
                                <tbody id="report-body">
                                </tbody>
                            </table>
                            <div class="export-div">
                                <button type="button" class="btn btn-info" id="export-button">Export</button>
                            </div>
                        </div>

                    </div>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('admin-scripts'); ?>
    <script>
        $(document).ready(function() {
            let initialSessionId = $('#initialSesstionId').val();
            getSession(initialSessionId);
            getClassDropDownWithAll();

            $('.super-div').hide();

            function getReport(newAdmission = '') {
                let sessionId = $('#session_id').val();
                let classId = $('#class_id').val();
                let newAdmissionId = newAdmission;
                $.ajax({
                    url: '<?php echo e(route('admin.reports.newAdmissionReportByReligion')); ?>',
                    type: 'GET',
                    dataType: 'JSON',
                    data: {
                        session_id: sessionId,
                        class: classId,
                        new_admission: newAdmissionId,
                    },
                    success: function(response) {
                        let tableHtml = '';
                        $.each(response.data, function(index, classData) {
                            // Initialize variables to store category values
                            let boysData = {
                                'Hindu': 0,
                                'Muslim': 0,
                                'Christian': 0,
                                'Sikh': 0

                            };
                            let girlsData = {
                                'Hindu': 0,
                                'Muslim': 0,
                                'Christian': 0,
                                'Sikh': 0
                            };

                            // Map the categories data to our structure
                            classData.religions.forEach(religion => {
                                boysData[religion.religion_name] = religion.boys;
                                girlsData[religion.religion_name] = religion.girls;
                            });

                            // Create row for boys
                            tableHtml += `
                                    <tr>
                                        <td rowspan="2">${classData.class}</td>
                                        <td>Boys --></td>
                                        <td>${boysData['Hindu']}</td>
                                        <td>${boysData['Muslim']}</td>
                                        <td>${boysData['Christian']}</td>
                                        <td>${boysData['Sikh']}</td>
                                    </tr>`;

                            // Create row for girls
                            tableHtml += `
                                    <tr>
                                        <td>Girls --></td>
                                        <td>${girlsData['Hindu']}</td>
                                        <td>${girlsData['Muslim']}</td>
                                        <td>${girlsData['Christian']}</td>
                                        <td>${girlsData['Sikh']}</td>
                                    </tr>`;
                        });
                        $('#report-body').html(tableHtml);
                    },
                    complete: function() {

                        loader.hide();
                    },
                    error: function(xhr) {
                        console.log(xhr);

                    },
                });

            }

            $('#show-report').click(function() {
                $('.super-div').show();
                getReport();
                getExcelReport();
            });
            $('#show-report-new').click(function() {
                $('.super-div').show();
                getReport($(this).val());
                getExcelReport($(this).val());
            });
            // Add event listeners for form field changes
            $('#class_id, #session_id').change(function() {
                $('.super-div').hide();
            });

            function getExcelReport(newAdmission = '') {
                $('#export-button').on('click', function() {
                    const session = $('#session_id').val();
                    const classId = $('#class_id').val();
                    let newAdmissionId = newAdmission;

                    const exportUrl = "<?php echo e(route('admin.reports.exportReportByReligion')); ?>?session_id=" +
                        session +
                        "&class=" + classId + "&new_admission=" + newAdmissionId;
                    window.location.href = exportUrl;
                });
            }


        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/webcalht/public_html/svpssoft/resources/views/admin/reports/new_admission/new_admission_report_by_religion.blade.php ENDPATH**/ ?>