<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <link rel="icon" type="image/x-icon" href="<?php echo e(config('myconfig.favIcon')); ?>">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous">
    </script>
</head>

<body>
    <div class="container">
        <div class="col-md-12">
            <div class="row">
                <div class="col-md-4">
                    <a href="<?php echo e(route('admin.login')); ?>" class="ml-5 fs-1" style="font-size: -webkit-xxx-large;">
                        <img src="<?php echo e(config('myconfig.admin')); ?>" alt="Admin">
                    </a>
                </div>
                <div class="col-md-4">
                    <a href="<?php echo e(route('fee.login')); ?>" class="ml-5fs-1" style="font-size: -webkit-xxx-large;">
                        <img src="<?php echo e(config('myconfig.fee')); ?>" alt="Fee">
                    </a>
                </div>
                <div class="col-md-4">
                    <a href="<?php echo e(route('student.login')); ?>" class="ml-5 fs-1" style="font-size: -webkit-xxx-large; ">
                        <img src="<?php echo e(config('myconfig.student')); ?>" alt="Std">
                    </a>
                </div>
                <div class="row">
                    <div class="col-md-4">
                        <a href="<?php echo e(route('marks.login')); ?>" class="ml-5 fs-1" style="font-size: -webkit-xxx-large;">
                            <img src="<?php echo e(config('myconfig.marks')); ?>" alt="Marks">
                        </a>
                    </div>
                    <div class="col-md-4">
                        <a href="<?php echo e(route('inventory.login')); ?>" class="ml-5 fs-1"
                            style="font-size: -webkit-xxx-large;">
                            <img src="<?php echo e(config('myconfig.inventory')); ?>" alt="Inventory">
                        </a>
                    </div>
                </div>
            </div>

        </div>
    </div>
    <script>
        window.onload = function() {
            if ('caches' in window) {
                caches.keys().then(function(cacheNames) {
                    cacheNames.forEach(function(cacheName) {
                        caches.delete(cacheName);
                    });
                });
            }
        };
    </script>
</body>

</html>
<?php /**PATH /home1/webcalht/public_html/svpssoft/resources/views/index.blade.php ENDPATH**/ ?>