<?php $__env->startSection('sub-content'); ?>
    <div class="container">
        <?php if(Session::has('success')): ?>
            <?php $__env->startSection('scripts'); ?>
                <script>
                    swal("Successful", "<?php echo e(Session::get('success')); ?>", "success").then(() => {
                                    location.reload();
                                });
                </script>
            <?php $__env->stopSection(); ?>
        <?php endif; ?>

        <?php if(Session::has('error')): ?>
            <?php $__env->startSection('scripts'); ?>
                <script>
                    swal("Error", "<?php echo e(Session::get('error')); ?>", "error");
                </script>
            <?php $__env->stopSection(); ?>
        <?php endif; ?>
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header"><?php echo e(__('Session Master')); ?>

                        <a href="<?php echo e(route('admin.session-master.create')); ?>" class="btn btn-info" style="float: right;">Add</a>

                    </div>

                    <div class="card-body">

                        <div class="table">
                            <table id="example" class="table table-striped table-bordered">
                                <thead>
                                    <tr>
                                        <th>S No.</th>
                                        <th>Session</th>
                                        <th class="text-center">Action</th>
                                    </tr>
                                </thead>

                                <?php if(count($data) > 0): ?>
                                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr data-entry-id="<?php echo e($value->id); ?>">
                                            <td><?php echo e($data->firstItem() + $key?? ''); ?></td>
                                            <td><?php echo e($value->session ?? ''); ?></td>


                                            <td class="text-center">
                                                <a href="<?php echo e(route('admin.session-master.edit', $value->id)); ?>"
                                                    class="btn btn-sm btn-icon p-1">
                                                    <i class="mdi mdi-pencil" data-bs-toggle="tooltip" data-bs-offset="0,4"
                                                        data-bs-placement="top" title="Edit"></i>
                                                </a>
                                                


                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="5">No Session Found</td>
                                    </tr>
                                <?php endif; ?>
                            </table>

                            <?php if((request()->get('start_year') || request()->get('end_year'))): ?>
                                <?php echo e($data->appends(['start_year' => request()->get('start_year'),'end_year' => request()->get('end_year')])->links()); ?>

                            <?php else: ?>
                                <?php echo e($data->links()); ?>

                            <?php endif; ?>

                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/webcalht/public_html/svpssoft/resources/views/admin/session/index.blade.php ENDPATH**/ ?>