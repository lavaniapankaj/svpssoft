<?php $__env->startSection('sub-content'); ?>
    <div class="container">
       <div class="row justify-content-center">
            <div class="col-md-14">
                <div class="card">
                    <div class="card-header">
                        <?php echo e('Fee Details'); ?>

                        <a href="<?php echo e(route('fee.fee-detail-relaive-wise')); ?>" class="btn btn-warning btn-sm" style="float: right;">Back</a>

                    </div>
                    <div class="card-body">
                        <input type="hidden" id="session" name="current_session" value="<?php echo e($session); ?>">
                        <input type="hidden" id="std_id" name="std_id" value="<?php echo e($st); ?>">
                        <input type="hidden" id="class_id" name="class" value="<?php echo e($class); ?>">
                        <input type="hidden" id="section_id" name="section" value="<?php echo e($section); ?>">
                        <div id="tables">

                            <div id="std-fee-due-table" class="mt-2">
                                <table class="table table-striped table-bordered">
                                    <thead>
                                        <tr>
                                            <th colspan="10">Academic Fee Due Details</th>
                                        </tr>
                                        <tr>

                                            <th></th>
                                            <th>Admission Fee</th>
                                            <th>Ist Installment</th>
                                            <th>IInd Installment</th>
                                            <th>Complete Fee</th>
                                            <th>Mercy Fee</th>
                                            <th>Status</th>
                                            <th>Pay Date</th>
                                            <th>Recp. No.</th>
                                            <th>Ref. Slip No.</th>
                                        </tr>
                                    </thead>
                                    <tbody class="table-group-divider">
                                    </tbody>
                                    <tfoot class="footer table-group-divider">
                                    </tfoot>
                                </table>
                            </div>
                            <div id="std-transport-fee-due-table" class="table-responsive">
                                <table class="table table-striped table-bordered">
                                    <thead>
                                        <tr>
                                            <th colspan="9">Transport Fee Due Details</th>
                                        </tr>
                                        <tr>

                                            <th></th>
                                            <th>Ist Installment</th>
                                            <th>IInd Installment</th>
                                            <th>Complete Fee</th>
                                            <th>Mercy Fee</th>
                                            <th>Status</th>
                                            <th>Pay Date</th>
                                            <th>Recp. No.</th>
                                            <th>Ref. Slip No.</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    </tbody>
                                    <tfoot class="footerTrans table-group-divider">
                                    </tfoot>
                                </table>
                            </div>
                        </div>
                        <div class="mt-3">
                            <button type="button" id="print-receipt" class="btn btn-primary print-receipt">Print Receipt</button>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('fee-scripts'); ?>
    <script>
         $(document).ready(function() {
            let session = $('#session').val();
            let std = $('#std_id').val();
            let classId = $('#class_id').val();
            let sectionId = $('#section_id').val();
            if (session !== '' && std !== '' && classId !== '' && sectionId !== '') {
                adcademicAndTransportFeePopulate(std,session,classId,sectionId);
            }
            $('.print-receipt').click(function() {
                $('#tables').print();
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('fee.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/webcalht/public_html/svpssoft/resources/views/fee/fee_details/individual_fee_detail.blade.php ENDPATH**/ ?>