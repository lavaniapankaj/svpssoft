<?php $__env->startSection('sub-content'); ?>
    <div class="container">

        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header"><?php echo e(__('New Admission Report By Date')); ?>

                        <a href="<?php echo e(route('admin.reports.newAdmissionReport')); ?>" class="btn btn-warning btn-sm" style="float: right;">Back</a>
                    </div>

                    <div class="card-body">

                        <div class="row mt-2">
                            <div class="form-group col-md-6">
                                <label for="session_id" class="mt-2">Session <span class="text-danger">*</span></label>
                                <input type="hidden" id="initialSesstionId"
                                    value="<?php echo e(old('session_id', isset($data) ? $data->id : '')); ?>">
                                <select name="session_id" id="session_id"
                                    class="form-control <?php $__errorArgs = ['session_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                    <option value="">Select session</option>
                                </select>
                                <?php $__errorArgs = ['session_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback form-invalid fw-bold" role="alert">
                                        <?php echo e($message); ?>

                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <img src="<?php echo e(config('myconfig.myloader')); ?>" alt="Loading..." class="loader" id="loader"
                                    style="display:none; width:10%;">
                            </div>
                            <div class="form-group col-md-6">
                                <label for="class_id" class="mt-2">Class <span class="text-danger">*</span></label>
                                <input type="hidden" name="current_session" value='' id="current_session">
                                <input type="hidden" id="initialClassId" name="initialClassId"
                                    value="<?php echo e(old('initialClassId', request()->get('class_id') !== null ? request()->get('class_id') : '')); ?>">
                                <select name="class_id" id="class_id"
                                    class="form-control mx-1 <?php $__errorArgs = ['class_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                    <option value="">All Class</option>
                                </select>
                                <?php $__errorArgs = ['class_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback form-invalid fw-bold" role="alert">
                                        <?php echo e($message); ?>

                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <img src="<?php echo e(config('myconfig.myloader')); ?>" alt="Loading..." class="loader" id="loader"
                                    style="display:none; width:10%;">
                            </div>
                        </div>
                        <div class="row mt-2">
                            <div class="form-group col-md-6">
                                <label for="age_proof" class="mt-2">
                                    Admission By <span class="text-danger">*</span></label>
                                <select name="age_proof" id="age_proof"
                                    class="form-control <?php $__errorArgs = ['age_proof'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                    <option value="1,2,3,4">All</option>
                                    <option value="1">Transfer Certificate(T.C.)</option>
                                    <option value="2">Birth Certificate</option>
                                    <option value="3">Affidavit</option>
                                    <option value="4">Aadhar Card</option>
                                </select>
                                <?php $__errorArgs = ['age_proof'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback form-invalid fw-bold" role="alert">
                                        <?php echo e($message); ?>

                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                            </div>
                            <div class="form-group col-md-6">
                                <label for="by_date" class="mt-2">Enter Date</label>
                                <input type="date" name="by_date" id="by_date" class="form-control">
                            </div>
                        </div>
                        <div class="mt-3">
                            <button class="btn btn-primary" type="button" id="show-report">Show Report</button>
                        </div>
                        
                        <div class="super-div">
                        </div>

                    </div>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('admin-scripts'); ?>
    <script>
        $(document).ready(function() {
            let initialSessionId = $('#initialSesstionId').val();
            getSession(initialSessionId);
            getClassDropDownWithAll();

            const loader = $('#loader');

            // Function to clear existing report content
            function clearReportContent() {
                // $('#show-report').nextAll().remove();
                $('.super-div').nextAll().remove();
            }

            // Initial clear
            clearReportContent();
            $('.super-div').hide();
            // Function to generate table HTML based on byDate condition
            function generateTableHtml(data, byDate) {
                if (!byDate) {
                    return generateSingleTable(data);
                }

                let beforeSection = `
                            <div class="row mt-4 mb-4">
                                <div class="col-12">
                                    <table class="table table-bordered">
                                        <thead>
                                            <tr>
                                                <th colspan="3" class="bg-light">Before Section</th>
                                            </tr>
                                            <tr>
                                                <th>Class</th>
                                                <th>Students</th>
                                                <th>Total</th>
                                            </tr>
                                        </thead>
                                        <tbody>`;

                // Generate all "Before" rows
                data.forEach(value => {
                    beforeSection += `
                        <tr>
                            <td style="width: 200px;" class="align-middle">${value.class}</td>
                            <td class="p-0">
                                <table class="table table-bordered mb-0">
                                    <tr>
                                        <td style="width: 200px;">Boys --></td>
                                        <td style="width: 100px;" class="text-end">${value.before.boys}</td>
                                    </tr>
                                    <tr>
                                        <td>Girls --></td>
                                        <td class="text-end">${value.before.girls}</td>
                                    </tr>
                                </table>
                            </td>
                            <td class="align-middle text-center" style="width: 100px;">
                                ${value.before.total}
                            </td>
                        </tr>`;
                });

                beforeSection += `
                    </tbody>
                </table>
            </div>
        </div>`;

                let afterSection = `
                        <div class="row mb-4">
                            <div class="col-12">
                                <table class="table table-bordered">
                                    <thead>
                                        <tr>
                                            <th colspan="3" class="bg-light">After Section</th>
                                        </tr>
                                        <tr>
                                            <th>Class</th>
                                            <th>Students</th>
                                            <th>Total</th>
                                        </tr>
                                    </thead>
                                    <tbody>`;

                // Generate all "After" rows
                data.forEach(value => {
                    afterSection += `
                            <tr>
                                <td style="width: 200px;" class="align-middle">${value.class}</td>
                                <td class="p-0">
                                    <table class="table table-bordered mb-0">
                                        <tr>
                                            <td style="width: 200px;">Boys --></td>
                                            <td style="width: 100px;" class="text-end">${value.after.boys}</td>
                                        </tr>
                                        <tr>
                                            <td>Girls --></td>
                                            <td class="text-end">${value.after.girls}</td>
                                        </tr>
                                    </table>
                                </td>
                                <td class="align-middle text-center" style="width: 100px;">
                                    ${value.after.total}
                                </td>
                            </tr>`;
                });

                afterSection += `
                                    </tbody>
                                </table>
                            </div>
                        </div>`;

                return beforeSection + afterSection;
            }

            // Helper function for non-dated tables
            function generateSingleTable(data) {
                let tableHtml = '';
                data.forEach(value => {
                    tableHtml += `
                        <div class="row mb-2 mt-4">
                            <div class="col-12">
                                <table class="table table-bordered mb-0">
                                    <tr>
                                        <td style="width: 200px;" class="align-middle">${value.class}</td>
                                        <td class="p-0">
                                            <table class="table table-bordered mb-0">
                                                <tr>
                                                    <td style="width: 200px;">Boys --></td>
                                                    <td style="width: 100px;" class="text-end">${value.boys}</td>
                                                </tr>
                                                <tr>
                                                    <td>Girls --></td>
                                                    <td class="text-end">${value.girls}</td>
                                                </tr>
                                            </table>
                                        </td>
                                    </tr>
                                </table>
                            </div>
                        </div>`;
                });
                return tableHtml;
            }

            // Handle show report click
            $('#show-report').click(function() {
                const session = $('#session_id').val();
                const classId = $('#class_id').val();
                const ageProof = $('#age_proof').val();
                const byDate = $('#by_date').val();

                // Clear existing report content
                clearReportContent();
                $('.super-div').show();

                loader.show();

                $.ajax({
                    url: "<?php echo e(route('admin.reports.newAdmissionReportByDate')); ?>",
                    type: "GET",
                    data: {
                        session_id: session,
                        class: classId,
                        age_proof: ageProof,
                        by_date: byDate
                    },
                    success: function(response) {
                        if (response.data.length > 0) {
                            const byDate = $('#by_date').val();
                            const tableHtml = generateTableHtml(response.data, byDate);

                            // $('#show-report').after(tableHtml);
                            $('.super-div').html(tableHtml);
                            $('.super-div').after(`<div class="export-div">
                             <button type="button" class="btn btn-info" id="export-button">Export</button>
                            </div>`);
                        } else {
                            $('.super-div').html(
                                '<p class="text-center">No data found.</p>');
                        }
                    },
                    complete: function() {
                        loader.hide();
                    },
                    error: function(xhr) {
                        console.error(xhr.responseText);
                        $('.super-div').html(
                            '<p class="text-center text-danger">Error loading data.</p>');
                    }
                });
            });

            // Add event listeners for form field changes
            $('#class_id, #session_id, #age_proof, #by_date').change(function() {
                clearReportContent();
                $('.super-div').hide();
            });

            $(document).on('click', '#export-button', function() {
                const session = $('#session_id').val();
                const classId = $('#class_id').val();
                const ageProof = $('#age_proof').val();
                const byDate = $('#by_date').val();

                const exportUrl = "<?php echo e(route('admin.reports.exportReport')); ?>?session_id=" + session +
                    "&class=" + classId + "&age_proof=" + ageProof + "&by_date=" + byDate;
                window.location.href = exportUrl;
            });

        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\svps-project\resources\views/admin/reports/new_admission_report_by_date.blade.php ENDPATH**/ ?>