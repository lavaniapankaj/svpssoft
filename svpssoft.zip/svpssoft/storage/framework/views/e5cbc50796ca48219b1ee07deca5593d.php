<?php $__env->startSection('sub-content'); ?>
    <div class="container">
        <?php if(Session::has('success')): ?>
            <?php $__env->startSection('scripts'); ?>
                <script>
                    swal("Successful", "<?php echo e(Session::get('success')); ?>", "success").then(() => {
                        location.reload();
                    });
                </script>
            <?php $__env->stopSection(); ?>
        <?php endif; ?>

        <?php if(Session::has('error')): ?>
            <?php $__env->startSection('scripts'); ?>
                <script>
                    swal("Error", "<?php echo e(Session::get('error')); ?>", "error").then(() => {
                        location.reload();
                    });
                </script>
            <?php $__env->stopSection(); ?>
        <?php endif; ?>
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header"><?php echo e(__('District Master')); ?>

                        <a href="<?php echo e(route('admin.district-master.create')); ?>" class="btn btn-info"
                            style="float: right;">Add</a>
                        <div class="col-lg-12 col-md-12">
                            <div class="right-item d-flex justify-content-end mt-4">
                                <form action="<?php echo e(route('admin.district-master.index')); ?>" method="get" class="d-flex">
                                    <select name="state_id" id="state_id" class="form-control mx-1" required>
                                        <option value="">Select State</option>
                                        <?php if(count($states) > 0): ?>
                                            <?php $__currentLoopData = $states; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($key); ?>"
                                                    <?php echo e(old('state_id', request()->get('state_id') !== null ? request()->get('state_id') : '') == $key ? 'selected' : ''); ?>>
                                                    <?php echo e($state); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php else: ?>
                                            <option value="">No State Found</option>
                                        <?php endif; ?>
                                    </select>
                                    <button type="submit" class="btn btn-sm btn-info mx-2">Search</button>
                                </form>
                                <a href="<?php echo e(route('admin.district-master.index')); ?>" class="btn btn-warning">Reset</a>
                            </div>
                        </div>
                    </div>

                    <div class="card-body">

                        <div class="table">
                            <table id="example" class="table table-striped table-bordered">
                                <thead>
                                    <tr>
                                        <th>S No.</th>
                                        <th>District</th>
                                        <th>State</th>
                                        <th class="text-center">Action</th>
                                    </tr>
                                </thead>

                                <?php if(count($data) > 0): ?>
                                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr data-entry-id="<?php echo e($value->id); ?>">
                                            <td><?php echo e($data->firstItem() + $key ?? ''); ?></td>
                                            <td><?php echo e($value->name ?? ''); ?></td>
                                            <td><?php echo e($value->state->name ?? ''); ?></td>


                                            <td class="text-center">


                                                <a href="<?php echo e(route('admin.district-master.edit', $value->id)); ?>"
                                                    class="btn btn-sm btn-icon p-1">
                                                    <i class="mdi mdi-pencil" data-bs-toggle="tooltip" data-bs-offset="0,4"
                                                        data-bs-placement="top" title="Edit"></i>
                                                </a>

                                                

                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="5">No District Found</td>
                                    </tr>
                                <?php endif; ?>
                            </table>

                            <?php if(request()->get('state_id')): ?>
                                <?php echo e($data->appends(['state_id' => request()->get('state_id')])->links()); ?>

                            <?php else: ?>
                                <?php echo e($data->links()); ?>

                            <?php endif; ?>

                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/webcalht/public_html/svpssoft/resources/views/admin/district/index.blade.php ENDPATH**/ ?>