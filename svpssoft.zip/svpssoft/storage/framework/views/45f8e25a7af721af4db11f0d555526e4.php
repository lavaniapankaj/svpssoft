<?php $__env->startSection('content'); ?>
    <div class="d-flex">
        <div class="py-4 col-md-2 navbar-light bg-white shadow-sm"
            style="height: 900px !important; background-color:#fe7c3e !important; color:white ;">
            <ul class="navbar-nav me-auto px-3">
                <li class="nav-item">
                    <a class="nav-link fs-5 fw-medium" href="<?php echo e(route('marks.changePass')); ?>">
                        <i class="mdi mdi-lock-reset"></i>
                        <span class="menu-title">Change Password</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link fs-5 fw-medium" href="<?php echo e(route('marks.marks-entry.index')); ?>">
                        <i class="mdi mdi-book"></i>
                        <span class="menu-title">Marks Entry</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link fs-5 fw-medium" href="<?php echo e(route('marks.marks-report')); ?>">
                        <i class="mdi mdi-book"></i>
                        <span class="menu-title">Marks Report</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link fs-5 fw-medium" href="<?php echo e(route('marks.marksheet')); ?>">
                        <i class="mdi mdi-book"></i>
                        <span class="menu-title">Marksheet</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link fs-5 fw-medium" href="<?php echo e(route('marks.rank-class-wise')); ?>">
                        <i class="mdi mdi-medal"></i>
                        <span class="menu-title">Rank Class Wise</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link fs-5 fw-medium" href="<?php echo e(route('marks.current-session.index')); ?>">
                        <i class="mdi mdi-cog"></i>
                        <span class="menu-title">Setting</span>
                    </a>
                </li>


            </ul>
        </div>
        <main class="py-4 col-md-10">

            <?php echo $__env->yieldContent('sub-content'); ?>
        </main>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('current-session'); ?>
    <li class="mx-2 my-2 fw-bold border border-1 py-2 px-2 rounded-pill bg-black-subtle">
        <?php if(Session::has('marks_current_session')): ?>
            <?php echo e(Session::get('marks_current_session')->session); ?>

            <input type="hidden" name="marks_current_session" id="marks_current_session"
                value="<?php echo e(Session::get('marks_current_session')->id); ?>">
        <?php else: ?>
            No current session found.
        <?php endif; ?>
    </li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('public/marks/assets/js/custom.js')); ?>" type="text/javascript"></script>
    <?php echo $__env->yieldContent('marks-scripts'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/webcalht/public_html/svpssoft/resources/views/marks/index.blade.php ENDPATH**/ ?>