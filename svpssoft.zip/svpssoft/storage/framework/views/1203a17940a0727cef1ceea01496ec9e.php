<?php $__env->startSection('sub-content'); ?>
    <div class="container">

        <div class="row justify-content-center">
            <div class="col-md-14">
                <div class="card">
                    <div class="card-header">
                        <?php echo e('Back Session Fee Details'); ?>

                        <a href="<?php echo e(route('fee.back-session-fee-detail')); ?>" class="btn btn-warning btn-sm"
                            style="float: right;">Back</a>
                    </div>
                    <div class="card-body">
                        <form id="class-section-form">
                            <div class="row">
                                <div class="form-group col-md-4">
                                    <label for="session_id" class="mt-2">Session <span
                                            class="text-danger">*</span></label>
                                    <input type="hidden" name="sessionId" value="" id="sessionId">
                                    <select name="session_id" id="session_id" class="form-control " required>
                                        <option value="">Select Session</option>
                                    </select>
                                    <span class="invalid-feedback form-invalid fw-bold" id="session-error"
                                        role="alert"></span>
                                </div>
                                <div class="form-group col-md-4">
                                    <label for="back_class_id" class="mt-2">Class <span
                                            class="text-danger">*</span></label>
                                    <input type="hidden" id="initialClassId"
                                        value="<?php echo e(old('initialClassId', request()->get('class_id') !== null ? request()->get('class_id') : '')); ?>">
                                    <select name="class" id="back_class_id" class="form-control " required>
                                        <option value="">All Class</option>
                                    </select>
                                    <span class="invalid-feedback form-invalid fw-bold" id="class-error"
                                        role="alert"></span>
                                    <img src="<?php echo e(config('myconfig.myloader')); ?>" alt="Loading..." class="loader"
                                        id="loader" style="display:none; width:10%;">
                                </div>


                                <div class="form-group col-md-4">
                                    <label for="back_section_id" class="mt-2">Section <span
                                            class="text-danger">*</span></label>
                                    <input type="hidden" id="initialSectionId"
                                        value="<?php echo e(old('initialSectionId', request()->get('section_id') !== null ? request()->get('section_id') : '')); ?>">
                                    <select name="section" id="back_section_id" class="form-control  " required>
                                        <option value="">All Section</option>
                                    </select>
                                    <span class="invalid-feedback form-invalid fw-bold" id="section-error"
                                        role="alert"></span>
                                </div>
                            </div>
                            <div class="row">
                                <div class="form-group col-md-6">
                                    <input type="hidden" name="current_session" value='' id="current_session">
                                    <label for="back_std_id" class="mt-2">Student <span
                                            class="text-danger">*</span></label>
                                    <select name="std_id" id="back_std_id" class="form-control " required>
                                        <option value="">All Students</option>
                                    </select>
                                    <span class="invalid-feedback form-invalid fw-bold" id="std-error"
                                        role="alert"></span>
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="report" class="mt-2">Select Report <span
                                            class="text-danger">*</span></label>
                                    <select name="report" id="report" class="form-control " required>
                                        
                                        <option value="complete" selected>Complete Report</option>
                                        <option value="due">Due Report</option>
                                    </select>
                                </div>
                            </div>

                            <div class="mt-3">
                                <button type="button" id="show-details" class="btn btn-primary">Show Details</button>
                                
                            </div>

                        </form>

                        <div id="complete-fee-table" class="table-responsive mt-5">
                            <table class="table table-striped table-bordered">
                                <thead>
                                    <th>Class</th>
                                    <th>Section</th>
                                    <th>Name</th>
                                    <th>F. Name</th>
                                    <th>Payable(Ac.)</th>
                                    <th>Paid(Ac.)</th>
                                    <th>Due(Ac.)</th>
                                    <th>Payable(Tr.)</th>
                                    <th>Paid(Tr.)</th>
                                    <th>Due(Tr.)</th>
                                    <th>Total Due</th>
                                    <th>Details</th>
                                    <th>Status</th>
                                </thead>
                                <tbody></tbody>
                            </table>
                            <div class="export-div">
                                <button type="button" class="btn btn-info" id="export-button">Export</button>
                            </div>
                            <div id="std-pagination"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('fee-scripts'); ?>
  <script>
        var initialSessionId =
            '<?php echo e(old('session_id', request()->get('session_id') !== null ? request()->get('session_id') : '')); ?>';
        getSession(initialSessionId);
        $(document).ready(function() {
            let classId = $('#back_class_id');
            let sectionId = $('#back_section_id');
            let sessionId = $('#session_id');
            let currentPage = 1;
            // var paginationContainer = $('#std-pagination');
            let stdId = $('#back_std_id');
            let loader = $('#loader');
            let hiddenSession = $('#sessionId');
            let stdHtml = '';
            $('#complete-fee-table').hide();
            classSectionWithAll(fetchStudentsForSession, fetchStudents);
            function fetchStudentsForSession() {
                let selectedSession = hiddenSession.val();
                let allClassesValue = classId.find('option:first').val();
                let allSectionsValue = sectionId.find('option:first').val();
                fetchStudents(allSectionsValue);
            }

            function studentTable(st, page = 1) {
                let reportType = $('#report').val();

                $.ajax({
                    url: '<?php echo e(route('fee.studentWithoutSsid')); ?>',
                    type: 'GET',
                    dataType: 'JSON',
                    data: {
                        session: hiddenSession.val(),
                        srno: st,
                        page: page,

                    },
                    success: function(data) {
                        let stdHtml = '';
                        const isAllStudents = st.includes(',');
                        const isAllSections = sectionId.val().includes(',');
                        data.data.forEach(value => {
                            let isValidateIsAll = isAllSections === false ? (st === value.student.srno.toString()) && (sectionId.val() == value.student.section.toString()) : (st === value.student.srno.toString());


                            // if (isAllStudents || st === value.student.srno.toString()) {
                            if (isAllStudents || isValidateIsAll) {
                                const totalDue = value.due_amount + value.trans_due_amount;

                                // Only include the student if it's a complete report or if there's a due amount
                                if (reportType === 'complete' || totalDue > 0) {
                                    stdHtml += `<tr>
                                        <td>${value.class_name}</td>
                                        <td>${value.section_name}</td>
                                        <td>${value.student_name}</td>
                                        <td>${value.father_name}</td>
                                        <td>${value.payable_amount}</td>
                                        <td>${value.paid_amount}</td>
                                        <td>${value.due_amount}</td>
                                        <td>${value.trans_payable_amount}</td>
                                        <td>${value.trans_paid_amount}</td>
                                        <td>${value.trans_due_amount}</td>
                                        <td>${totalDue}</td>
                                        <td><a href='${siteUrl}/fee/back-session/individual-fee-details/${value.student.srno}/${value.student.session_id}/${value.student.class}' class="btn btn-sm btn-icon p-1"> <i class="mdi mdi-eye mx-1" data-bs-toggle="tooltip"
                                                                data-bs-offset="0,4" data-bs-placement="top" title="View"></i></a></td>
                                        <td>${
                                            value.student.ssid == 1 ? 'Active' :
                                            value.student.ssid == 2 ? 'Class Promoted' :
                                            value.student.ssid == 3 ? 'School Promoted' :
                                            value.student.ssid == 4 ? 'Tc' :
                                            value.student.ssid == 5 ? 'Left Out' : ''
                                        }</td>
                                    </tr>`;
                                }
                            }
                        });

                        $('#complete-fee-table table tbody').html(stdHtml);
                        updatePaginationControls(data.pagination);
                    },
                    complete: function() {
                        loader.hide();
                    },
                    error: function(data) {
                        console.error('Error fetching students:', data.responseJSON ? data.responseJSON
                            .message : 'Unknown error');
                    }
                });
            }



            function fetchStudents(sectionIds) {
                loader.show();
                $.ajax({
                    url: '<?php echo e(route('fee.studentWithoutSsid')); ?>',
                    type: 'GET',
                    dataType: 'JSON',
                    data: {
                        session: hiddenSession.val(),
                        class: classId.val(),
                        section: sectionIds,
                    },
                    success: function(data) {

                        stdId.empty();
                        let allStdIds = [];

                        if (sectionIds.includes(',')) {

                            // Always populate allStdIds
                            $.each(data.data, function(id, value) {
                                allStdIds.push(value.student.srno);
                            });

                            // Add "All Students" option
                            stdId.append('<option value="' + allStdIds.join(',') +
                                '" selected>All Students</option>');
                        } else {

                            // Add individual student options
                            $.each(data.data, function(id, value) {
                                stdId.append('<option value="' + value.student.srno + '">' +
                                    value.student_name +
                            '/SH. ' +
                            value.father_name + '</option>');
                            });
                        }

                        // Fetch students for the initial selection
                        var selectedStValue = stdId.val();
                        studentTable(selectedStValue ? selectedStValue : allStdIds.join(','));

                    },
                    complete: function() {
                        loader.hide();
                    },
                    error: function(data) {
                        console.error('Error fetching students:', data.responseJSON ? data.responseJSON
                            .message : 'Unknown error');
                    }
                });
            }

            $(document).on('click', '#std-pagination .page-link', function(e) {
                e.preventDefault();
                var st = stdId.val();
                var page = $(this).data('page');
                currentPage = $(this).data('page');
                //    fetchStdNameFather(sessionId, page);
                studentTable(st, page);
            });



            sectionId.change(function() {
                fetchStudents($(this).val());
            });
            sessionId.change(function() {
                hiddenSession.val($(this).val());
                // Reset class and section to "All" options
                classId.val(classId.find('option:first').val());
                sectionId.val(sectionId.find('option:first').val());

                if ($(this).val() == '') {
                    $('#complete-fee-table').hide();
                }

                // Fetch students with the new session and default "All" options
                fetchStudentsForSession();
            });


            stdId.change(function() {
                studentTable($(this).val());
            });


            // Add an event listener for the report dropdown
            $('#report').change(function() {
                let selectedStudents = $('#back_std_id').val();
                studentTable(selectedStudents);
            });

            // Modify the show-details button click event
            $('#show-details').click(function() {
                if (sessionId.val() == '' || sessionId.val() == undefined) {
                    $('#session-error').show().html('Select the Session');
                    $('#complete-fee-table').hide();
                }else{
                    $('#session-error').hide().html('');
                    $('#complete-fee-table').show();
                }

            });

            function getExcelReport(std = stdId.val(), p = 1) {
                    let session = $('#sessionId').val();
                    let page = p;
                    let st = std;
                    let report = $('#report').val();
                    const exportUrl = "<?php echo e(route('fee.back-session-fee-detail-excel')); ?>?session=" +
                        session + "&srno=" + st + "&page=" + page + "&reportType=" + report ;
                    window.location.href = exportUrl;
            }
            $('#export-button').on('click', function() {
                var st = stdId.val();
                getExcelReport(st, currentPage);
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('fee.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/webcalht/public_html/svpssoft/resources/views/fee/fee_details/back_session_fee_detail.blade.php ENDPATH**/ ?>