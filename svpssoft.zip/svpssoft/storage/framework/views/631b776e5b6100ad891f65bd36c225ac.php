<?php $__env->startSection('sub-content'); ?>
    <div class="container">

        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">
                        <?php echo e('Group SMS Master'); ?>

                        <a href="<?php echo e(route('admin.group-sms-panel.index')); ?>" class="btn btn-warning btn-sm"
                            style="float: right;">Back</a>

                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="form-group col-md-6">
                                <div class="mt-3">
                                    <a href="<?php echo e(route('admin.add-sms-group.index')); ?>" id="add-group" class="btn btn-sm btn-primary">Add Group</a>
                                    <a href="<?php echo e(route('admin.add-edit-sms-group-mobile.index')); ?>" id="add-edit-mobile" class="btn btn-sm btn-primary">Add/Edit Mobile Number</a>
                                    <a href="<?php echo e(route('admin.send-group-sms.index')); ?>" id="send-sms" class="btn btn-sm btn-primary">Send SMS</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/webcalht/public_html/svpssoft/resources/views/admin/groupsms/index.blade.php ENDPATH**/ ?>