<?php $__env->startSection('sub-content'); ?>

    <div class="container">

        <div class="row justify-content-center">

            <div class="col-md-12">

                <div class="card">

                    <div class="card-header">

                        <?php echo e('Print Final Marksheet (3rd to 5th)'); ?>


                        <a href="<?php echo e(route('marks.marks-report.marksheet.third.fifth')); ?>" class="btn btn-warning btn-sm" style="float: right;">Back</a>
                        <button type="button" id="print-marksheet" class="btn btn-sm btn-primary mx-2 print-marksheet" style="float: right;">Print Marksheet</button>
                    </div>

                    <div class="card-body">

                            <input type="hidden" id="class" value="<?php echo e($class); ?>">

                            <input type="hidden" id="section" value="<?php echo e($section); ?>">

                            <input type="hidden" id="students" value="<?php echo e($students); ?>">

                            <input type="hidden" id="exam" value="<?php echo e($exam); ?>">

                            <input type="hidden" id="with" value="<?php echo e($with); ?>">

                            <input type="hidden" id="without" value="<?php echo e($without); ?>">

                            <input type="hidden" id="session-message" value="<?php echo e($sessionMessage); ?>">

                            <input type="hidden" id="date-message" value="<?php echo e($dateMessage); ?>">

                        <div class="row">

                            <img src="<?php echo e(config('myconfig.myloader')); ?>" alt="Loading..." class="loader"

                                    id="loader" style="width:10%;">

                            <div class="marksheet-div">
                                <div class="marksheet"></div>
                                <div class="mt-3">
                                    <button type="button" id="print-marksheet" class="btn btn-primary print-marksheet">Print Marksheet</button>

                                </div>

                            </div>

                        </div>

                    </div>

                </div>

            </div>

        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('marks-scripts'); ?>

    <script>

        $(document).ready(function() {
            marksheetData();
        });

    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('marks.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/webcalht/public_html/svpssoft/resources/views/marks/marksheet/marksheet_final_third_fifth_print.blade.php ENDPATH**/ ?>