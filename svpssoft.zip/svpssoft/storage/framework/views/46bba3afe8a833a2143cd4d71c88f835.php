<?php $__env->startSection('sub-content'); ?>
    <div class="container">
        <?php if(Session::has('success')): ?>
            <?php $__env->startSection('scripts'); ?>
                <script>
                    swal("Good job!", "<?php echo e(Session::get('success')); ?>", "success").then(() => {
                        location.reload();
                    });
                </script>
            <?php $__env->stopSection(); ?>
        <?php endif; ?>

        <?php if(Session::has('error')): ?>
            <?php $__env->startSection('scripts'); ?>
                <script>
                    swal("Oops...", "<?php echo e(Session::get('error')); ?>", "error");
                </script>
            <?php $__env->stopSection(); ?>
        <?php endif; ?>
        <div class="row justify-content-center">
            <div class="col-md-14">
                <div class="card">
                    <div class="card-header">
                        <?php echo e('Marks Entry'); ?>

                        <a href="<?php echo e(route('marks.marks-entry.index')); ?>" class="btn btn-warning btn-sm"
                            style="float: right;">Back</a>

                    </div>
                    <div class="card-body">
                        <form id="class-section-form">

                            <div class="row">
                                <div class="form-group col-md-6">
                                    <label for="class_id" class="mt-2">Class <span class="text-danger">*</span></label>
                                    <input type="hidden" id="initialClassId"
                                        value="<?php echo e(old('initialClassId', request()->get('class_id') !== null ? request()->get('class_id') : '')); ?>">
                                    <select name="class" id="class_id"
                                        class="form-control <?php $__errorArgs = ['class'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                        <option value="">Select Class</option>
                                    </select>
                                    <?php $__errorArgs = ['class'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback form-invalid fw-bold"
                                            role="alert"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    <img src="<?php echo e(config('myconfig.myloader')); ?>" alt="Loading..." class="loader"
                                        id="loader" style="display:none; width:10%;">
                                </div>


                                <div class="form-group col-md-6">
                                    <label for="section_id" class="mt-2">Section <span
                                            class="text-danger">*</span></label>
                                    <input type="hidden" id="initialSectionId"
                                        value="<?php echo e(old('initialSectionId', request()->get('section_id') !== null ? request()->get('section_id') : '')); ?>">
                                    <select name="section" id="section_id"
                                        class="form-control <?php $__errorArgs = ['section'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                        <option value="">Select Section</option>

                                    </select>
                                    <?php $__errorArgs = ['section'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback form-invalid fw-bold"
                                            role="alert"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="row">
                                <div class="form-group col-md-6">
                                    <label for="subject_id" class="mt-2">Subject <span
                                            class="text-danger">*</span></label>
                                    <input type="hidden" id="initialSubjectId"
                                        value="<?php echo e(old('initialSubjectId', request()->get('subject_id') !== null ? request()->get('subject_id') : '')); ?>">
                                    <select name="subject" id="subject_id"
                                        class="form-control <?php $__errorArgs = ['subject'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                        <option value="">Select Subject</option>
                                    </select>
                                    <?php $__errorArgs = ['subject'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback form-invalid fw-bold"
                                            role="alert"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                </div>
                                <div class="form-group col-md-6">
                                    <label for="exam_id" class="mt-2">Exam <span class="text-danger">*</span></label>
                                    <input type="hidden" id="initialExamId"
                                        value="<?php echo e(old('initialExamId', request()->get('exam_id') !== null ? request()->get('exam_id') : '')); ?>">
                                    <select name="exam" id="exam_id"
                                        class="form-control <?php $__errorArgs = ['exam'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                        <option value="">Select Exam</option>

                                    </select>
                                    <?php $__errorArgs = ['exam'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback form-invalid fw-bold"
                                            role="alert"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="mt-3">
                                <button type="button" id="show-details" class="btn btn-primary">
                                    Show Details</button>
                            </div>

                        </form>


                        <div id="std-container" class="mt-4">
                            <form action="<?php echo e(route('marks.marks-entry.store')); ?>" method="POST" id="std-form">
                                <?php echo csrf_field(); ?>
                                <table class="table table-responsible">
                                    <input type="hidden" name="current_session" value='' id="current_session">
                                    <input type="hidden" name="hidden_class" value='' id="hidden_class">
                                    <input type="hidden" name="hidden_section" value='' id="hidden_section">
                                    <input type="hidden" name="hidden_subject" value='' id="hidden_subject">
                                    <input type="hidden" name="hidden_exam" value='' id="hidden_exam">

                                    <thead>
                                        <tr>
                                            <th>Roll No.</th>
                                            <th>Student</th>
                                            <th>Obtained Marks</th>
                                            <th>Attendance</th>
                                        </tr>
                                    </thead>
                                    <tbody>

                                    </tbody>
                                </table>
                                <div id="std-pagination"></div>
                                <div class="row">
                                    <div class="mt-3">
                                        <button type="submit" class="btn btn-primary"
                                            id="section-updateBtn">Update</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('marks-scripts'); ?>
    <script>
        var initialClassId =
            '<?php echo e(old('initialClassId', request()->get('class_id') !== null ? request()->get('class_id') : '')); ?>';
        var initialSectionId =
            '<?php echo e(old('initialSectionId', request()->get('section_id') !== null ? request()->get('section_id') : '')); ?>';
        getClassSection(initialClassId, initialSectionId);
        var initialSubjectId =
            '<?php echo e(old('initialSubjectId', request()->get('subject_id') !== null ? request()->get('subject_id') : '')); ?>';
        getClassSubject(initialClassId, initialSubjectId);
        var initialExamId =
            '<?php echo e(old('initialExamId', request()->get('exam_id') !== null ? request()->get('exam_id') : '')); ?>';
        getExams(initialExamId);

        $(document).ready(function() {
            $('#std-form').hide();
            $('#class-section-form').validate({
                rules: {
                    exam: {
                        required: true,
                    },
                    subject: {
                        required: true,
                    },
                    class: {
                        required: true,
                    },
                    section: {
                        required: true,
                    },
                },
                messages: {
                    exam: {
                        required: "Please select a exam.",
                    },
                    subject: {
                        required: "Please select a subject.",
                    },
                    class: {
                        required: "Please select a class.",
                    },
                    section: {
                        required: "Please select a section.",
                    },
                },
            });

            $('#show-details').on('click', function() {
                if ($('#class-section-form').valid()) {

                    const classId = $('#class_id').val();
                    const sectionId = $('#section_id').val();
                    const sessionId = $('#current_session').val();
                    const exam = $('#exam_id').val();
                    const subject = $('#subject_id').val();
                    const $paginationContainer = $('#std-pagination');
                    var page = 1;
                    loader.show();
                    $('#hidden_class').val(classId);
                    $('#hidden_section').val(sectionId);
                    $('#hidden_subject').val(subject);
                    $('#hidden_exam').val(exam);

                    function stdDetails(page) {
                        if (classId && sectionId && sessionId) {
                            $('#std-form').show();
                            $.ajax({
                                url: '<?php echo e(route('stdNameFather.get')); ?>',
                                type: 'GET',
                                dataType: 'JSON',
                                data: {
                                    class_id: classId,
                                    section_id: sectionId,
                                    session_id: sessionId,
                                    page: page,
                                },
                                success: function(students) {
                                    console.log(students);

                                    let stdHtml = '';
                                    $.each(students.data, function(index, std) {


                                        stdHtml += `<tr>
                                                <td>${std.rollno}</td>
                                                <td>
                                                    <input type="hidden" name="students[${index}][srno]" value="${std.srno}" class="std-srno" id="std-srno" data-index="${index}">
                                                    ${std.student_name}
                                                </td>
                                                <td>
                                                   <input type="text" name="students[${index}][marks]" value="" class="std-marks" id="stdMarks" data-index="${index}">
                                                   <span class="invalid-feedback form-invalid fw-bold" id="marks-error" role="alert"></span>
                                                </td>
                                                 <td>
                                                    <input type="checkbox" name="students[${index}][status]" value="1" class="status-checkbox" data-index="${index}" checked>
                                                </td>

                                                </tr>`;

                                    });
                                    if (stdHtml === '') {
                                        stdHtml =
                                            '<tr><td colspan="4">No Student found</td></tr>';
                                    }
                                    $('#std-container table tbody').html(stdHtml);
                                    updatePaginationControls(students);

                                },
                                complete: function() {
                                    loader.hide();
                                },
                                error: function(xhr) {
                                    console.log(xhr);

                                    console.error(xhr.responseText);

                                }
                            });
                        }
                    }
                    $(document).on('click', '#std-pagination .page-link', function(e) {
                        e.preventDefault();
                        var page = $(this).data('page');
                        stdDetails(page);
                    });

                    function updatePaginationControls(data) {
                        var paginationHtml = '';
                        if (data.last_page > 1) {
                            paginationHtml += '<ul class="pagination">';

                            if (data.current_page > 1) {
                                paginationHtml +=
                                    `<li class="page-item"><a class="page-link" href="#" data-page="${data.current_page - 1}">Previous</a></li>`;
                            }

                            for (let i = 1; i <= data.last_page; i++) {
                                if (i == data.current_page) {
                                    paginationHtml +=
                                        `<li class="page-item active"><span class="page-link">${i}</span></li>`;
                                } else {
                                    paginationHtml +=
                                        `<li class="page-item"><a class="page-link" href="#" data-page="${i}">${i}</a></li>`;
                                }
                            }

                            if (data.current_page < data.last_page) {
                                paginationHtml +=
                                    `<li class="page-item"><a class="page-link" href="#" data-page="${data.current_page + 1}">Next</a></li>`;
                            }

                            paginationHtml += '</ul>';
                        }
                        $paginationContainer.html(paginationHtml);
                    }

                    stdDetails(page);
                }
            });

            $(document).on('keypress', '.std-marks', function() {
                const inputVal = $(this).val();
                const char = String.fromCharCode(event.which);
                if (isNaN(char) || char.trim() === '') {
                    $(this).siblings('.invalid-feedback').show().text("Only numbers are allowed.");
                } else {
                    $(this).siblings('.invalid-feedback').hide();
                }
            });


        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('marks.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\svps-project\resources\views/marks/marks_entry/index.blade.php ENDPATH**/ ?>