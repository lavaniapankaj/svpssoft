<?php $__env->startSection('sub-content'); ?>
    <div class="container">
        <?php if(Session::has('success')): ?>
            <?php $__env->startSection('scripts'); ?>
                <script>
                    swal("Good job!", "<?php echo e(Session::get('success')); ?>", "success").then(() => {
                        $('#std-form').hide();
                        location.reload();
                    });
                </script>
            <?php $__env->stopSection(); ?>
        <?php endif; ?>

        <?php if(Session::has('error')): ?>
            <?php $__env->startSection('scripts'); ?>
                <script>
                    swal("Oops...", "<?php echo e(Session::get('error')); ?>", "error");
                </script>
            <?php $__env->stopSection(); ?>
        <?php endif; ?>
        <div class="row justify-content-center">
            <div class="col-md-14">
                <div class="card">
                    <div class="card-header">
                        <?php echo e('Relative Wise'); ?>

                        <a href="<?php echo e(route('student.student-report-relative-wise')); ?>" class="btn btn-warning btn-sm"
                            style="float: right;">Back</a>

                    </div>
                    <div class="card-body">
                        <form method="get" action="">
                            <div class="row">
                                <div class="form-group col-md-4">
                                    <label for="class_id" class="mt-2">Class <span class="text-danger">*</span></label>
                                    <input type="hidden" name="current_session" value='' id="current_session">
                                    <input type="hidden" id="initialClassId" name="initialClassId"
                                        value="<?php echo e(old('initialClassId', request()->get('class_id') !== null ? request()->get('class_id') : '')); ?>">
                                    <select name="class_id" id="class_id"
                                        class="form-control mx-1 <?php $__errorArgs = ['class_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                        <option value="">Select Class</option>
                                    </select>
                                    <?php $__errorArgs = ['class_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback form-invalid fw-bold" role="alert">
                                            <?php echo e($message); ?>

                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="form-group col-md-4">
                                    <label for="section_id" class="mt-2">Section<span class="text-danger">*</span></label>
                                    <input type="hidden" id="initialSectionId" name="initialSectionId"
                                        value="<?php echo e(old('initialSectionId', request()->get('section_id') !== null ? request()->get('section_id') : '')); ?>">
                                    <select name="section_id" id="section_id"
                                        class="form-control mx-1 <?php $__errorArgs = ['section_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                        <option value="">Select Section</option>
                                    </select>
                                    <?php $__errorArgs = ['section_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback form-invalid fw-bold" role="alert">
                                            <?php echo e($message); ?>

                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="form-group col-md-4">
                                    <label for="std_id" class="mt-2">Student<span class="text-danger">*</span></label>
                                    <input type="hidden" id="initialStdId" name="initialStdId"
                                        value="<?php echo e(old('initialStdId', request()->get('std_id') !== null ? request()->get('std_id') : '')); ?>">
                                    <select name="std_id" id="std_id"
                                        class="form-control mx-1 <?php $__errorArgs = ['std_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                        <option value="">Select Student</option>
                                    </select>
                                    <?php $__errorArgs = ['std_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback form-invalid fw-bold" role="alert">
                                            <?php echo e($message); ?>

                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <img src="<?php echo e(config('myconfig.myloader')); ?>" alt="Loading..." class="loader" id="loader"
                                    style="display:none; width:10%;">
                            </div>
                            <div class="row mt-4">
                                <div class="table" id="std-container" style="display: none;">
                                    <table id="example" class="table table-striped table-bordered">
                                        <thead>
                                            <tr>
                                                <th>Class</th>
                                                <th>Section</th>
                                                <th>SRNO</th>
                                                <th>Name</th>
                                                <th>Father's Name</th>
                                                <th>Mother's Name</th>
                                                <th>Father's Mobile</th>
                                                <th>Address</th>
                                                <th>State</th>
                                                <th>District</th>
                                                <th>Phone Number</th>
                                            </tr>
                                        </thead>
                                        <tbody class="">
                                        </tbody>
                                    </table>

                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('std-scripts'); ?>
    <script>
        var initialClassId =
            '<?php echo e(old('initialClassId', request()->get('class_id') !== null ? request()->get('class_id') : '')); ?>';
        var initialSectionId =
            '<?php echo e(old('initialSectionId', request()->get('section_id') !== null ? request()->get('section_id') : '')); ?>';
        // var initialStdId = '<?php echo e(old('initialStdId', request()->get('std_id') !== null ? request()->get('std_id') : '')); ?>';


        getClassSection(initialClassId, initialSectionId);

        $(document).ready(function() {
            getStudentDropdown();
            const classFirst = $('#class_id');
            const sectionFirst = $('#section_id');
            const sessionSelect = $('#current_session').val();
            const stdSelect = $('#std_id');

            function populateDropdowns(data, dropdown) {
                dropdown.empty();
                dropdown.append('<option value="">Select Student</option>');
                if (data) {

                    $.each(data, function(id, value) {
                        dropdown.append('<option value="' + value.srno + '">' +
                            ++id + '. ' + value.student_name + '/SH. ' + value.f_name +
                            '</option>');
                    });
                }else{
                    dropdown.empty();
                    dropdown.append('<option value="">Select Student</option>');
                }
            }


            function fetchStdNameFather(classId, sectionId, stdDropdown) {
                if (classId && sectionId) {
                    $.ajax({
                        url: '<?php echo e(route('stdNameFather.get')); ?>',
                        type: 'GET',
                        dataType: 'JSON',
                        data: {
                            class_id: classId,
                            section_id: sectionId,
                            session_id: sessionSelect,
                        },
                        success: function(data) {
                            populateDropdowns(data, stdDropdown);
                            stdWithRelative(data);
                        },
                        error: function(xhr) {
                            console.error('Error fetching student details:', xhr);
                        }
                    });

                }
            }

            function stdWithRelative(data) {

                stdSelect.change(function(e) {
                    const selectedStdId = $(this).val();
                    if (selectedStdId !== '') {

                        var rowsHtml = '';
                        $.ajax({
                            url: '<?php echo e(route('admin.getStdWithRelativeStd')); ?>',
                            type: 'GET',
                            dataType: 'JSON',
                            data: {
                                srno: selectedStdId
                            },
                            success: function(data) {
                                $.each(data.data, function(id, value) {
                                    console.log(value);

                                    if (value) {

                                        rowsHtml += `
                                                    <tr>
                                                        <td>${value.class_name}</td>
                                                        <td>${value.section_name}</td>
                                                        <td>${value.srno}</td>
                                                        <td>${value.student_name}</td>
                                                        <td>SH. ${value.f_name}</td>
                                                        <td>${value.m_name}</td>
                                                        <td>${value.f_mobile}</td>
                                                        <td>${value.address}</td>
                                                        <td>${value.state_name}</td>
                                                        <td>${value.district_name}</td>
                                                        <td>${value.m_mobile ?? 'N/A'}</td>

                                                    </tr>`;
                                        $('#std-container table tbody').html(rowsHtml);
                                        $('#std-container').show();
                                    } else {
                                        $('#std-container').hide();
                                    }
                                });
                            },
                            error: function(xhr) {

                                console.error('Error fetching student details:', xhr);
                            }
                        });
                    }
                });
            }

            classFirst.change(function() {
                $('#std-container').hide();
            });
            sectionFirst.change(function() {
                fetchStdNameFather(classFirst.val(), sectionFirst.val(), stdSelect);
                $('#std-container').hide();
            });




        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('student.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\svps-project\resources\views/student/std_report/relative_wise_report.blade.php ENDPATH**/ ?>