<?php $__env->startSection('sub-content'); ?>
    <div class="container">
        <?php if(Session::has('success')): ?>
            <?php $__env->startSection('scripts'); ?>
                <script>
                    swal("Good job!", "<?php echo e(Session::get('success')); ?>", "success").then(() => {
                        location.reload();
                    });
                </script>
            <?php $__env->stopSection(); ?>
        <?php endif; ?>

        <?php if(Session::has('error')): ?>
            <?php $__env->startSection('scripts'); ?>
                <script>
                    swal("Oops...", "<?php echo e(Session::get('error')); ?>", "error");
                </script>
            <?php $__env->stopSection(); ?>
        <?php endif; ?>
        <div class="row justify-content-center">
            <div class="col-md-14">
                <div class="card">
                    <div class="card-header">
                        <?php echo e('Marks Report'); ?>


                    </div>
                    <div class="card-body">
                        <form id="class-section-form">

                            <div class="row">
                                <div class="form-group col-md-6">
                                    <label for="class_id" class="mt-2">Class <span class="text-danger">*</span></label>
                                    <input type="hidden" id="initialClassId"
                                        value="<?php echo e(old('initialClassId', request()->get('class_id') !== null ? request()->get('class_id') : '')); ?>">
                                    <select name="class" id="class_id"
                                        class="form-control <?php $__errorArgs = ['class'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                        <option value="">Select Class</option>
                                    </select>
                                    <?php $__errorArgs = ['class'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback form-invalid fw-bold"
                                            role="alert"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    <img src="<?php echo e(config('myconfig.myloader')); ?>" alt="Loading..." class="loader"
                                        id="loader" style="display:none; width:10%;">
                                </div>


                                <div class="form-group col-md-6">
                                    <label for="section_id" class="mt-2">Section <span
                                            class="text-danger">*</span></label>
                                    <input type="hidden" id="initialSectionId"
                                        value="<?php echo e(old('initialSectionId', request()->get('section_id') !== null ? request()->get('section_id') : '')); ?>">
                                    <select name="section" id="section_id"
                                        class="form-control <?php $__errorArgs = ['section'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                        <option value="">Select Section</option>

                                    </select>
                                    <?php $__errorArgs = ['section'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback form-invalid fw-bold"
                                            role="alert"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="row">
                                <div class="form-group col-md-4">
                                    <input type="hidden" name="current_session" value='' id="current_session">

                                    <label for="exam_id" class="mt-2">Exam <span class="text-danger">*</span></label>
                                    <input type="hidden" id="initialExamId"
                                        value="<?php echo e(old('initialExamId', request()->get('exam_id') !== null ? request()->get('exam_id') : '')); ?>">
                                    <select name="exam" id="exam_id"
                                        class="form-control <?php $__errorArgs = ['exam'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                        <option value="">Select Exam</option>

                                    </select>
                                    <?php $__errorArgs = ['exam'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback form-invalid fw-bold"
                                            role="alert"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="form-group col-md-4">
                                    <label for="subject_id" class="mt-2">Subject <span
                                            class="text-danger">*</span></label>
                                    <input type="hidden" id="initialSubjectId"
                                        value="<?php echo e(old('initialSubjectId', request()->get('subject_id') !== null ? request()->get('subject_id') : '')); ?>">
                                    <select name="subject[]" id="subject_id"
                                        class="form-control <?php $__errorArgs = ['subject'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" multiple required>
                                        <option value="">All Subject</option>
                                    </select>
                                    <?php $__errorArgs = ['subject'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback form-invalid fw-bold"
                                            role="alert"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                </div>

                                <div class="form-group col-md-4">
                                    <label for="std_id" class="mt-2">Student <span class="text-danger">*</span></label>
                                    <select name="std_id" id="std_id"
                                        class="form-control <?php $__errorArgs = ['std_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                        <option value="">All Students</option>
                                    </select>
                                    <?php $__errorArgs = ['std_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback form-invalid fw-bold"
                                            role="alert"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="mt-3">
                                <button type="button" id="show-details" class="btn btn-primary">
                                    Show Details</button>
                            </div>

                        </form>


                        <div id="std-container" class="mt-4">
                            <form>
                                <table class="table table-responsible">

                                    <thead id="std-table-head">
                                    </thead>
                                    <tbody id="std-table-body">

                                    </tbody>
                                </table>
                                
                                <div class="row">
                                    <div class="mt-3">
                                        <button type="button" class="btn btn-primary" id="export-button">Download
                                            Excel</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('marks-scripts'); ?>
    <script>
        var initialClassId =
            '<?php echo e(old('initialClassId', request()->get('class_id') !== null ? request()->get('class_id') : '')); ?>';
        var initialSectionId =
            '<?php echo e(old('initialSectionId', request()->get('section_id') !== null ? request()->get('section_id') : '')); ?>';
        getClassSection(initialClassId, initialSectionId);
        var initialSubjectId =
            '<?php echo e(old('initialSubjectId', request()->get('subject_id') !== null ? request()->get('subject_id') : '')); ?>';
        getClassSubject(initialClassId, initialSubjectId);
        var initialExamId =
            '<?php echo e(old('initialExamId', request()->get('exam_id') !== null ? request()->get('exam_id') : '')); ?>';
        getExams(initialExamId);

        $(document).ready(function() {
            $('#std-form').hide();
            $('#std-container').hide();
            $('#class-section-form').validate({
                rules: {
                    exam: {
                        required: true,
                    },
                    subject: {
                        required: true,
                    },
                    std: {
                        required: true,
                    },
                    class: {
                        required: true,
                    },
                    section: {
                        required: true,
                    },
                },
                messages: {
                    exam: {
                        required: "Please select a exam.",
                    },
                    subject: {
                        required: "Please select a subject.",
                    },
                    std: {
                        required: "Please select a student.",
                    },
                    class: {
                        required: "Please select a class.",
                    },
                    section: {
                        required: "Please select a section.",
                    },
                },
            });
            var stdSelect = $('#std_id');
            $('#subject_id').select2();
            getStd();
            $('#show-details').on('click', function() {
                if ($('#class-section-form').valid()) {
                    const classId = $('#class_id').val();
                    const sessionId = $('#current_session').val();
                    const exam = $('#exam_id').val();
                    const subject = $('#subject_id').val();
                    const std = stdSelect.val();

                    loader.show();
                    $('#std-container').show();

                    if (classId && sessionId && exam && subject && std) {
                        $('#std-form').show();
                        $.ajax({
                            url: '<?php echo e(route('marks.marks-report.get')); ?>',
                            type: 'GET',
                            dataType: 'JSON',
                            data: {
                                class: classId,
                                session: sessionId,
                                exam: exam,
                                subject: subject,
                                std_id: std,

                            },
                            success: function(data) {
                                let subjects = [];
                                let studentsData = {};

                                // First pass: collect all subjects and initialize student data
                                $.each(data.data, function(index, subjectData) {
                                    subjects.push(subjectData.subject);
                                    $.each(subjectData.students, function(j, student) {
                                        if (!studentsData[student
                                                .roll_number]) {
                                            studentsData[student
                                                .roll_number] = {
                                                name: student.name,
                                                marks: {}
                                            };
                                        }
                                        studentsData[student.roll_number].marks[
                                                subjectData.subject] = student
                                            .marks;
                                    });
                                });

                                // Generate table header
                                let headerHtml = '<tr><th>Student</th>';
                                subjects.forEach(subject => {
                                    headerHtml += `<th>${subject}</th>`;
                                });
                                headerHtml += '<th>Total</th></tr>';
                                $('#std-table-head').html(headerHtml);

                                // Generate table body
                                let bodyHtml = '';
                                Object.keys(studentsData).forEach(rollNumber => {
                                    let student = studentsData[rollNumber];
                                    let totalMarks = 0;
                                    bodyHtml +=
                                        `<tr><td>${rollNumber}. ${student.name}</td>`;
                                    subjects.forEach(subject => {
                                        let mark = student.marks[subject];
                                        totalMarks += (mark == null || mark ==
                                            'N/A') ? 0 : mark;
                                        bodyHtml +=
                                            `<td>${mark == null ? 'N/A' : mark}</td>`;
                                    });
                                    bodyHtml += `<td>${totalMarks}</td></tr>`;
                                });
                                $('#std-table-body').html(bodyHtml);
                            },

                            complete: function() {
                                loader.hide();
                            },
                            error: function(xhr) {
                                console.log(xhr);

                                console.error(xhr.responseText);

                            }
                        });
                    }

                }
            });

            function getExcelReport() {
                const classId = $('#class_id').val();
                const sessionId = $('#current_session').val();
                const exam = $('#exam_id').val();
                const std = $('#std_id').val();
                const subjects = $('#subject_id').val(); 
                // Start with the base URL
                let exportUrl = "<?php echo e(route('marks.marks-report.excel')); ?>?class=" + classId +
                    "&session=" + sessionId +
                    "&exam=" + exam +
                    "&std_id=" + std;

                // Append subjects[] as separate query parameters
                if (subjects && Array.isArray(subjects)) {
                    subjects.forEach(function(subject) {
                        exportUrl += "&subject[]=" + subject;
                    });
                }

                // Redirect to the export URL
                window.location.href = exportUrl;
            }


            $('#export-button').on('click', function() {
                getExcelReport();
            });

        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('marks.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\svps-project\resources\views/marks/marks_entry/report.blade.php ENDPATH**/ ?>