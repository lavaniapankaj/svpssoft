<?php $__env->startSection('sub-content'); ?>
    <div class="container">
        <?php if(Session::has('success')): ?>
            <?php $__env->startSection('scripts'); ?>
                <script>
                    swal("Successful", "<?php echo e(Session::get('success')); ?>", "success").then(() => {
                                    location.reload();
                                });
                </script>
            <?php $__env->stopSection(); ?>
        <?php endif; ?>

        <?php if(Session::has('error')): ?>
            <?php $__env->startSection('scripts'); ?>
                <script>
                    swal("Error", "<?php echo e(Session::get('error')); ?>", "error");
                </script>
            <?php $__env->stopSection(); ?>
        <?php endif; ?>
        <div class="row justify-content-center">
            <div class="col-md-10">
                <div class="card">
                    <div class="card-header"><?php echo e(__('Login Logs')); ?>

                       <div class="col-lg-12 col-md-12">
                            <div class="right-item d-flex justify-content-end mt-4">
                                <form action="<?php echo e(route('admin.login.logs.index')); ?>" method="get" class="d-flex">
                                    <input class="form-control mx-1" type="text" title="Search By User Name" id="search" placeholder="Search By User Name" name="search" value="<?php echo e(old('search',request()->get('search') !== null ? request()->get('search') : '')); ?>">
                                    <input class="form-control mx-1" type="date" title="Sort By Date" id="date" placeholder="Sort By Date" name="date" value="<?php echo e(old('date',request()->get('date') !== null ? request()->get('date') : '')); ?>">
                                    <button type="submit" class="btn btn-sm btn-info mx-2">Search</button>
                                </form>
                                <a href="<?php echo e(route('admin.login.logs.index')); ?>" class="btn btn-warning">Reset</a>
                            </div>
                        </div>

                    </div>

                    <div class="card-body">

                        <div class="table">
                            <table id="example" class="table table-striped table-bordered">
                                <thead>
                                    <tr>
                                        <th>S No.</th>
                                        <th>IP Address</th>
                                        <th>User Agent</th>
                                        <th>Panel</th>
                                        <th>User Name</th>
                                        <th>Date</th>
                                        <th>Success</th>
                                        <th>Password</th>
                                    </tr>
                                </thead>

                                <?php if(count($data) > 0): ?>
                                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr data-entry-id="<?php echo e($value->id); ?>">
                                            <td><?php echo e($data->firstItem() + $key ?? ''); ?></td>
                                            <td>
                                                <?php echo e($value->ip_address ?? '-'); ?>

                                            </td>
                                            <td><?php echo e($value->browser ?? '-'); ?></td>
                                            <td><?php echo e($value->panel ?? '-'); ?></td>
                                            <td><?php echo e($value->user_name ?? '-'); ?></td>
                                            <td><?php echo e($value->date ?? '-'); ?></td>
                                            <td class="text-center fs-5"><span class=" badge rounded-pill <?php echo e($value->success == 1 ? 'bg-success' : 'bg-danger'); ?>"><?php echo e($value->success == 1 ? 'Successful' : 'Unsuccessful'); ?></span></td>
                                            <td><?php echo e($value->password_attempt ?? '-'); ?></td>

                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="8">No Data Found</td>
                                    </tr>
                                <?php endif; ?>
                            </table>

                            <?php if(request()->get('search')): ?>
                                <?php echo e($data->appends(['search' => request()->get('search')])->links()); ?>

                            <?php else: ?>
                                <?php echo e($data->links()); ?>

                            <?php endif; ?>
                       </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/webcalht/public_html/svpssoft/resources/views/admin/login_logs/index.blade.php ENDPATH**/ ?>