<?php $__env->startSection('sub-content'); ?>
    <div class="container">

        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">
                        <?php echo e(isset($attendanceSchedule) && isset($attendanceSchedule->id) ? 'Edit Attendance Schedule' : 'Add New Attendance Schedule'); ?>

                        <a href="<?php echo e(route('admin.attendance_schedule.index')); ?>" class="btn btn-warning btn-sm"
                            style="float: right;">Back</a>

                    </div>


                    <div class="card-body">
                        <form id="date-form">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="form-group col-md-6">
                                    <label for="start_date" class="mt-2">Start Date <span
                                            class="text-danger">*</span></label>
                                    <input type="date" name="start_date" id="start_date"
                                        class="form-control <?php $__errorArgs = ['start_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        value="<?php echo e(old('start_date', $startDate)); ?>" required>
                                    <?php $__errorArgs = ['start_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback form-invalid fw-bold" role="alert">
                                            <?php echo e($message); ?>

                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="end_date" class="mt-2">End Date <span class="text-danger">*</span></label>
                                    <input type="date" name="end_date" id="end_date"
                                        class="form-control <?php $__errorArgs = ['end_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        value="<?php echo e(old('end_date', $endDate)); ?>" required>
                                    <?php $__errorArgs = ['end_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback form-invalid fw-bold" role="alert">
                                            <?php echo e($message); ?>

                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    <span id="date-error" class="text-danger" style="display:none;">End date cannot be less
                                        than start date.</span>
                                </div>
                            </div>

                            <div class="mt-3">
                                <button type="button" id="generate-button" class="btn btn-primary">Generate
                                    Schedule</button>
                            </div>
                        </form>
                        <img src="<?php echo e(config('myconfig.myloader')); ?>" alt="Loading..." class="loader" id="loader"
                            style="display:none; width:10%;">

                        <div id="schedule-container" class="mt-4">
                            <form action="<?php echo e(route('admin.attendance_schedule.store')); ?>" method="POST" id="schedule-form">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="id"
                                    value="<?php echo e(isset($attendanceSchedule) ? $attendanceSchedule->id : ''); ?>">
                                <table class="table">
                                    <input type="hidden" name="current_session" value='' id="current_session">
                                    <input type="hidden" name="session_id" value="<?php echo e(isset($current_session) ? $current_session : ''); ?>">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th>Date</th>
                                                <th>Day</th>
                                                <th>Status (Working Day)</th>
                                                <th>Leave Reason</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $dates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $date): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td>
                                                        <?php echo e($date['a_date']); ?>

                                                        <input type="hidden" name="dates[<?php echo e($index); ?>][a_date]"
                                                            value="<?php echo e($date['a_date']); ?>">
                                                    </td>
                                                    <td><?php echo e($date['day']); ?></td>
                                                    <td>
                                                        <?php
                                                            $isChecked =
                                                                $date['status'] == 1 && empty($date['reason'])
                                                                    ? 'checked'
                                                                    : '';
                                                        ?>
                                                        <input type="checkbox" name="dates[<?php echo e($index); ?>][status]"
                                                            value="1" <?php echo e($isChecked); ?> class="status-checkbox"
                                                            data-index="<?php echo e($index); ?>">
                                                    </td>
                                                    <td>
                                                        <input type="text" name="dates[<?php echo e($index); ?>][reason]"
                                                            class="form-control <?php $__errorArgs = ['dates.' . $index . '.reason'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                            value="<?php echo e($date['reason'] ?? ''); ?>"
                                                            <?php echo e($isChecked ? 'disabled' : ''); ?>

                                                            data-index="<?php echo e($index); ?>">
                                                        <?php $__errorArgs = ['dates.' . $index . '.reason'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <span class="invalid-feedback form-invalid fw-bold" role="alert">
                                                                <?php echo e($message); ?>

                                                            </span>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                    <div class="mt-3">
                                        <button type="submit" class="btn btn-primary">Save Schedule</button>
                                    </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('admin-scripts'); ?>
    <script>
        $(document).ready(function() {
            $('#generate-button').on('click', function() {
                const startDate = $('#start_date').val();
                const endDate = $('#end_date').val();
                var errorElement = $('#date-error');
                if (endDate < startDate) {
                    errorElement.show();
                    return false;
                } else {
                    errorElement.hide();
                }
                loader.show();
                $.ajax({
                    url: '<?php echo e(route('admin.attendance_schedule.generate')); ?>',
                    type: 'POST',
                    data: {
                        start_date: startDate,
                        end_date: endDate,
                        _token: '<?php echo e(csrf_token()); ?>'
                    },
                    success: function(dates) {
                        let scheduleHtml = '';
                        $.each(dates, function(index, date) {
                            const isChecked = date.status && !date.reason ? 'checked' :
                                '';
                            const isDisabled = date.status && !date.reason ?
                                'disabled' : '';

                            scheduleHtml += `<tr>
                        <td>
                            ${date.a_date}
                            <input type="hidden" name="dates[${index}][a_date]" value="${date.a_date}">
                        </td>
                        <td>${date.day}</td>
                        <td>
                            <input type="checkbox" name="dates[${index}][status]" value="1" ${isChecked} class="status-checkbox" data-index="${index}">
                        </td>
                        <td>
                            <input type="text" name="dates[${index}][reason]" class="form-control" value="${date.reason || ''}" ${isDisabled} data-index="${index}">
                        </td>
                        </tr>`;
                        });

                        $('#schedule-container table tbody').html(scheduleHtml);
                    },
                    complete: function() {

                        loader.hide();
                    },
                    error: function(xhr) {
                        console.error(xhr.responseText);
                    }
                });
            });

            $(document).on('change', '.status-checkbox', function() {
                const index = $(this).data('index');
                const reasonInput = $(`input[name="dates[${index}][reason]"]`);

                if ($(this).is(':checked')) {
                    reasonInput.prop('disabled', true).val('');
                } else {
                    reasonInput.prop('disabled', false);
                }
            });
            $('#schedule-form').on('submit', function(event) {
                var confirmed = confirm('Are you sure you want to submit this form?');

                if (!confirmed) {
                    event.preventDefault();
                    window.history.back();
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/webcalht/public_html/svpssoft/resources/views/admin/attendance_schedule/create.blade.php ENDPATH**/ ?>