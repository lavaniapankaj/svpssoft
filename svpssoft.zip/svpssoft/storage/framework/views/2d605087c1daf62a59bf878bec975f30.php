<?php $__env->startSection('sub-content'); ?>
    <div class="container">
        <?php if(Session::has('success')): ?>
            <?php $__env->startSection('scripts'); ?>
                <script>
                    swal("Successful", "<?php echo e(Session::get('success')); ?>", "success").then(() => {
                        location.reload();
                    });
                </script>
            <?php $__env->stopSection(); ?>
        <?php endif; ?>

        <?php if(Session::has('error')): ?>
            <?php $__env->startSection('scripts'); ?>
                <script>
                    swal("Error", "<?php echo e(Session::get('error')); ?>", "error").then(() => {
                        location.reload();
                    });
                </script>
            <?php $__env->stopSection(); ?>
        <?php endif; ?>
        <div class="row justify-content-center">
            <div class="col-md-14">
                <div class="card">
                    <div class="card-header">
                        <?php echo e('Update Mobile No.'); ?>

                        <a href="<?php echo e(route('student.updateMobile.index')); ?>" class="btn btn-warning btn-sm"
                            style="float: right;">Back</a>

                    </div>
                    <div class="card-body">
                        <form id="st-form" action="<?php echo e(route('student.updateMobile.store')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="form-group col-md-4">
                                    <label for="class_id" class="mt-2">Class <span class="text-danger">*</span></label>
                                    <select name="class" id="class_id"
                                        class="form-control <?php $__errorArgs = ['class'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                        <option value="">Select Class</option>
                                        <?php if(count($classes) > 0): ?>
                                            <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($key); ?>" <?php echo e(old('class') == $key ? 'selected' : ''); ?>><?php echo e($class); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php else: ?>
                                            <option value="">No Class Found</option>
                                        <?php endif; ?>
                                    </select>
                                    <span class="text-danger fw-bold class-error" role="alert"></span>
                                    <?php $__errorArgs = ['class'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback form-invalid fw-bold"
                                            role="alert"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    <img src="<?php echo e(config('myconfig.myloader')); ?>" alt="Loading..." class="loader"
                                        id="loader" style="display:none; width:10%;">
                                </div>


                                <div class="form-group col-md-4">
                                    <label for="section_id" class="mt-2">Section <span
                                            class="text-danger">*</span></label>
                                    <input type="hidden" id="initialSectionId"
                                        value="<?php echo e(old('section')); ?>">
                                    <select name="section" id="section_id"
                                        class="form-control <?php $__errorArgs = ['section'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                        <option value="">Select Section</option>

                                    </select>
                                    <span class="text-danger fw-bold section-error" role="alert"></span>
                                    <input type="hidden" name="current_session" value='' id="current_session">
                                    <?php $__errorArgs = ['section'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback form-invalid fw-bold"
                                            role="alert"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="form-group col-md-4">
                                    <label for="std_id" class="mt-2">Student <span class="text-danger">*</span></label>
                                    <select name="std_id" id="std_id"
                                        class="form-control <?php $__errorArgs = ['std_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                        <option value="">Select Student</option>
                                    </select>
                                    <span class="text-danger fw-bold st-error" role="alert"></span>
                                    <?php $__errorArgs = ['std_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback form-invalid fw-bold"
                                            role="alert"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="row">
                                <div class="form-group col-md-6">
                                    <label for="f_mobile" class="mt-2">Enter Father's Mob. No. <span
                                            class="text-danger">*</span></label>
                                    <input type="text" name="f_mobile" id="f_mobile"
                                        class="form-control <?php $__errorArgs = ['f_mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                    <span class="text-danger fw-bold f-mobile-error" role="alert"></span>
                                    <?php $__errorArgs = ['f_mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback form-invalid fw-bold"
                                            role="alert"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="m_mobile" class="mt-2">Enter Mother's Mob. No. <span
                                            class="text-danger">*</span></label>
                                    <input type="text" name="m_mobile" id="m_mobile"
                                        class="form-control <?php $__errorArgs = ['m_mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                    <span class="text-danger fw-bold m-mobile-error" role="alert"></span>
                                    <?php $__errorArgs = ['m_mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback form-invalid fw-bold"
                                            role="alert"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="mt-3">
                                <button type="submit" id="update-btn" class="btn btn-primary">Update</button>
                            </div>

                        </form>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('std-scripts'); ?>
    <script>

        $(document).ready(function() {
            let initialClassId = $('#class_id').val();
            let initialSectionId = $('#initialSectionId').val();
            getClassSection(initialClassId, initialSectionId);
            var loader = $('#loader');

            $('#section_id').change(function() {
                var classId = $('#class_id').val();
                var sectionId = $(this).val();
                var sessionId = $('#current_session').val();
                var stdSelect = $('#std_id');
                var fMobile = $('#f_mobile');
                var mMobile = $('#m_mobile');
                if (classId && sectionId && sessionId) {
                    loader.show();
                    $.ajax({
                        url: '<?php echo e(route('stdNameFather.get')); ?>',
                        type: 'GET',
                        dataType: 'JSON',
                        data: {
                            class_id: classId,
                            section_id: sectionId,
                            session_id: sessionId,
                        },
                        success: function(students) {
                            stdSelect.empty();

                            let options = '<option value="">Select Student</option>';

                            if (students.length > 0) {
                                $.each(students, function(index, student) {
                                    options += '<option value="' + student.srno + '">' +
                                        student.rollno + '. ' + student.student_name +
                                        '/' +
                                        student.f_name + '</option>';

                                });
                                stdSelect.change(function() {
                                    var st = students.filter(student => student.srno ===
                                        stdSelect.val());
                                    // console.log(st);
                                    $.each(st, function(index, std) {
                                        fMobile.val(std.f_mobile);
                                        mMobile.val(std.m_mobile);
                                    });

                                });
                            } else {
                                options += '<option value="">No student found</option>';
                            }

                            stdSelect.html(options);
                        },
                        complete: function() {
                            loader.hide();
                        },
                        error: function(xhr) {
                            console.error(xhr.responseText);
                        }
                    });
                }
            });
            $('#update-btn').on('click', function() {
                $('#st-form').validate();
                $('.f-mobile-error, .m-mobile-error').hide();

                var regex = /^[0-9]{10}$/;

                function validateMobileInput(input, errorClass) {
                    var value = $(input).val();
                    if (value === '') {
                        $(errorClass).hide();
                    } else if (!regex.test(value)) {
                        $(errorClass).show().html('Please Enter a valid Phone Number');
                    } else {
                        $(errorClass).hide();
                    }
                }

                 $('#f_mobile').on('input', function() {
                    validateMobileInput(this, '.f-mobile-error');
                });

                $('#m_mobile').on('input', function() {
                   // validateMobileInput(this, '.m-mobile-error');
                   if ($(this) == '') {
                        $('.m-mobile-error').hide().html('');
                   }
                   $('.m-mobile-error').show().html('Please Enter a valid Phone Number');
                });

                $('.f-mobile-error, .m-mobile-error').each(function() {
                    if ($(this).is(':visible')) {
                        $(this).hide().html('');
                    }
                });
            });



        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('student.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/webcalht/public_html/svpssoft/resources/views/student/update_mobile/index.blade.php ENDPATH**/ ?>