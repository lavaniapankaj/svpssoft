<?php $__env->startSection('sub-content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <?php echo e('Print Report Exam Wise'); ?>

                        <a href="<?php echo e(route('marks.marksheet')); ?>" class="btn btn-warning btn-sm" style="float: right;">Back</a>
                    </div>
                    <div class="card-body">
                        <form id="class-section-form">
                            <div class="row">
                                <div class="form-group col-md-4">
                                    <input type="hidden" name="current_session" value='' id="current_session">
                                    <label for="class_id" class="mt-2">Class <span class="text-danger">*</span></label>
                                    <input type="hidden" id="initialClassId"
                                        value="<?php echo e(old('initialClassId', request()->get('class_id') !== null ? request()->get('class_id') : '')); ?>">
                                    <select name="class" id="class_id"
                                        class="form-control <?php $__errorArgs = ['class'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                        <option value="">Select Class</option>
                                    </select>
                                    <?php $__errorArgs = ['class'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback form-invalid fw-bold"
                                            role="alert"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    <img src="<?php echo e(config('myconfig.myloader')); ?>" alt="Loading..." class="loader"
                                        id="loader" style="display:none; width:10%;">
                                </div>
                                <div class="form-group col-md-4">
                                    <label for="section_id" class="mt-2">Section <span
                                            class="text-danger">*</span></label>
                                    <input type="hidden" id="initialSectionId"
                                        value="<?php echo e(old('initialSectionId', request()->get('section_id') !== null ? request()->get('section_id') : '')); ?>">
                                    <select name="section" id="section_id"
                                        class="form-control <?php $__errorArgs = ['section'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                        <option value="">Select Section</option>

                                    </select>
                                    <?php $__errorArgs = ['section'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback form-invalid fw-bold"
                                            role="alert"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="form-group col-md-4">
                                    <label for="std_id" class="mt-2">Student <span class="text-danger">*</span></label>
                                    <select name="std_id" id="std_id"
                                        class="form-control <?php $__errorArgs = ['std_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                        <option value="">All Students</option>
                                    </select>
                                    <?php $__errorArgs = ['std_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback form-invalid fw-bold"
                                            role="alert"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="row">
                                <div class="form-group col-md-6">
                                    <label for="result-date-message" class="mt-2">Result Date Message <span
                                            class="text-danger">*</span></label>
                                    <input type="text" name="result_date_message" value="" id="result-date-message"
                                        class="form-control">
                                    <span class="invalid-feedback form-invalid fw-bold result-date-message-error"
                                        role="alert"></span>
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="session-start-message" class="mt-2">Session Start Message<span
                                            class="text-danger">*</span></label>
                                    <input type="text" name="session_start_message" value=""
                                        id="session-start-message" class="form-control">
                                    <span class="invalid-feedback form-invalid fw-bold session-start-message-error"
                                        role="alert"></span>
                                </div>
                            </div>
                            <div class="mt-3">
                                <button type="button" id="show-details" class="btn btn-primary">
                                    Show Details</button>
                            </div>

                        </form>
                        <div class="row">
                            <div class="marksheet-div">
                                <div class="marksheet">

                                </div>
                                <div class="mt-3">
                                    <button type="button" id="print-marksheet" class="btn btn-primary">Print
                                        Marksheet</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('marks-scripts'); ?>
    <script>
        $(document).ready(function() {
            let initialClassId = $('#initialClassId').val();
            let initialSectionId = $('#initialSectionId').val();
            getClassSection(initialClassId, initialSectionId);
            getStd();

            function marksheetPrint() {
                let marksheetDiv = $('.marksheet-div');
                marksheetDiv.hide();
                $('#class-section-form').validate({
                    rules: {
                        exam: {
                            required: true,
                        },
                        std_id: {
                            required: true,
                        },
                        class: {
                            required: true,
                        },
                        section: {
                            required: true,
                        },
                    },
                    messages: {
                        exam: {
                            required: "Please select a exam.",
                        },
                        std_id: {
                            required: "Please select at least a student.",
                        },
                        class: {
                            required: "Please select a class.",
                        },
                        section: {
                            required: "Please select a section.",
                        },
                    },
                });

                $('#show-details').click(function() {
                    if ($('#class-section-form').valid()) {
                        let classId = $('#class_id').val();
                        let sectionId = $('#section_id').val();
                        let sessionMessage = $('#session-start-message').val();
                        let dateMessage = $('#result-date-message').val();
                        let stdId = $('#std_id').val();

                        marksheetDiv.show();

                        $.ajax({
                            url: siteUrl + '/marks/marksheet-final-pg-nursary/report',
                            type: 'GET',
                            dataType: 'JSON',
                            data: {
                                class: classId,
                                section: sectionId,
                                std_id: stdId,
                                sessionMessage: sessionMessage,
                                dateMessage: dateMessage,
                            },
                            // success: function(response) {
                            //     if (response) {
                            //         let tableHtml = `
                        //                             <div class="container mt-4">
                        //                                 <!-- Header -->
                        //                                 <div class="text-center mb-4">
                        //                                     <img src="/api/placeholder/60/60" alt="School Logo" class="mb-2">
                        //                                     <h2 class="fst-italic">St. Vivekanand Play House</h2>
                        //                                     <h6 class="fw-normal">(English Medium)</h6>
                        //                                     <p class="mb-1 small">Vivekanand Chowk, Chirawa, 01596 - 220877</p>
                        //                                     <p class="small">Session : ${response.session}</p>
                        //                                 </div>`;

                            //         response.students.forEach(student => {
                            //             // Extract student details
                            //             const studentInfo = student.student_details;
                            //             const subjectMarks = student.subject_marks;
                            //             const totalMarks = student.total_marks;
                            //             const attendance = student.attendance;
                            //             const result = student.result_data;
                            //             tableHtml += `
                        //                     <div class="row g-0 mb-3">
                        //                         <div class="col-2 pe-2">
                        //                             <p class="mb-1">Name of Student :</p>
                        //                             <p class="mb-1">Father's Name :</p>
                        //                             <p class="mb-1">Class :</p>
                        //                             <p class="mb-1">Section :</p>
                        //                         </div>
                        //                         <div class="col-4">
                        //                             <p class="mb-1">${studentInfo.name}</p>
                        //                             <p class="mb-1">SH. ${studentInfo.father_name}</p>
                        //                             <p class="mb-1">${studentInfo.class}</p>
                        //                             <p class="mb-1">${studentInfo.section}</p>
                        //                         </div>
                        //                         <div class="col-2 pe-2">
                        //                             <p class="mb-1">S.R.No. :</p>
                        //                             <p class="mb-1"></p>
                        //                             <p class="mb-1">Date of Birth :</p>
                        //                             <p class="mb-1">Roll No. :</p>
                        //                         </div>
                        //                         <div class="col-4">
                        //                             <p class="mb-1">${studentInfo.sr_no}</p>
                        //                             <p class="mb-1"></p>
                        //                             <p class="mb-1"> ${studentInfo.dob}</p>
                        //                             <p class="mb-1">${studentInfo.roll_no}</p>
                        //                         </div>
                        //                     </div>
                        //                     <!-- Main Content -->
                        //                             <div class="row g-0">
                        //                                 <!-- Marks Table -->
                        //                                 <div class="col-8">
                        //                                     <table class="table table-bordered border-dark mb-0">
                        //                                         <thead>
                        //                                             <tr>
                        //                                                 <th class="fw-normal" style="width: 25%">Subject</th>
                        //                                                 <th class="fw-normal text-center">First Terminal Examination
                        //                                                 </th>
                        //                                                 <th class="fw-normal text-center">Grand Total</th>
                        //                                             </tr>
                        //                                         </thead>
                        //                                         <tbody>
                        //             `;
                            //             subjectMarks.map(subject => {

                            //                 tableHtml += `
                        //                                <tr>
                        //                                    <td>${subject.subject_name}</td>
                        //                                    <td class="text-center">${subject.total_max}</td>
                        //                                    <td class="text-center">${subject.total_obtained}</td>
                        //                                </tr>
                        //                    `;
                            //             }

                            //             );
                            //              tableHtml +=
                            //                         ` </tbody>
                        //                                     </table>
                        //                                 </div>
                        //                                    <!-- Right Side -->
                        //                                     <div class="col-4 d-flex">
                        //                                         <!-- Attendance -->
                        //                                         <div
                        //                                             class="border-dark border-top-1 border border-bottom-1 col-4 align-content-center text-center">
                        //                                             <p class="fw-bold mb-1 text-decoration-underline">Attendance</p>
                        //                                             <p class="mb-1">Attended</p>
                        //                                             <p class="mb-1 text-decoration-underline">${attendance.days_present}</p>
                        //                                             <p class="mb-1">${attendance.total_days}</p>
                        //                                             <p class="mb-1 text-decoration-underline">Result</p>
                        //                                             <p class="mb-1">${result.result}</p>
                        //                                             <p class="mb-1">${result.result_date_message}</p>
                        //                                             <p class="mb-1">${result.session_start_message}</p>
                        //                                         </div>

                        //                                         <!-- Grade Table -->

                        //                                         <table class="table table-bordered border-dark mb-0">
                        //                                             <tr>
                        //                                                 <td class="p-1 text-center">Abst</td>
                        //                                                 <td class="p-1 text-center">A</td>
                        //                                             </tr>
                        //                                             <tr>
                        //                                                 <td class="p-1 text-center">Abst</td>
                        //                                                 <td class="p-1 text-center">A</td>
                        //                                             </tr>
                        //                                             <tr>
                        //                                                 <td class="p-1 text-center">Abst</td>
                        //                                                 <td class="p-1 text-center">A+</td>
                        //                                             </tr>
                        //                                             <tr>
                        //                                                 <td class="p-1 text-center">Abst</td>
                        //                                                 <td class="p-1 text-center">A+</td>
                        //                                             </tr>
                        //                                             <tr>
                        //                                                 <td class="p-1 text-center">Abst</td>
                        //                                                 <td class="p-1 text-center">A+</td>
                        //                                             </tr>
                        //                                             <tr>
                        //                                                 <td class="p-1 text-center">Abst</td>
                        //                                                 <td class="p-1 text-center">A+</td>
                        //                                             </tr>
                        //                                             <tr>
                        //                                                 <td class="p-1 text-center">Abst</td>
                        //                                                 <td class="p-1 text-center">A+</td>
                        //                                             </tr>
                        //                                         </table>
                        //                                     </div>
                        //                                 </div>

                        //                                 <!-- Signatures -->
                        //                                 <div class="row mt-5 pt-4">
                        //                                     <div class="col-4 text-center">
                        //                                         <div class="border-top border-dark pt-2">Sign of Class Teacher</div>
                        //                                     </div>
                        //                                     <div class="col-4 text-center">
                        //                                         <div class="border-top border-dark pt-2">Sign of Checker</div>
                        //                                     </div>
                        //                                     <div class="col-4 text-center">
                        //                                         <div class="border-top border-dark pt-2">Sign of Principal</div>
                        //                                     </div>
                        //                                 </div>
                        //                             </div>
                        //                         `;
                            //         });

                            //         $('.marksheet').html(tableHtml);
                            //     } else {
                            //         $('.marksheet').html(
                            //             '<p>No data available for the selected criteria.</p>'
                            //         );
                            //     }
                            // },
                            success: function(response) {
                                if (response) {
                                    // Start constructing the table HTML
                                    let tableHtml = '';

                                    // Loop through each student
                                    response.students.forEach(student => {
                                        // Header HTML, move inside the loop
                                        tableHtml += `
                                            <div class="container mt-4 marksheet-container">
                                                <!-- Header -->
                                                <div class="text-center mb-4">
                                                    <img src="${student.logo.school_logo}" alt="School Logo" class="mb-2">
                                                    <h2 class="fst-italic">St. Vivekanand Play House</h2>
                                                    <h6 class="fw-normal">(English Medium)</h6>
                                                    <p class="mb-1 small">Vivekanand Chowk, Chirawa, 01596 - 220877</p>
                                                    <p class="small">Session : ${response.session}</p>
                                                </div>`;

                                        // Extract student details
                                        const studentInfo = student.student_details;
                                        const subjectMarks = student.subject_marks;
                                        const totalMarks = student.total_marks;
                                        const attendance = student.attendance;
                                        const result = student.result_data;

                                        tableHtml += `
                                            <div class="row g-0 mb-3">
                                                <div class="col-2 pe-2">
                                                    <p class="mb-1">Name of Student :</p>
                                                    <p class="mb-1">Father's Name :</p>
                                                    <p class="mb-1">Class :</p>
                                                    <p class="mb-1">Section :</p>
                                                </div>
                                                <div class="col-4">
                                                    <p class="mb-1">${studentInfo.name}</p>
                                                    <p class="mb-1">SH. ${studentInfo.father_name}</p>
                                                    <p class="mb-1">${studentInfo.class}</p>
                                                    <p class="mb-1">${studentInfo.section}</p>
                                                </div>
                                                <div class="col-2 pe-2">
                                                    <p class="mb-1">S.R.No. :</p>
                                                    <p class="mb-1"></p>
                                                    <p class="mb-1">Date of Birth :</p>
                                                    <p class="mb-1">Roll No. :</p>
                                                </div>
                                                <div class="col-4">
                                                    <p class="mb-1">${studentInfo.sr_no}</p>
                                                    <p class="mb-1"></p>
                                                    <p class="mb-1">${studentInfo.dob}</p>
                                                    <p class="mb-1">${studentInfo.roll_no}</p>
                                                </div>
                                            </div>
                                            <!-- Main Content -->
                                            <div class="row g-0 d-flex align-items-stretch">
                                                <!-- Marks Table -->
                                                <div class="col-8 table-responsive align-items-stretch">
                                                    <table class="table table-bordered border-dark mb-0 h-100">
                                                        <thead>
                                                            <tr>
                                                                <th class="fw-normal" style="width: 25%">Subject</th>
                                                                <th class="fw-normal text-center">First Terminal Examination</th>
                                                                <th class="fw-normal text-center">Grand Total</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>`;

                                        subjectMarks.forEach(subject => {
                                            tableHtml += `
                                                <tr>
                                                    <td>${subject.subject_name}</td>
                                                    <td class="text-center">${subject.total_max}</td>
                                                    <td class="text-center">${subject.total_obtained}</td>
                                                </tr>`;
                                        });

                                        tableHtml += `</tbody>
                                                    </table>
                                                </div>
                                                <!-- Right Side -->
                                                <div class="col-4 d-flex align-content-center align-items-stretch">
                                                    <!-- Attendance -->
                                                    <div class="border-dark border-top-1 border border-bottom-1 col-4  text-center">
                                                        <p class="fw-bold mb-1 text-decoration-underline">Attendance</p>
                                                        <p class="mb-1">Attended</p>
                                                        <p class="mb-1 text-decoration-underline">${attendance.days_present}</p>
                                                        <p class="mb-1">${attendance.total_days}</p>
                                                        <p class="mb-1 text-decoration-underline">Result</p>
                                                        <p class="mb-1">${result.result}</p>
                                                        <p class="mb-1">${result.result_date_message}</p>
                                                        <p class="mb-1">${result.session_start_message}</p>
                                                    </div>
                                                    <!-- Grade Table -->
                                                    <table class="table table-bordered border-dark mb-0">
                                                `;
                                        subjectMarks.forEach(subject => {
                                            tableHtml += `
                                                            <tr><td class="p-1 text-center">Abst</td><td class="p-1 text-center">${subject.total_obtained}</td></tr>
                                                           `;
                                        });

                                        tableHtml += `
                                                        </table>
                                                        </div>
                                                    </div>
                                                    <!-- Signatures -->
                                                        <div class="row pt-2">
                                                            <div class="col-4 text-center align-content-end">
                                                                <p class="mb-2"></p>
                                                                <div class="border-top border-dark pt-2">Sign of Class Teacher</div>
                                                            </div>
                                                            <div class="col-4 text-center align-content-end">
                                                                <p class="mb-2"></p>
                                                                <div class="border-top border-dark pt-2">Sign of Checker</div>
                                                            </div>
                                                            <div class="col-4 text-center align-content-end">
                                                                <img src="${student.logo.principal_sign}" alt="School Logo" class="mb-2" style="height:35px;">
                                                                <div class="border-top border-dark pt-2">Sign of Principal</div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                `;
                                    });

                                    // Append the final table HTML to the .marksheet container
                                    $('.marksheet').html(tableHtml);
                                }
                                else {
                                    $('.marksheet').html(
                                        '<p>No data available for the selected criteria.</p>'
                                    );
                                }
                            },

                            complete: function() {
                                $('#loader').hide();
                            },
                            error: function(xhr) {
                                console.log('Error:', xhr);
                                console.error(xhr.responseText);
                            }
                        });
                    }
                });



                $('#print-marksheet').click(function() {
    const printContainer = $('<div>').addClass('print-wrapper');

    // Clone only visible marksheets
    $('.marksheet .marksheet-container').each(function() {
        const clone = $(this).clone(true);
        printContainer.append(clone);
    });

    const printStyles = `
        <style type="text/css" media="print">
    @media print {
        @page {
            size: A4 landscape;
            margin: 0.5cm;
            break-inside: avoid;
        }

        body {
            margin: 0;
            padding: 0;
        }

        body * {
            visibility: hidden;
        }

        .print-wrapper, .print-wrapper * {
            visibility: visible;
        }

        .print-wrapper {
            position: absolute;
            left: 0;
            top: 0;
            width: 100%;
            height: auto;
            overflow: visible;
        }

        .marksheet-container {
            page-break-inside: avoid;
            break-inside: avoid;
            margin: auto;
            padding: 8px;
            width: 100%;
            display: block;
            position: relative;
        }

        .marksheet-container:last-child {
            page-break-after: avoid;
        }

        .row {
            margin: 0 !important;
            display: flex;
            width: 100%;
        }

        .container {
            max-width: none;
            padding: 0;
            margin: 0;
            width: 100%;
        }

        .small {
            font-size: 0.85em !important;
        }

        /* Clear floats after each marksheet */
        .marksheet-container::after {
            content: "";
            display: table;
            clear: both;
        }

        /* Hide any empty space after content */
        .marksheet-container ~ div:empty {
            display: none;
        }
    }
</style>`;

    // Clean up any existing print styles
    $('head style[media="print"]').remove();

    // Add new print styles
    $('head').append(printStyles);

    // Remove any existing print wrapper
    $('.print-wrapper').remove();

    // Add new print wrapper
    $('body').append(printContainer);

    // Trigger print
    window.print();

    // Cleanup after printing
    setTimeout(() => {
        printContainer.remove();
        $('head style[media="print"]').remove();
    }, 1000);
});

            }
            marksheetPrint();
            $('#class_id, #section_id, #exam_id, #std_id').change(function() {
                let marksheetDiv = $('.marksheet-div');
                marksheetDiv.hide();
            });

        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('marks.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\svps-project\resources\views/marks/marksheet/marksheet_final_pg_nur.blade.php ENDPATH**/ ?>