<?php $__env->startSection('sub-content'); ?>
    <div class="container">

        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card">
                        <div class="card-header">
                            <?php echo e(isset($fee) && isset($fee->id) ? 'Edit Transport Fee' : 'Add New Transport Fee'); ?>

                            <a href="<?php echo e(route('admin.transport-fee-master.index')); ?>" class="btn btn-warning btn-sm"
                                    style="float: right;">Back</a>

                        </div>

                        <div class="card-body">
                            <form action="<?php echo e(route('admin.transport-fee-master.store')); ?>" method="POST"
                                enctype="multipart/form-data" id="basic-form">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="id" id="id"
                                    value="<?php echo e(isset($fee) ? $fee->id : ''); ?>">

                                <div class="row">
                                    <div class="form-group col-md-6">
                                        <label for="class_id" class="mt-2">Class <span
                                                class="text-danger">*</span></label>
                                        <input type="hidden" id="initialClassId"
                                            value="<?php echo e(isset($fee) ? $fee->class_id : ''); ?>">
                                        <select name="class_id" id="class_id"
                                            class="form-control <?php $__errorArgs = ['class_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                            <option value="">Select Class</option>
                                        </select>
                                        <?php $__errorArgs = ['class_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback form-invalid fw-bold" role="alert">
                                                <?php echo e($message); ?>

                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="form-group col-md-6">
                                        <label for="section_id" class="mt-2">Section<span
                                                class="text-danger">*</span></label>
                                        <input type="hidden" id="initialSectionId"
                                            value="<?php echo e(isset($fee) ? $fee->section_id : ''); ?>">
                                        <select name="section_id" id="section_id"
                                            class="form-control <?php $__errorArgs = ['section_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                            <option value="">Select Section</option>
                                        </select>
                                        <?php $__errorArgs = ['section_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback form-invalid fw-bold" role="alert">
                                                <?php echo e($message); ?>

                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <img src="<?php echo e(config('myconfig.myloader')); ?>" alt="Loading..." class="loader"
                                        id="loader" style="display:none; width:10%;">
                                </div>
                                <div class="row">

                                    <div class="form-group col-md-6">
                                        <input type="hidden" name="current_session" value='' id="current_session">
                                        <label for="std_id" class="mt-2">Student<span
                                                class="text-danger">*</span></label>
                                        <select name="std_id" id="std_id"
                                            class="form-control <?php $__errorArgs = ['std_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                            <option value="">Select Student</option>
                                        </select>
                                        <?php $__errorArgs = ['std_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback form-invalid fw-bold" role="alert">
                                                <?php echo e($message); ?>

                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                <div class="row">

                                    <div class="row">
                                        <div class="form-group col-md-2">
                                            <label for="trans_1st_inst">1st Installment</label>
                                            <input type="text" name="trans_1st_inst" id="trans_1st_inst"
                                                class="form-control <?php $__errorArgs = ['trans_1st_inst'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                value="<?php echo e(old('trans_1st_inst', isset($fee) ? $fee->trans_1st_inst : '')); ?>"
                                                required>
                                            <?php $__errorArgs = ['trans_1st_inst'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback form-invalid fw-bold"
                                                    role="alert"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="form-group col-md-2">
                                            <label for="trans_2nd_inst">2nd Installment</label>
                                            <input type="text" name="trans_2nd_inst" id="trans_2nd_inst"
                                                class="form-control <?php $__errorArgs = ['trans_2nd_inst'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                value="<?php echo e(old('trans_2nd_inst', isset($fee) ? $fee->trans_2nd_inst : '')); ?>"
                                                required>
                                            <?php $__errorArgs = ['trans_2nd_inst'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback form-invalid fw-bold"
                                                    role="alert"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="form-group col-md-2">
                                            <label for="trans_discount">Discount</label>
                                            <input type="text" name="trans_discount" id="trans_discount"
                                                class="form-control <?php $__errorArgs = ['trans_discount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                value="<?php echo e(old('trans_discount', isset($fee) ? $fee->trans_discount : '')); ?>"
                                                required>
                                            <?php $__errorArgs = ['trans_discount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback form-invalid fw-bold"
                                                    role="alert"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="form-group col-md-2">
                                            <label for="trans_total">Total</label>
                                            <input type="text" name="trans_total" id="trans_total"
                                                class="form-control <?php $__errorArgs = ['trans_total'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                value="<?php echo e(old('trans_total', isset($fee) ? $fee->trans_total : '')); ?>"
                                                readonly>
                                            <?php $__errorArgs = ['trans_total'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback form-invalid fw-bold"
                                                    role="alert"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>

                                    </div>
                                </div>

                                <div class="mt-3">
                                    <input class="btn btn-primary" type="submit"
                                        value="<?php echo e(isset($fee) && isset($fee->id) ? 'Update' : 'Save'); ?>">
                                </div>
                            </form>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('admin-scripts'); ?>
    <script>
        var initialClassId = '<?php echo e(old('class_id', isset($fee) ? $fee->class_id : '')); ?>';
        var initialSectionId = '<?php echo e(old('section_id', isset($fee) ? $fee->section_id : '')); ?>';
        var initialStdId = '<?php echo e(old('std_id', isset($fee) ? $fee->srno : '')); ?>';

        getClassSection(initialClassId, initialSectionId);

        $(document).ready(function() {
            var classSelect = $('#class_id');
            var sectionSelect = $('#section_id');
            var sessionSelect = $('#current_session');
            var stdSelect = $('#std_id');

            function fetchStdNameFather(classId, sectionId, sessionId) {
                if (classId && sectionId && sessionId) {
                    $.ajax({
                        url: '<?php echo e(route('stdNameFather.get')); ?>',
                        type: 'GET',
                        data: {
                            class_id: classId,
                            section_id: sectionId,
                            session_id: sessionId,
                        },
                        success: function(data) {
                            console.log(data);
                            stdSelect.empty();
                            stdSelect.append('<option value="">Select Student</option>');
                            $.each(data, function(id, value) {
                                stdSelect.append('<option value="' + value.srno + '">' +
                                    ++id + '. ' + value.student_name + '/SH. ' + value.f_name +
                                    '</option>');
                            });
                            stdSelect.change(function() {
                                var selectedStdId = $(this).val();
                                var selectedStudent = data.find(student => student.srno ===
                                    selectedStdId);

                                if (selectedStudent) {
                                    $('#trans_1st_inst').val(selectedStudent.trans_1st_inst);
                                    $('#trans_2nd_inst').val(selectedStudent.trans_2nd_inst);
                                    $('#trans_discount').val(selectedStudent.trans_discount);
                                    $('#trans_total').val(selectedStudent.trans_total);
                                }
                            });

                            if (typeof initialStdId !== 'undefined') {
                                stdSelect.val(initialStdId);
                            }
                        },
                        error: function(xhr) {
                            console.error('Error fetching student detail:', xhr);
                        }
                    });
                } else {
                    stdSelect.empty();
                    stdSelect.append('<option value="">Select Student</option>');
                }
            }

            var selectedClassId = classSelect.val();
            var selectedSectionId = sectionSelect.val();
            var selectedSessionId = sessionSelect.val();
            if (selectedClassId && selectedSectionId && selectedSessionId) {
                fetchStdNameFather(selectedClassId, selectedSectionId, selectedSessionId);
            }

            sectionSelect.change(function() {
                var sectionId = $(this).val();
                var classId = classSelect.val();
                var sessionId = sessionSelect.val();
                fetchStdNameFather(classId, sectionId, sessionId);
            });

        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\svps-project\resources\views/admin/transport_fee/create.blade.php ENDPATH**/ ?>