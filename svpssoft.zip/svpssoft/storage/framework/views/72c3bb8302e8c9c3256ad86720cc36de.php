<?php $__env->startSection('sub-content'); ?>
    <div class="container">

        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">
                        <?php echo e('Rank Report'); ?>

                        <a href="<?php echo e(route('marks.rank-class-wise')); ?>" class="btn btn-warning btn-sm"
                            style="float: right;">Back</a>

                    </div>
                    <div class="card-body">
                        <form id="class-section-form">

                            <div class="row">
                                <div class="form-group col-md-6">
                                    <label for="class_id" class="mt-2">Class <span class="text-danger">*</span></label>
                                    <input type="hidden" name="current_session" value='' id="current_session">
                                    <select name="class" id="class_id"
                                        class="form-control <?php $__errorArgs = ['class'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                        <option value="">Select Class</option>
                                    </select>
                                    <?php $__errorArgs = ['class'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback form-invalid fw-bold"
                                            role="alert"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    <img src="<?php echo e(config('myconfig.myloader')); ?>" alt="Loading..." class="loader"
                                        id="loader" style="display:none; width:10%;">
                                </div>
                            </div>

                            <div class="mt-3">
                                <button type="button" id="show-std" class="btn btn-primary">
                                    Show Student</button>
                            </div>

                        </form>


                        <div id="std-container" class="mt-4">
                            <table class="table table-responsible">

                                <thead>
                                    <tr>
                                        <th>S.No.</th>
                                        <th>Class</th>
                                        <th>Section</th>
                                        <th>SRNO</th>
                                        <th>Name</th>
                                        <th>Total Obt. Marks</th>
                                        <th>Rank</th>
                                        <th>Total Meetings</th>
                                        <th>Meetings Attended</th>
                                    </tr>
                                </thead>
                                <tbody>
                                </tbody>
                            </table>
                            <div class="export-div">
                                <button type="button" class="btn btn-info" id="export-button">Excel</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('marks-scripts'); ?>
    <script>
        $(document).ready(function() {
            let initialClassId = $('#class_id').val();
            getClassSection(initialClassId);
            $('#std-container').hide();
            $('#show-std').click(function() {
                // console.log(initialClassId);
                let classId = $('#class_id').val();
                let sessionId = $('#current_session').val();
                $('#std-container').show();
                $.ajax({
                    url: '<?php echo e(route('marks.class-wise-rank-report')); ?>',
                    type: 'GET',
                    dataType: 'JSON',
                    data: {
                        class: classId,
                        session: sessionId,
                    },
                    success: function(response) {
                        console.log(response.data);

                        let stdHtml = '';
                        if (response.data && response.data.length > 0) {
                            $('#export-button').show();
                            $.each(response.data, function(index, std) {
                                stdHtml += `<tr>
                            <td>${index + 1}</td>
                            <td>${std.class}</td>
                            <td>${std.section}</td>
                            <td>${std.srno}</td>
                            <td>${std.name}</td>
                            <td>${std.total_marks}</td>
                            <td>${std.rank}</td>
                            <td>${std.total_meeting}</td>
                            <td>${std.meeting_attended}</td>
                        </tr>`;
                            });
                        } else {
                            stdHtml = '<tr><td colspan="9">No Student found</td></tr>';
                            $('#export-button').hide();
                        }
                        $('#std-container table tbody').html(stdHtml);
                    },
                    complete: function() {
                        loader.hide();
                    },
                    error: function(xhr) {
                        console.error(xhr.responseText);

                    }
                });
            });


            $('#export-button').on('click', function() {
                const classId = $('#class_id').val();
                const sessionId = $('#current_session').val();
                const exportUrl = "<?php echo e(route('marks.class-wise-rank-report-excel')); ?>?class=" +
                classId + "&session=" + sessionId;
                window.location.href = exportUrl;

            });

        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('marks.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\svps-project\resources\views/marks/marks_entry/rank_class_wise.blade.php ENDPATH**/ ?>