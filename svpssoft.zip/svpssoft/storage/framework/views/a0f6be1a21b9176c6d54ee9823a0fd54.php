<?php $__env->startSection('sub-content'); ?>
    <div class="container">
        <?php if(Session::has('success')): ?>
            <?php $__env->startSection('scripts'); ?>
                <script>
                    swal("Successful", "<?php echo e(Session::get('success')); ?>", "success").then(() => {
                        $('#std-form').hide();
                        location.reload();
                    });
                </script>
            <?php $__env->stopSection(); ?>
        <?php endif; ?>

        <?php if(Session::has('error')): ?>
            <?php $__env->startSection('scripts'); ?>
                <script>
                    swal("Error", "<?php echo e(Session::get('error')); ?>", "error").then(() => {
                        $('#std-form').hide();
                        location.reload();
                    });
                </script>
            <?php $__env->stopSection(); ?>
        <?php endif; ?>
        <div class="row justify-content-center">
            <div class="col-md-14">
                <div class="card">
                    <div class="card-header">
                        <?php echo e('Update Student Info. Class Wise'); ?>

                        <a href="<?php echo e(route('admin.editSection.index')); ?>" class="btn btn-warning btn-sm"
                            style="float: right;">Back</a>

                    </div>
                    <div class="card-body">
                        <form id="class-section-form">
                            <div class="row">
                                <div class="form-group col-md-6">
                                    <label for="class_id" class="mt-2">Class <span class="text-danger">*</span></label>
                                    <input type="hidden" id="initialClassId" value="<?php echo e(old('initialClassId',request()->get('class_id') !== null ? request()->get('class_id') : '')); ?>">
                                    <select name="class" id="class_id"
                                        class="form-control <?php $__errorArgs = ['class'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                        <option value="">Select Class</option>
                                        <?php if(count($classes) > 0): ?>
                                            <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($key); ?>" <?php echo e(old('class') == $key ? 'selected' : ''); ?>><?php echo e($class); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php else: ?>
                                            <option value="">No Class Found</option>
                                        <?php endif; ?>
                                    </select>
                                    <?php $__errorArgs = ['class'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback form-invalid fw-bold"
                                            role="alert"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                </div>


                                <div class="form-group col-md-6">
                                    <label for="section_id" class="mt-2">Section <span
                                            class="text-danger">*</span></label>
                                            <input type="hidden" id="initialSectionId" value="<?php echo e(old('section')); ?>">
                                    <select name="section" id="section_id"
                                        class="form-control <?php $__errorArgs = ['section'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                        <option value="">Select Section</option>

                                    </select>
                                    <?php $__errorArgs = ['section'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback form-invalid fw-bold"
                                            role="alert"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    <img src="<?php echo e(config('myconfig.myloader')); ?>" alt="Loading..." class="loader"
                                        id="loader" style="display:none; width:10%;">
                                </div>
                            </div>


                            <div class="mt-3">
                                <button type="button" id="show-details" class="btn btn-primary">
                                    Show Details</button>
                            </div>

                        </form>


                        <div id="std-container" class="mt-4">
                            <form action="<?php echo e(route('admin.editSection.editStdInfoClass.store')); ?>" method="POST" id="std-form">
                                <?php echo csrf_field(); ?>
                                <table class="table table-responsible">
                                    <input type="hidden" name="current_session" value='' id="current_session">

                                    <thead>
                                        <tr>
                                            <th>Roll No.</th>
                                            <th>SRNO</th>
                                            <th>Name</th>
                                            <th>Father Name</th>
                                            <th>Mother Name</th>
                                            <th>Grand Father Name</th>
                                            <th>DOB</th>
                                            <th>Contact 1</th>
                                            <th>Contact 2</th>
                                            <th>Age Proof</th>
                                        </tr>
                                    </thead>
                                    <tbody>

                                    </tbody>
                                </table>
                                <div id="std-pagination"></div>
                                <div class="row">
                                    <div class="mt-3">
                                        <button type="submit" class="btn btn-primary"
                                            id="section-updateBtn">Update</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('admin-scripts'); ?>
    <script>
        $(document).ready(function() {
            $('#std-form').hide();
            var loader = $('#loader');
            getClassSection($('#class_id').val(), $('#initialSectionId').val());
            $('#show-details').on('click', function() {

                const classId = $('#class_id').val();
                const sectionId = $('#section_id').val();
                const sessionId = $('#current_session').val();
                const paginationContainer = $('#std-pagination');
                var page = 1;
                loader.show();

                function stdDetails(page) {
                    if (classId && sectionId && sessionId) {
                        $('#std-form').show();
                        $.ajax({
                            url: '<?php echo e(route('stdNameFather.get')); ?>',
                            type: 'GET',
                            dataType: 'JSON',
                            data: {
                                class_id: classId,
                                section_id: sectionId,
                                session_id: sessionId,
                                page: page,
                            },
                            success: function(students) {
                                let stdHtml = '';
                                $.each(students.data, function(index, std) {


                                    stdHtml += `<tr>
                                                <td>${std.rollno}</td>
                                                <td>${std.srno}</td>
                                                <td>
                                                    <input type="hidden" name="students[${index}][srno]" value="${std.srno}" class="std-srno" id="std-srno" data-index="${index}">
                                                    <input type="text" name="students[${index}][student_name]" value='${std.student_name}' class="form-control <?php $__errorArgs = ['students[${index}][student_name]'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> std-name" data-index="${index}">
                                                        <span class="invalid-feedback form-invalid fw-bold error" id="std-name-error" role="alert">
                                                        </span>
                                                    <?php $__errorArgs = ['students[${index}][student_name]'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback form-invalid fw-bold error" role="alert">
                                                            <?php echo e(meaasge); ?>

                                                        </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </td>
                                                <td>
                                                    <input type="text" name="students[${index}][f_name]" value='${std.f_name}' class="form-control <?php $__errorArgs = ['students[${index}][f_name]'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> f_name" data-index="${index}">
                                                        <span class="invalid-feedback form-invalid fw-bold error" id="std-fname-error" role="alert">
                                                        </span>
                                                    <?php $__errorArgs = ['students[${index}][f_name]'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback form-invalid fw-bold error" role="alert">
                                                            <?php echo e(meaasge); ?>

                                                        </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </td>
                                                <td>
                                                    <input type="text" name="students[${index}][m_name]" value='${std.m_name}' class="form-control <?php $__errorArgs = ['students[${index}][m_name]'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> m_name" data-index="${index}">
                                                        <span class="invalid-feedback form-invalid fw-bold error" id="std-mname-error" role="alert">
                                                        </span>
                                                    <?php $__errorArgs = ['students[${index}][m_name]'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback form-invalid fw-bold error" role="alert">
                                                            <?php echo e(meaasge); ?>

                                                        </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </td>
                                                <td>
                                                    <input type="text" name="students[${index}][g_f_name]" value='${std.g_f_name}' class="form-control <?php $__errorArgs = ['students[${index}][g_f_name]'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> g_f_name" data-index="${index}">
                                                        <span class="invalid-feedback form-invalid fw-bold error" id="std-gfname-error" role="alert">
                                                        </span>
                                                    <?php $__errorArgs = ['students[${index}][g_f_name]'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback form-invalid fw-bold error" role="alert">
                                                            <?php echo e(meaasge); ?>

                                                        </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </td>
                                                <td>
                                                    <input type="date" name="students[${index}][dob]" value='${std.dob}' class="form-control <?php $__errorArgs = ['students[${index}][dob]'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> dob" data-index="${index}">
                                                        <span class="invalid-feedback form-invalid fw-bold error" id="std-dob-error" role="alert">
                                                        </span>
                                                    <?php $__errorArgs = ['students[${index}][dob]'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback form-invalid fw-bold error" role="alert">
                                                            <?php echo e(meaasge); ?>

                                                        </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </td>
                                                <td>
                                                    <input type="text" name="students[${index}][f_mobile]" value='${std.f_mobile ?? ''}' class="form-control <?php $__errorArgs = ['students[${index}][f_mobile]'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> contact1" data-index="${index}">
                                                        <span class="invalid-feedback form-invalid fw-bold error" id="std-contact1-error" role="alert">
                                                        </span>
                                                    <?php $__errorArgs = ['students[${index}][f_mobile]'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback form-invalid fw-bold error" role="alert">
                                                            <?php echo e(meaasge); ?>

                                                        </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </td>
                                                <td>
                                                    <input type="text" name="students[${index}][m_mobile]" value='${std.m_mobile ?? ''}' class="form-control <?php $__errorArgs = ['students[${index}][m_mobile]'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> contact2" data-index="${index}">
                                                        <span class="invalid-feedback form-invalid fw-bold error" id="std-contact1-error" role="alert">
                                                        </span>
                                                    <?php $__errorArgs = ['students[${index}][contact2]'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback form-invalid fw-bold error" role="alert">
                                                            <?php echo e(meaasge); ?>

                                                        </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </td>
                                                <td>
                                                     <select name="students[${index}][age_proof]" id="age_proof_${index}" class="form-control <?php $__errorArgs = ['students[${index}][age_proof]'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>  'is-invalid' <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                                        <option value="">Select Age Proof</option>
                                                        <option value="1" ${std.age_proof && std.age_proof == 1 ? 'selected' : ''}>Birth Certificate</option>
                                                        <option value="2" ${std.age_proof && std.age_proof == 2 ? 'selected' : ''}>Transfer Certificate</option>
                                                        <option value="3" ${std.age_proof && std.age_proof == 3 ? 'selected' : ''}>Affidavit</option>
                                                        <option value="4" ${std.age_proof && std.age_proof == 4 ? 'selected' : ''}>Aadhar Card</option>
                                                    </select>
                                                    <span class="invalid-feedback form-invalid fw-bold error" id="std-age-proof-error-${index}" role="alert"></span>
                                                    <?php $__errorArgs = ['students[${index}][age_proof]'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback form-invalid fw-bold error" role="alert">
                                                            <?php echo e(message); ?>

                                                        </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </td>

                                                </tr>`;

                                });
                                if (stdHtml === '') {
                                    stdHtml =
                                        '<tr><td colspan="10">No Student found</td></tr>';
                                }
                                $('#std-container table tbody').html(stdHtml);
                                updatePaginationControls(students);

                            },
                            complete: function() {
                                loader.hide();
                            },
                            error: function(xhr) {
                                console.error(xhr.responseText);

                            }
                        });
                    }
                }
                $(document).on('click', '#std-pagination .page-link', function(e) {
                    e.preventDefault();
                    var page = $(this).data('page');
                    stdDetails(page);
                });

                // function updatePaginationControls(data) {
                //     var paginationHtml = '';
                //     if (data.last_page > 1) {
                //         paginationHtml += '<ul class="pagination">';

                //         if (data.current_page > 1) {
                //             paginationHtml +=
                //                 `<li class="page-item"><a class="page-link" href="#" data-page="${data.current_page - 1}">Previous</a></li>`;
                //         }

                //         for (let i = 1; i <= data.last_page; i++) {
                //             if (i == data.current_page) {
                //                 paginationHtml +=
                //                     `<li class="page-item active"><span class="page-link">${i}</span></li>`;
                //             } else {
                //                 paginationHtml +=
                //                     `<li class="page-item"><a class="page-link" href="#" data-page="${i}">${i}</a></li>`;
                //             }
                //         }

                //         if (data.current_page < data.last_page) {
                //             paginationHtml +=
                //                 `<li class="page-item"><a class="page-link" href="#" data-page="${data.current_page + 1}">Next</a></li>`;
                //         }

                //         paginationHtml += '</ul>';
                //     }
                //     paginationContainer.html(paginationHtml);
                // }

                stdDetails(page);
            });

        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/webcalht/public_html/svpssoft/resources/views/admin/editSections/edit_student_info_class_wise.blade.php ENDPATH**/ ?>