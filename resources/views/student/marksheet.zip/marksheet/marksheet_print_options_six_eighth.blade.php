
@extends('marks.index')

@section('sub-content')
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        {{ 'Select Exams' }}
                        <a href="{{ route('marks.marks-report.marksheet.six.eighth') }}" class="btn btn-warning btn-sm" style="float: right;">Back</a>
                    </div>
                    <div class="card-body">
                        <form id="submitForm">
                            @csrf
                            <input type="hidden" id="class" name="class" value="{{$class}}">
                            <input type="hidden" id="section" name="section" value="{{$section}}">
                            <input type="hidden" id="students" name="students" value="{{$students}}">
                            <input type="hidden" id="session-message" name="sessionMessage" value="{{$sessionMessage}}">
                            <input type="hidden" id="date-message" name="dateMessage" value="{{$dateMessage}}">
                            <input type="hidden" id="exams" name="exams" value="">
                            <input type="hidden" id="withExam" name="withExam" value="">
                            <input type="hidden" id="withoutExam" name="withoutExam" value="">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>Examinition</th>
                                        <th>Select Exam (without W+O)</th>
                                        <th>Select Exam (with W+O)</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @if ($data)
                                        @foreach ($data as $key => $value)
                                            <tr data-entry-id="{{ $value->id }}" id="exam-row">
                                                 <td>{{$value->exam}}</td>
                                                <td><input type="checkbox" id="without" name="without" value={{$value->id}}></td>
                                                <td><input type="checkbox" id="with" name="with" value={{$value->id}}></td>
                                            </tr>
                                        @endforeach
                                    @else
                                        <tr>
                                            <td colspan="5">No Exam Found</td>
                                        </tr>
                                    @endif
                                    
                                </tbody>
                            </table>
                    
                            <div class="form-group">
                                <button type="button" class="btn btn-primary" id="show">Show MarkSheet</button>
                            </div>
                       </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
@section('marks-scripts')
    <script>
        $(document).ready(function() {
            
          $('#show').click(function(e) {
                    e.preventDefault();
                    let isValidSelection = true;
    
                    // Check each row for multiple checkbox selection
                    $('tr[data-entry-id]').each(function() {
                        let withCheckbox = $(this).find('input[name="with"]');
                        let withoutCheckbox = $(this).find('input[name="without"]');
                        
                        // If both checkboxes are checked, show an error
                        if (withCheckbox.is(':checked') && withoutCheckbox.is(':checked')) {
                            isValidSelection = false;
                            return false; // Break the loop
                        }
                    });
                    
                    // If validation fails, show an alert and stop processing
                    if (!isValidSelection) {
                        alert('For each exam, you can select either "With" or "Without" checkbox, but not both.');
                        return;
                    }
                let classId = $('#class').val();
                let sectionId = $('#section').val();
                let sessionMessage = $('#session-message').val();
                let dateMessage = $('#date-message').val();
                let stdId = $('#students').val();
                // let examId = $('#exam-row').data("entry-id");
            
                // Collect selected 'with' checkbox values
                let withIds = [];
                $('input[name="with"]:checked').each(function() {
                    withIds.push($(this).val());
                });
                
                // Collect selected 'without' checkbox values
                let withoutIds = [];
                $('input[name="without"]:checked').each(function() {
                    withoutIds.push($(this).val());
                });
            
                // Join the selected values into comma-separated strings
                let withId = withIds.join(',');
                let withoutId = withoutIds.join(',');
                let examId = (withId && withoutId) ? withId +","+withoutId :(withId ? withId : withoutId);
              
                $('#exams').val(examId);
                $('#withExam').val(withId);
                $('#withoutExam').val(withoutId);
                
                 $.ajaxSetup({
                            headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        }
                    });
                
                $.ajax({
                        url: '{{route('marks.marks-report.select.exam.six.eighth.store')}}',
                        method: 'POST',
                        data: $('#submitForm').serialize(),
                        dataType: 'JSON',
                        success:function(response)
                        {
                           window.location.href = response.redirectUrl; 
                        },
                        error: function(error) {
                            console.log(error);
                        }
                });
            
            });

           
        });
    </script>
@endsection