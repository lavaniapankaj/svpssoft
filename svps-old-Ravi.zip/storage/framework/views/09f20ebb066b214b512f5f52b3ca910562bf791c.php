<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header"><?php echo e(__('Add New Class')); ?><a href="<?php echo e(url('studentclass')); ?>" class="float-right btn btn-primary"><?php echo e(__('Back')); ?></a></div>
        <div class="card-body">
            <!-- Display Validation Errors -->
            <?php echo $__env->make('common.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <form action="<?php echo e(url('studentclass/store')); ?>" method="POST" class="form-horizontal">
                <?php echo e(csrf_field()); ?>

                <div class="form-group">
                    <label for="class_name" class="col-sm-3 control-label"> <?php echo e(__('Enter Class Name')); ?></label>
                    <div class="col-sm-6">
                        <input type="text" name="class_name" id="class_name" required class="form-control <?php $__errorArgs = ['class_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> " value="<?php echo e(old('class_name')); ?>">
                    </div>
                </div>
                <div class="form-group">
                    <button type="submit" class="btn btn-primary"><?php echo e(__('Add')); ?></button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home3/servefi4/public_html/svpssoft/resources/views/admin/studentclass/create.blade.php ENDPATH**/ ?>