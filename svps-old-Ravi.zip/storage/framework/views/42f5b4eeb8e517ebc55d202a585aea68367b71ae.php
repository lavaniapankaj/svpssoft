<?php $__env->startSection('content'); ?>
	<div class="card">
        <div class="card-header"><?php echo e(__('Hello Admin!')); ?>

        </div>
        <div class="card-body">
        	Stats here.
        </div>
	</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home3/webcawig/public_html/svpssoft/resources/views/admin/admindashboard.blade.php ENDPATH**/ ?>