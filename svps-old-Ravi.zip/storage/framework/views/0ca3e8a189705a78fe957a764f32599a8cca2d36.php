<?php $__env->startSection('content'); ?>
	<div class="card">
        <div class="card-header"><?php echo e(__('Section Master')); ?><a href="<?php echo e(url('section/create')); ?>" class="float-right btn btn-primary"><?php echo e(__('Add New Section')); ?></a>
        </div>
        <div class="card-body">
        	<?php if(count($section) > 0): ?>
            	<table class="table table-striped task-table ">
                    <thead>
                        <th>Sr.No.</th>
                        <th>Class</th>
                        <th>Section</th>
                        <th>Action</th>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $section; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $sectionInfo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="table-text"><?php echo e($index + $section->firstItem()); ?></td>
								<td class="table-text"><?php echo e($sectionInfo->class_name); ?></td>
								<td class="table-text"><?php echo e($sectionInfo->section_name); ?></td>
                                <td>
                                    <a href="<?php echo e(url('section/'.$sectionInfo->id)); ?>">Edit</a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
				<?php echo $section->render(); ?>

            <?php endif; ?>
        </div>
	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home3/servefi4/public_html/svpssoft/resources/views/admin/section/index.blade.php ENDPATH**/ ?>