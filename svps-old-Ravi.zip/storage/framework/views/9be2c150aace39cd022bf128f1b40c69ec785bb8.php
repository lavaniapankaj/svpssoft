<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header"><?php echo e(__('Add New Section')); ?><a href="<?php echo e(url('section')); ?>" class="float-right btn btn-primary"><?php echo e(__('Back')); ?></a></div>
        <div class="card-body">
            <!-- Display Validation Errors -->
            <?php echo $__env->make('common.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <form action="<?php echo e(url('section/store')); ?>" method="POST" class="form-horizontal">
                <?php echo e(csrf_field()); ?>

                <div class="form-group">
                    <label for="class_id" class="col-sm-3 control-label"> <?php echo e(__('Select Class')); ?></label>
                    <div class="col-sm-6">
                        <select name="class_id" id="class_id" class="form-control <?php $__errorArgs = ['class_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> " required>
                            <option value="">select</option>
                            <?php if($studentClassInfo && count($studentClassInfo) > 0): ?>
                                <?php $__currentLoopData = $studentClassInfo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $studentClass): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($studentClass->id); ?>" <?php echo e(old('class_id') == $studentClass->id ? 'selected' : ''); ?>><?php echo e($studentClass->class_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                            
                        </select>
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="section_name" class="col-sm-3 control-label"> <?php echo e(__('Enter Section Name')); ?></label>
                    <div class="col-sm-6">
                        <input type="text" name="section_name" id="section_name" required class="form-control <?php $__errorArgs = ['section_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> " value="<?php echo e(old('section_name')); ?>">
                    </div>
                </div>
    
                <!-- Add Task Button -->
                <div class="form-group">
                    <button type="submit" class="btn btn-primary">
                        <?php echo e(__('Add')); ?>

                    </button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home3/servefi4/public_html/svpssoft/resources/views/admin/section/create.blade.php ENDPATH**/ ?>