<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header"><?php echo e(__('Class Master')); ?><a href="<?php echo e(url('studentclass/create')); ?>" class="float-right btn btn-primary"><?php echo e(__('Add New Class')); ?></a></div>
        <div class="card-body">
            <?php if(count($studentClass) > 0): ?>
                    <table class="table table-striped task-table ">
                        <thead>
                            <th>Sr.No.</th>
                            <th>Class Name</th>
                            <th>Action</th>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $studentClass; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $classInfo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="table-text"><?php echo e($index + $studentClass->firstItem()); ?></td>
                                    <td class="table-text"><?php echo e($classInfo->class_name); ?></td>
                                    <td>
                                        <a href="<?php echo e(url('studentclass/'.$classInfo->id)); ?>">Edit</a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php echo $studentClass->render(); ?>

                <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home3/webcawig/public_html/svpssoft/resources/views/admin/studentclass/index.blade.php ENDPATH**/ ?>