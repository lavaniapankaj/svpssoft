<?php



use Illuminate\Support\Facades\Route;



/*

|--------------------------------------------------------------------------

| Web Routes

|--------------------------------------------------------------------------

|

| Here is where you can register web routes for your application. These

| routes are loaded by the RouteServiceProvider within a group which

| contains the "web" middleware group. Now create something great!

|

*/



Route::get('/', function () {

	/* return view('welcome'); */

	/* By default redirecting to login not on welcome page. */

	return view('auth.login');

});



Auth::routes(['register' => false]);


Route::get('changepassword', 'Auth\ChangePasswordController@index')->name('changepassword');
Route::post('change-password', 'Auth\ChangePasswordController@store')->name('change.password');

Route::get('/home', 'HomeController@index')->name('home');



/* Admin routes. */

Route::get('/admindashboard', 'admin\AdminController@index')->middleware('userrole:admin')->name('admindashboard');
Route::get('/loginlogs', 'admin\AdminController@loginlogs')->middleware('userrole:admin')->name('loginlogs');

// class 
Route::get('/studentclass', 'admin\StudentclassController@index')->middleware('userrole:admin')->name('studentclass');
Route::get('/studentclass/create', 'admin\StudentclassController@create')->middleware('userrole:admin')->name('studentclassCreate');
Route::post('/studentclass/store', 'admin\StudentclassController@store')->middleware('userrole:admin')->name('studentclassStore');
Route::post('/studentclass/store/{class_id}', 'admin\StudentclassController@store')->middleware('userrole:admin')->name('studentclassStore');
Route::get('/studentclass/{class_id}', 'admin\StudentclassController@edit')->middleware('userrole:admin')->name('studentclassEdit');

// Section 

Route::get('/section', 'admin\SectionController@index')->middleware('userrole:admin')->name('section');
Route::get('/section/create', 'admin\SectionController@create')->middleware('userrole:admin')->name('sectionCreate');
Route::post('/section/store', 'admin\SectionController@store')->middleware('userrole:admin')->name('sectionStore');
Route::post('/section/store/{section_id}', 'admin\SectionController@store')->middleware('userrole:admin')->name('sectionStore');
Route::get('/section/{section_id}', 'admin\SectionController@edit')->middleware('userrole:admin')->name('sectionEdit');


/* Student routes. */

Route::get('/studentdashboard', 'student\StudentController@index')->middleware('userrole:student')->name('studentdashboard');







/* Fee routes. */

Route::get('/feedashboard', 'fee\FeeController@index')->middleware('userrole:fee')->name('feedashboard');







/* Marks routes. */

Route::get('/marksdashboard', 'marks\MarksController@index')->middleware('userrole:marks')->name('marksdashboard');







