@extends('layouts.admin')

@section('content')
	<div class="card">
        <div class="card-header">{{ __('Hello Admin!') }}
        </div>
        <div class="card-body">
        	Stats here.
        </div>
	</div>
@endsection

