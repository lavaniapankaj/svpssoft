@extends('layouts.admin')

@section('content')
	<div class="card">
        <div class="card-header">{{ __('Update Class') }}<a href="{{ url('studentclass') }}" class="float-right btn btn-primary">{{ __('Back') }}</a></div>
        <div class="card-body">
			<!-- Display Validation Errors -->
			@include('common.errors')
            <form action="{{ url('studentclass/store/'.$classInfo->id) }}" method="POST" class="form-horizontal">
				{{ csrf_field() }}
				<div class="form-group">
					<label for="class_name" class="col-sm-3 control-label"> {{ __('Enter Class Name') }}</label>
					<div class="col-sm-6">
						<input type="text" name="class_name" id="class_name" class="form-control @error('class_name') is-invalid @enderror " value="@if(old('class_name')){{ old('class_name') }}@else{{$classInfo->class_name}}@endif" required>
					</div>
				</div>
                <div class="form-group">
                    <button type="submit" class="btn btn-primary">{{ __('Update') }}</button>
                </div>
            </form>
        </div>
    </div>
@endsection