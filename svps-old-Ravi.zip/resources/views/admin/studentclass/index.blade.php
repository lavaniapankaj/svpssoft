@extends('layouts.admin')

@section('content')
    <div class="card">
        <div class="card-header">{{ __('Class Master') }}<a href="{{ url('studentclass/create') }}" class="float-right btn btn-primary">{{ __('Add New Class') }}</a></div>
        <div class="card-body">
            @if (count($studentClass) > 0)
                    <table class="table table-striped task-table ">
                        <thead>
                            <th>Sr.No.</th>
                            <th>Class Name</th>
                            <th>Action</th>
                        </thead>
                        <tbody>
                            @foreach ($studentClass as  $index => $classInfo)
                                <tr>
                                    <td class="table-text">{{$index + $studentClass->firstItem()}}</td>
                                    <td class="table-text">{{ $classInfo->class_name }}</td>
                                    <td>
                                        <a href="{{ url('studentclass/'.$classInfo->id) }}">Edit</a>
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                    {!! $studentClass->render() !!}
                @endif
        </div>
    </div>
@endsection