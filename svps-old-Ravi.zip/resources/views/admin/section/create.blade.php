@extends('layouts.admin')

@section('content')
    <div class="card">
        <div class="card-header">{{ __('Add New Section') }}<a href="{{ url('section') }}" class="float-right btn btn-primary">{{ __('Back') }}</a></div>
        <div class="card-body">
            <!-- Display Validation Errors -->
            @include('common.errors')
            <form action="{{ url('section/store') }}" method="POST" class="form-horizontal">
                {{ csrf_field() }}
                <div class="form-group">
                    <label for="class_id" class="col-sm-3 control-label"> {{ __('Select Class') }}</label>
                    <div class="col-sm-6">
                        <select name="class_id" id="class_id" class="form-control @error('class_id') is-invalid @enderror " required>
                            <option value="">select</option>
                            @if($studentClassInfo && count($studentClassInfo) > 0)
                                @foreach($studentClassInfo as $studentClass)
                                <option value="{{$studentClass->id}}" {{ old('class_id') == $studentClass->id ? 'selected' : '' }}>{{$studentClass->class_name}}</option>
                                @endforeach
                            @endif
                            
                        </select>
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="section_name" class="col-sm-3 control-label"> {{ __('Enter Section Name') }}</label>
                    <div class="col-sm-6">
                        <input type="text" name="section_name" id="section_name" required class="form-control @error('section_name') is-invalid @enderror " value="{{ old('section_name') }}">
                    </div>
                </div>
    
                <!-- Add Task Button -->
                <div class="form-group">
                    <button type="submit" class="btn btn-primary">
                        {{ __('Add') }}
                    </button>
                </div>
            </form>
        </div>
    </div>
@endsection
