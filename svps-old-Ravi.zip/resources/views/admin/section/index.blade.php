@extends('layouts.admin')

@section('content')
	<div class="card">
        <div class="card-header">{{ __('Section Master') }}<a href="{{ url('section/create') }}" class="float-right btn btn-primary">{{ __('Add New Section') }}</a>
        </div>
        <div class="card-body">
        	@if (count($section) > 0)
            	<table class="table table-striped task-table ">
                    <thead>
                        <th>Sr.No.</th>
                        <th>Class</th>
                        <th>Section</th>
                        <th>Action</th>
                    </thead>
                    <tbody>
                        @foreach ($section as  $index => $sectionInfo)
                            <tr>
                                <td class="table-text">{{$index + $section->firstItem()}}</td>
								<td class="table-text">{{ $sectionInfo->class_name }}</td>
								<td class="table-text">{{ $sectionInfo->section_name }}</td>
                                <td>
                                    <a href="{{ url('section/'.$sectionInfo->id) }}">Edit</a>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
				{!! $section->render() !!}
            @endif
        </div>
	</div>
@endsection
