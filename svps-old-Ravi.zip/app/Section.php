<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Section extends Model
{
    protected $table = 'tbl_section';
	
	protected $primaryKey = 'id';
	
	protected $fillable = [
        'add_id', 'edit_id', 'class_id','section_name', 'active',
    ];
	use SoftDeletes;
	protected $dates = ['deleted_at'];
}
