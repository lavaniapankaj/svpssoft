<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\LoginLog;
use App\Providers\RouteServiceProvider;
use Illuminate\Foundation\Auth\AuthenticatesUsers;

class LoginController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Login Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles authenticating users for the application and
    | redirecting them to your home screen. The controller uses a trait
    | to conveniently provide its functionality to your applications.
    |
    */
    use AuthenticatesUsers;
    /**
     * Where to redirect users after login.
     *
     * @var string
     */
    protected $redirectTo = RouteServiceProvider::HOME;
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest')->except('logout');
    }

	/* Manage custom redirect. */
	protected function authenticated($request, $user)
	{
		/* Save login log. */
		$loginlog = new LoginLog;
		$loginlog->user_id = $user->id;
		$loginlog->ip = isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : "";
		$loginlog->save();
		
		$user_role = $user->user_role;
		if($user_role == "admin")
		{
			return redirect()->route('admindashboard');
		}
		if($user_role == "student")
		{
			return redirect()->route('studentdashboard');
		}
		if($user_role == "fee")
		{
			return redirect()->route('feedashboard');
		}
		if($user_role == "marks")
		{
			return redirect()->route('marksdashboard');
		}
		return redirect()->route('home');
	}
}
