<?php
namespace App\Http\Controllers\Auth;
use Illuminate\Http\Request;
use App\Rules\MatchOldPassword;
use Illuminate\Support\Facades\Hash;
use App\User;
use App\Http\Controllers\Controller;
use Auth;
use Exception;
use Redirect;

class ChangePasswordController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }
   
    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        return view('auth.changePassword');
    } 
   
    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function store(Request $request)
    {
        $request->validate(['new_password' => ['nullable', 'string', 'min:8'],
        'new_confirm_password' => ['nullable', 'required_with:new_password', 'same:new_password'],
        'current_password' => ['required', function ($attribute, $value, $fail) {
            if (!\Hash::check($value, Auth::user()->password)) {
                return $fail(__('The current password is incorrect.'));
            }
	}]]);
		try{
        $response = User::find(auth()->user()->id)->update(['password'=> Hash::make($request->new_password)]);
			if(!$response)
			{
				throw new Exception('Update password failed');
			}
			Auth::logout();
			return redirect('/');
		}
		catch(Exception $e)
		{
			return redirect()->back();
		}
        
    }
}

