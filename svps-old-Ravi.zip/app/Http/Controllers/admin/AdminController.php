<?php

namespace App\Http\Controllers\admin;

use App\LoginLog;
use App\User;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class AdminController extends Controller
{
	/**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }
	
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
		return view("admin.admindashboard");
    }

    /* Get login logs. */
	public function loginlogs()
	{
		$user_role = isset($_GET['role']) ? $_GET['role'] : "";
		$number_of_records = isset($_GET['limit']) ? $_GET['limit'] : "5";
		$loginlogs = DB::table('users')
            ->join('login_logs', 'users.id', '=', 'login_logs.user_id')
            ->select('users.id', 'users.name', 'login_logs.id as log_id', 'login_logs.ip', 'login_logs.created_at')
			->where('users.user_role', "like", $user_role)
			->orderBy('created_at', "desc")
			->limit($number_of_records)
            ->get();
		$logs = array();
		if(!empty($loginlogs))
		{
			foreach($loginlogs as $log)
			{
				$logs[] = array(
								"log_id" => $log->log_id,
								"user_id" => $log->id,
								"user_name" => $log->name,
								"ip" => $log->ip,
								"login_date" => date("m/d/Y H:i:s", strtotime($log->created_at))
							);
			}
		}
		return $logs;
	}
}
