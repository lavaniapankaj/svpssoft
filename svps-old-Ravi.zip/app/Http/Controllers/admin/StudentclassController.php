<?php

namespace App\Http\Controllers\admin;

use App\Studentclass;
use App\User;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use DB;
use Exception;
use Redirect;
class StudentclassController extends Controller
{
	/**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }
	
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
		$studentClass = studentclass::orderBy('created_at','desc')->paginate(10);
		return view("admin.studentclass.index",['studentClass'=>$studentClass]);
    }
	public function create()
    {
		return view("admin.studentclass.create");
    }
	
	public function store(Request $request, $class_id=null)
    {
		$this->validate($request, [
			'class_name'=>'required|unique:tbl_class,class_name,'.$class_id.',id,deleted_at,NULL',
		]);
		try{
			DB::beginTransaction();
			$classInfo = [
				'class_name'=>$request->class_name,
			];
			$classInfo = $this->setAddEditData($classInfo,$class_id);
			if($class_id)
			{
				$classEditInfo = Studentclass::find($class_id);
				$response = $classEditInfo->update($classInfo);
			}
			else{
				$response = Studentclass::create($classInfo);
			}
			
			if(!$response)
			{
				throw new Exception('class create update failed');
			}

			DB::commit();
		}
		catch(Exception $e)
		{
			DB::rollBack();
			return Redirect::back()->withErrors(['class_name' => [$e->getMessage()]])->withInput($request->all());
		}
		return redirect('/studentclass');
    }

    public function edit($id)
	{
		$classInfo = Studentclass::find($id);
		return view("admin.studentclass.edit",['classInfo'=>$classInfo]);
	}
}
