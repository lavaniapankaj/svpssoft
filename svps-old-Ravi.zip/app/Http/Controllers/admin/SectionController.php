<?php

namespace App\Http\Controllers\admin;

use App\Studentclass;
use App\Section;
use App\User;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use DB;
use Exception;
use Redirect;
class SectionController extends Controller
{
	/**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }
	
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
		$section = Section::join('tbl_class','tbl_class.id','=','tbl_section.class_id')
		->select('*','tbl_section.id as id')
		->orderBy('tbl_section.created_at','desc')->paginate(10);
		return view("admin.section.index",['section' => $section]);
    }
	public function create()
    {
		$studentClassInfo = Studentclass::orderBy('created_at','desc')->get();
		return view("admin.section.create",['studentClassInfo'=>$studentClassInfo]);
    }
	
	public function store(Request $request, $section_id=null)
    {
		$this->validate($request, [
			'class_id'=>'required',
			'section_name'=>'required|unique:tbl_section,section_name,'.$section_id.',id,deleted_at,NULL,class_id,'.$request->class_id,
		]);
		try{
			DB::beginTransaction();
			$sectionInfo = [
				'section_name'=>$request->section_name,
				'class_id'=>$request->class_id,
			];
			$sectionInfo = $this->setAddEditData($sectionInfo,$section_id);
			if($section_id)
			{
				$sectionEditInfo = Section::find($section_id);
				$response = $sectionEditInfo->update($sectionInfo);
			}
			else{
				$response = Section::create($sectionInfo);
			}
			
			if(!$response)
			{
				throw new Exception('Section create update failed');
			}

			DB::commit();
		}
		catch(Exception $e)
		{
			DB::rollBack();
			return Redirect::back()->withErrors(['section_name' => [$e->getMessage()]])->withInput($request->all());
		}
		return redirect('/section');
    }

    public function edit($id)
	{
		$sectionInfo = Section::find($id);
		if($sectionInfo)
		{
			$studentClassInfo = Studentclass::orderBy('created_at','desc')->get();
		}
		return view("admin.section.edit",['sectionInfo'=>$sectionInfo,'studentClassInfo'=>$studentClassInfo]);
	}
}
