<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Routing\Controller as BaseController;
use Auth;
class Controller extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;
	
	
	public function loggedUserInfo()
	{
		$user = Auth::user();
		return $user;
	}
	
	public function todayDate()
	{
		return date('Y-m-d h:i:s');
	}
	
	public function setAddEditData($info,$type)
	{
		if($type)
		{
			$info['edit_id'] = $this->loggedUserInfo()->id;
		}
		else{
			$info['add_id'] = $this->loggedUserInfo()->id;
		}
		return $info;
	}
}
