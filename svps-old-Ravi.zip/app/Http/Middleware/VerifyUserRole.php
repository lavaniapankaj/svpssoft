<?php

namespace App\Http\Middleware;
use Illuminate\Support\Facades\Auth;

use Closure;

class VerifyUserRole
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next, $user_role)
    {
		if(Auth::check())
		{
			$current_user_id = Auth::id();
			$logged_in_user_role = Auth::user()->user_role;
			if($logged_in_user_role == $user_role)
			{
				return $next($request);
			}
		}
		return redirect('login');
    }
}
