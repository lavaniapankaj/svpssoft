<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Studentclass extends Model
{
    protected $table = 'tbl_class';
	
	protected $primaryKey = 'id';
	
	protected $fillable = [
        'add_id', 'edit_id', 'class_name', 'active',
    ];
	use SoftDeletes;
	protected $dates = ['deleted_at'];
}
