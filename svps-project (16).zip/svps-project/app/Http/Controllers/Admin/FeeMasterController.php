<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Admin\FeeMaster;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Validation\Rule;

class FeeMasterController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        //
        $query =  FeeMaster::query();
        if ($query) {
            # code...
            if (filled($request->session_id) && filled($request->class_id)) {
                $query->where('session_id', $request->session_id)->where('class_id', $request->class_id);
            }
            $data = $query->where('active', 1)->orderBy('created_at', 'DESC')->paginate(10);
            return view('admin.academic_fee.index', compact('data'));
        }else {
            return redirect()->back()->with('error', 'Something went wrong, please try again.');
        }
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
        return view('admin.academic_fee.create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
        $request->validate([
            // 'class_id' => 'required|integer|exists:class_masters,id',
            'session_id' => 'required|integer|exists:session_masters,id',
            'admission_fee' => 'required|numeric|min:0',
            'inst_1' => 'required|numeric|min:0',
            'inst_2' => 'required|numeric|min:0',
            'ins_discount' => 'required|numeric|min:0',
            'inst_total' => 'required|numeric|min:0',
            'class_id' => [
                'required',
                'integer',
                'exists:class_masters,id',
                Rule::unique('fee_masters')->where(function ($query) use ($request) {
                    return $query->where('class_id', $request->class_id)->where('session_id', $request->session_id)->where('active', 1);
                })->ignore($request->id),
            ],
        ], [
            'class_id.required' => 'Select Class',
            'session_id.required' => 'Select Session',
            'admission_fee.required' => 'Enter Admission Fee',
            'inst_1.required' => 'Enter First Installment',
            'inst_2.required' => 'Enter Second Installment',
            'ins_discount.required' => 'Enter Discount',
            'inst_total.required' => 'Enter Total',
            'numeric' => 'The :attribute must be a number.',
            'min' => 'The :attribute must be at least :min.',
        ]);

        $user = Auth::user();

        $feeData = [
            'session_id' => $request->session_id,
            'class_id' => $request->class_id,
            'admission_fee' => $request->admission_fee,
            'inst_1' => $request->inst_1,
            'inst_2' => $request->inst_2,
            'ins_discount' => $request->ins_discount ?? 0,
            'inst_total' => $request->inst_total,
            'edit_user_id' => $user->id,
            'active' => 1,

        ];
        $query = FeeMaster::query();
        if ($query) {
            # code...
            if ($request->id !== '') {
                $fee = $query->find($request->id);
                if ($fee !== null) {
                    $feeData['add_user_id'] = $fee->add_user_id;
                } else {
                    $feeData['add_user_id'] = $user->id;
                }
            }
            $fee = $query->updateOrCreate(['id' => $request->id], $feeData);

            if ($fee) {
                return redirect()->route('admin.academic-fee-master.index')->with('success', $request->id ? 'Academic Fee updated successfully.' : 'Academic Fee saved successfully.');
            } else {
                return redirect()->back()->with('error', 'Something went wrong, please try again.');
            }
        } else {
            return redirect()->back()->with('error', 'Something went wrong, please try again.');
        }
    }




    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
        $fee = FeeMaster::findOrFail($id);
        if ($fee !== null) {
            # code...
            return view('admin.academic_fee.create', compact('fee'));
        } else {
            # code...
            return redirect()->back()->with('error', 'Something went wrong, please try again.');
        }

    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }
}
