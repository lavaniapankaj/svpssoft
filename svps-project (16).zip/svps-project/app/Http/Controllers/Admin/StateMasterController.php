<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Admin\StateMaster;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class StateMasterController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        //
        $query = StateMaster::query();
        if ($query) {
            if ($request->search !== '') {
                $search = $request->search;
                $query->where('name', 'LIKE', "%{$search}%")->where('active', 1);
            }
            $data['data'] = $query->where('active', 1)->orderBy('created_at', 'DESC')->paginate(10);

            if ($data !== null) {
                return view('admin.state.index', $data);
            }
        } else {
            return redirect()->back()->with('error', 'Something went wrong, please try again.');
        }
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
        return view('admin.state.create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
        $request->validate([
            'state' => 'required|string|unique:state_masters,name,' . $request->id . ',id,active,1',

        ]);

        $user = Auth::user();
        $stateData = [
            'name' => $request->state,
            'edit_user_id' => $user->id,
            'active' => 1,

        ];
        $query = StateMaster::query();
        if ($query) {
            # code...
            if ($request->id !== '') {
                $state = $query->find($request->id);
                if ($state == true) {
                    $stateData['add_user_id'] = $state->add_user_id;
                } else {
                    $stateData['add_user_id'] = $user->id;
                }
            }
            $state = $query->updateOrCreate(['id' => $request->id], $stateData);

            if ($state) {
                return redirect()->route('admin.state-master.index')->with('success', $request->id ? 'State updated successfully.' : 'State saved successfully.');
            } else {
                return redirect()->back()->with('error', 'Something went wrong, please try again.');
            }
        } else {
            return redirect()->back()->with('error', 'Something went wrong, please try again.');
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(StateMaster $stateMaster)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit($id)
    {
        //
        if ($id) {
            # code...
            $data['data'] = StateMaster::where('id', $id)->first();
            return view('admin.state.create', $data);
        } else {
            return redirect()->back()->with('error', 'Something went wrong, please try again.');
        }
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, StateMaster $stateMaster)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    // public function softDelete($id)
    // {
    //     try {
    //         $stateData = ['active' => 0];

    //         $state = StateMaster::find($id);
    //         if ($state) {
    //             $state->update($stateData);
    //             return response()->json(['status' => 'success', 'message' => 'State Master deleted successfully.']);
    //         } else {
    //             return response()->json(['status' => 'error', 'message' => 'Failed to delete State Master.'], 404);
    //         }
    //     } catch (\Exception $e) {
    //         return response()->json(['status' => 'error', 'message' => 'An error occurred while deleting.'], 500);
    //     }
    // }

    /**
     * Get All The States
     */

    public function getStates()
    {
        try {
            $states = StateMaster::where('active', 1)->pluck('name', 'id');
            if ($states->isNotEmpty()) {
                return response()->json([
                    'status' => 'success',
                    'message' => "All States",
                    'data' => $states,
                ], 200);
            } else {
                return response()->json([
                    'status' => 'success',
                    'message' => "No States are found",
                    'data' => [],
                ], 200);
            }
        } catch (\Exception $e) {
            return response()->json([
                'status' => 'error',
                'message' => "Failed to get states " . $e->getMessage()
            ], 500);
        }
    }
}
