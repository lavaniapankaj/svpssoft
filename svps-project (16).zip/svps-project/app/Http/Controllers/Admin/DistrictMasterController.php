<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Admin\DistrictMaster;
use App\Models\Admin\StateMaster;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;

class DistrictMasterController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        //
        if ($request->state_id !== '') {
            # code...
            $query = DistrictMaster::query();
            $data['state'] = $request->state_id;
            if ($request->state_id) {
                $data['state'] =  $query->where('state_id', $data['state'])->where('active', 1);
            }
            $data = $query->where('active', 1)->orderBy('created_at', 'DESC')->paginate(10);
            return view('admin.district.index', compact('data'));
        } else {
            return redirect()->back()->with('error', 'Something went wrong, please try again.');
        }
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
        return view('admin.district.create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
        $request->validate([
            'name' => [
                'required',
                'string',
                Rule::unique('district_masters')->where(function ($query) use ($request) {
                    return $query->where('state_id', $request->state_id)->where('active', 1);
                })->ignore($request->id),
            ],
            'state_id' => 'required|exists:state_masters,id',
        ]);
        $user = Auth::user();

        $districtData = [
            'name' => $request->name,
            'state_id' => $request->state_id,
            'edit_user_id' => $user->id,
            'active' => 1,

        ];
        if ($districtData !== []) {
            # code...
            $query = DistrictMaster::query();
            if ($request->id !== '') {
                $district = $query->find($request->id);
                if ($district !== null) {
                    $districtData['add_user_id'] = $district->add_user_id;
                } else {
                    $districtData['add_user_id'] = $user->id;
                }
                $district = $query->updateOrCreate(['id' => $request->id], $districtData);

                if ($district) {
                    return redirect()->route('admin.district-master.index')->with('success', $request->id ? 'District updated successfully.' : 'District saved successfully.');
                } else {
                    return redirect()->back()->with('error', 'Something went wrong, please try again.');
                }
            }

        } else {
            return redirect()->back()->with('error', 'Something went wrong, please try again.');
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(DistrictMaster $districtMaster)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit($id)
    {
        //
        if ($id) {
            # code...
            $district = DistrictMaster::findOrFail($id);
            return view('admin.district.create', compact('district'));
        } else {
            return redirect()->back()->with('error', 'Something went wrong, please try again.');
        }
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, DistrictMaster $districtMaster)
    {
        //
    }

    public function getDistricts(Request $request)
    {
        try {
            $validator = Validator::make($request->all(), [
                'state_id' => 'required|exists:state_masters,id',
            ]);
            if ($validator->fails()) {
                return response()->json([
                    'status' => 'error',
                    'message' => $validator->errors()
                ], 400);
            }
            $stateId = $request->input('state_id');
            if (!empty($stateId)) {
                $districts = DistrictMaster::where('state_id', $stateId)->where('active', 1)->pluck('name', 'id');
                if ($districts->isNotEmpty()) {
                    return response()->json([
                        'status' => 'success',
                        'message' => "All districts according to the states",
                        'data' => $districts,
                    ], 200);
                    return response()->json($districts);
                }
                else {
                    return response()->json([
                        'status' => 'success',
                        'message' => "No districts are found",
                        'data' => [],
                    ], 200);
                    return response()->json($districts);
                }
            } else {
                return response()->json([
                    'status' => 'error',
                    'message' => "Please Select the state",
                ], 400);
            }
        } catch (\Exception $e) {
            return response()->json([
                'status' => 'error',
                'message' => "Failed to get districts " . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Remove the specified resource from storage.
     */


    // public function softDelete($id)
    // {
    //     try {
    //         $districtData = ['active' => 0];

    //         $district = DistrictMaster::find($id);
    //         if ($district) {
    //             $district->update($districtData);
    //             return response()->json(['status' => 'success', 'message' => 'District Master deleted successfully.']);
    //         } else {
    //             return response()->json(['status' => 'error', 'message' => 'Failed to delete District Master.'], 404);
    //         }
    //     } catch (\Exception $e) {
    //         return response()->json(['status' => 'error', 'message' => 'An error occurred while deleting.'], 500);
    //     }
    // }
}
