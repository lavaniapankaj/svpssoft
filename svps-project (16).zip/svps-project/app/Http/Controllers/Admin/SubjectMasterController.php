<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Admin\ClassMaster;
use App\Models\Admin\SectionMaster;
use App\Models\Admin\SubjectMaster;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;

class SubjectMasterController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        $query = SubjectMaster::query();
        if ($query) {
            # code...
            if (filled($request->class_id)) {
                $query->where('class_id', $request->class_id)->whereNull('subject_id')->where('active', 1)->get();
            }
            $data = $query->whereNull('subject_id')->where('active', 1)->orderBy('created_at', 'DESC')->with('class')->paginate(10);
            if ($data !== null) {
                return view('admin.subject.index', ['data' => $data, 'selectedClassId' => $request->class_id]);
            }
        } else {
            return redirect()->back()->with('error', 'Something went wrong, please try again.');
        }
    }


    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('admin.subject.create');
    }


    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $request->validate([
            'subject' => [
                'required',
                'string',
                Rule::unique('subject_masters')->where(function ($query) use ($request) {
                    return $query->where('class_id', $request->class_id)->where('active', 1);
                })->ignore($request->id),
            ],
            'class_id' => 'required|exists:class_masters,id',
            'by_m_g' => 'required',
        ]);
        $user = Auth::user();

        $subjectData = [
            'subject' => $request->subject,
            'by_m_g' => $request->by_m_g,
            'class_id' => $request->class_id,
            'priority' => 1,
            'edit_user_id' => $user->id,
            'active' => 1,

        ];
        $query = SubjectMaster::query();
        if ($query) {
            if ($request->id !== '') {
                $subject = $query->find($request->id);
                if ($subject !== null) {
                    $subjectData['add_user_id'] = $subject->add_user_id;
                } else {
                    $subjectData['add_user_id'] = $user->id;
                }
            }

            $subject = $query->updateOrCreate(['id' => $request->id], $subjectData);

            if ($subject) {
                return redirect()->route('admin.subject-master.index')->with('success', $request->id ? 'Subject updated successfully.' : 'Subject saved successfully.');
            } else {
                return redirect()->back()->with('error', 'Something went wrong, please try again.');
            }
        } else {
            return redirect()->back()->with('error', 'Something went wrong, please try again.');
        }
    }


    /**
     * Display the specified resource.
     */
    public function show(SubjectMaster $subjectMaster)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit($id)
    {
        if ($id) {
            # code...
            $subject = SubjectMaster::findOrFail($id);
            return view('admin.subject.create', compact('subject'));
        } else {
            return redirect()->back()->with('error', 'Something went wrong, please try again.');
        }
    }


    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, SubjectMaster $subjectMaster)
    {
        //
    }

    /**
     * Get the subjects according to the classes
     */

    public function getSubjects(Request $request)
    {
        try {
            $validator = Validator::make($request->all(), [
                'class_id' => 'required|exists:class_masters,id',
            ]);
            if ($validator->fails()) {
                return response()->json([
                    'status' => 'error',
                    'message' => $validator->errors()
                ], 400);
            }
            //code...
            $query = SubjectMaster::query();
            if ($query) {
                if (filled($request->class_id)) {
                    if (filled($request->subject)) {
                        $data = $query->where('class_id', $request->class_id)->whereNull('subject_id')->where('active', 1)->pluck('subject', 'id');
                    } else {
                        $data = $query->where('class_id', $request->class_id)
                            ->where('active', 1)
                            ->pluck('subject', 'id');
                    }
                    if ($data->isNotEmpty()) {
                        return response()->json([
                            'status' => 'success',
                            'message' => "All Subjects",
                            'data' => $data,
                        ], 200);
                    }else {
                        return response()->json([
                            'status' => 'success',
                            'message' => "No Subjects are found",
                            'data' => [],
                        ], 200);

                    }
                }
            }
        } catch (\Exception $e) {
            return response()->json([
                'status' => 'error',
                'message' => "Failed to get subjects " . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    // public function softDelete($id)
    // {
    //     try {
    //         $subjectData = ['active' => 0];

    //         $subject = SubjectMaster::find($id);
    //         if ($subject) {
    //             $subject->update($subjectData);
    //             return response()->json(['status' => 'success', 'message' => 'Subject Master deleted successfully.']);
    //         } else {
    //             return response()->json(['status' => 'error', 'message' => 'Failed to delete Subject Master.'], 404);
    //         }
    //     } catch (\Exception $e) {
    //         return response()->json(['status' => 'error', 'message' => 'An error occurred while deleting.'], 500);
    //     }
    // }



}
