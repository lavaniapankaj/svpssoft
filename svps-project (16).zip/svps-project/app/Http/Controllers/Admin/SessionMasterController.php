<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Admin\SessionMaster;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Validation\Rule;

class SessionMasterController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        //
        if ($request->start_year !== '' && $request->end_year !== '') {
            $query = SessionMaster::query();
            $start_year = $request->start_year;
            $end_year = $request->end_year;
            if ($start_year !== '' && $end_year !== '') {
                $query->where(function ($q) use ($start_year, $end_year) {
                    $q->where('start_year', 'LIKE', "%{$start_year}%")
                        ->where('end_year', 'LIKE', "%{$end_year}%");
                });
            }
            $data['data'] = $query->where('active', 1)->orderBy('created_at', 'DESC')->paginate(10);
            return view('admin.session.index', $data);
        }else {
            return redirect()->back()->with('error', 'Something went wrong, please try again.');
        }
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        // $years = $this->generateYearOptions();

        return view('admin.session.create');
        //return view('admin.session.create', ['years' => $years]);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        // Validate start_year and end_year
        $request->validate([
            'start_year' => 'required|integer|digits:4|between:2004,2050',
            'end_year' => [
                'required',
                'integer',
                'digits:4',
                'between:2005,2051',
                'gt:start_year',
            ],
        ]);

        $uniqueRule = Rule::unique('session_masters')
            ->where(function ($query) use ($request) {
                return $query->where('active',1)->where('start_year', $request->start_year)
                    ->where('end_year', $request->end_year);
            })
            ->ignore($request->id);

        $request->validate([
            'start_year' => [$uniqueRule],
        ]);
        $user = Auth::user();

        $sessionData = [
            'start_year' => $request->start_year,
            'end_year' => $request->end_year,
            'session' => $request->start_year . '-' . $request->end_year,
            'edit_user_id' => $user->id,
            'active' => 1,
        ];
        if ($request->id  !== '') {
            $session = SessionMaster::find($request->id);
            if ($session !== null) {
                $sessionData['add_user_id'] = $session->add_user_id;
            }
        } else {
           $sessionData['add_user_id'] = $user->id;
        }

        $session = SessionMaster::updateOrCreate(['id' => $request->id], $sessionData);

        if ($session) {
            return redirect()->route('admin.session-master.index')->with('success', $request->id ? 'Session updated successfully.' : 'Session saved successfully.');
        } else {
            return redirect()->back()->with('error', 'Something went wrong, please try again.');
        }
    }

    public function edit($id)
    {
        if ($id) {
            # code...
            $data['data'] = SessionMaster::findOrFail($id);
            if ($data !== null) {
                # code...
                return view('admin.session.create', $data);
            }
        }else{
            return redirect()->back()->with('error', 'Something went wrong, please try again.');
        }
    }


    /**
     * Display the specified resource.
     */
    public function show(SessionMaster $sessionMaster)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */



    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, SessionMaster $sessionMaster)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    // public function softDelete($id)
    // {
    //     try {
    //         $sessionData = ['active' => 0];

    //         // Find the session by ID and update its 'active' status
    //         $session = SessionMaster::find($id);
    //         if ($session) {
    //             $session->update($sessionData);
    //             return response()->json(['status' => 'success', 'message' => 'Session Master deleted successfully.']);
    //         } else {
    //             return response()->json(['status' => 'error', 'message' => 'Failed to delete Session Master.'], 404);
    //         }
    //     } catch (\Exception $e) {
    //         return response()->json(['status' => 'error', 'message' => 'An error occurred while deleting.'], 500);
    //     }
    // }

    /**
     * Get all the sessions.
     */

    public function getSessions(){
        try {
            //code...
            $sessions = SessionMaster::where('active', 1)->pluck('session', 'id');
            if ($sessions->isNotEmpty()) {
                return response()->json([
                    'status' => 'success',
                    'message' => "All Sessions",
                    'data' => $sessions,
                ], 200);
            }else {
                return response()->json([
                    'status' => 'success',
                    'message' => "No Sessions are found",
                    'data' => [],
                ], 200);
            }
        }  catch (\Exception $e) {
            return response()->json([
                'status' => 'error',
                'message' => "Failed to get sessions " . $e->getMessage()
            ], 500);

        }
    }
}
