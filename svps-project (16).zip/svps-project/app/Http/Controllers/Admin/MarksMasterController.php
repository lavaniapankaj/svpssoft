<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Admin\ExamMaster;
use App\Models\Admin\MarksMaster;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Validation\Rule;

class MarksMasterController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        //
        $currentSession = session('current_session')->id;
        $query = MarksMaster::query();
        if ($query) {
            # code...
            if ($request->class_id !== '' && $request->subject_id !== '') {
                $query->where('class_id', $request->class_id)->where('subject_id', $request->subject_id)->where('active', 1);
            }
            $data = $query->where('session_id', $currentSession)->where('active', 1)->orderBy('created_at', 'DESC')->paginate(10);

            if ($data !== null) {
                # code...
                return view('admin.marks.index', ['data' => $data]);
            }else {
                return redirect()->back()->with('error', 'Something went wrong, please try again.');
            }
        }else{
            return redirect()->back()->with('error', 'Something went wrong, please try again.');
        }

    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
        // $exams = ExamMaster::where('active',1)->get();
        // if ($exams !== null) {
            # code...
            // return view('admin.marks.create',compact('exams'));
            return view('admin.marks.create');
        // }else {
        //     return redirect()->back()->with('error', 'Something went wrong, please try again.');
        // }
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {

        $request->validate([
            'min_marks' => [
                'required',
                'numeric',
                'lt:max_marks',
                'different:max_marks',
                Rule::unique('marks_masters')
                    ->where(function ($query) use ($request) {
                        return $query->where('class_id', $request->class_id)
                                     ->where('subject_id', $request->subject_id)
                                     ->where('exam_id', $request->exam_id)
                                     ->where('session_id', $request->current_session)
                                     ->where('active', 1);
                    })
                    ->ignore($request->id),
            ],
            'max_marks' => [
                'required',
                'numeric',
                'gt:min_marks',
                'different:min_marks',
                Rule::unique('marks_masters')
                    ->where(function ($query) use ($request) {
                        return $query->where('class_id', $request->class_id)
                                     ->where('subject_id', $request->subject_id)
                                     ->where('exam_id', $request->exam_id)
                                     ->where('session_id', $request->current_session)
                                     ->where('active', 1);
                    })
                    ->ignore($request->id),
            ],
            'class_id' => 'required|exists:class_masters,id',
            'subject_id' => 'required|exists:subject_masters,id',
            'exam_id' => 'required|exists:exam_masters,id',
        ]);

        $user = Auth::user();

        $marksData = [
            'session_id' => $request->current_session,
            'class_id' => $request->class_id,
            'subject_id' => $request->subject_id,
            'exam_id' => $request->exam_id,
            'min_marks' => $request->min_marks,
            'max_marks' => $request->max_marks,
            'edit_user_id' => $user->id,
            'active' => 1,
        ];
        $query = MarksMaster::query();
        if ($request->id !== '') {
            $marks = $query->find($request->id);
            if ($marks) {
                $marksData['add_user_id'] = $marks->add_user_id;
            }
            else {
                $marksData['add_user_id'] = $user->id;
            }
        }
        $marks = $query->updateOrCreate(['id' => $request->id], $marksData);

        if ($marks) {
            return redirect()->route('admin.marks-master.index')->with('success', $request->id ? 'Marks updated successfully.' : 'Marks saved successfully.');
        } else {
            return redirect()->back()->with('error', 'Something went wrong, please try again.');
        }
    }


    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
        $marks = MarksMaster::findOrFail($id);
        if ($marks > 0) {
            // $exams = ExamMaster::where('id',$marks->exam_id)->where('active',1)->get();
            // if ($exams > 0) {
                # code...
                // return view('admin.marks.create',compact('marks','exams'));
                return view('admin.marks.create',compact('marks'));
            // }
        }else {
            return redirect()->back()->with('error', 'Something went wrong, please try again.');
        }

    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }
}
