<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Admin\ExamMaster;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class ExamMasterController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //

        $data['data'] = ExamMaster::where('active', 1)->orderBy('created_at', 'DESC')->paginate(10);
        return view('admin.exam.index', $data);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
        return view('admin.exam.create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
        $request->validate([
            'exam' => 'required|unique:exam_masters,exam,' . $request->id . ',id,active,1',
            'show_y_n' => 'required',
        ]);
        $user = Auth::user();

        $examData = [
            'exam' => $request->exam,
            'show_y_n' => $request->show_y_n,
            'edit_user_id' => $user->id,
            'active' => 1,

        ];
        $query = ExamMaster::query();
        if ($request->id !== '') {
            $exam = $query->find($request->id);
            if ($exam) {
                $examData['add_user_id'] = $exam->add_user_id;
            } else {
                $examData['add_user_id'] = $user->id;
            }
        }

        $exam = $query->updateOrCreate(['id' => $request->id], $examData);

        if ($exam) {
            return redirect()->route('admin.exam-master.index')->with('success', $request->id ? 'Exam updated successfully.' : 'Exam saved successfully.');
        } else {
            return redirect()->back()->with('error', 'Something went wrong, please try again.');
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
        $exam = ExamMaster::findOrFail($id);

        if ($exam !== null) {
            # code...
            return view('admin.exam.create', compact('exam'));
        } else {
            return redirect()->back()->with('error', 'Something went wrong, please try again.');
        }
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }

    //get exams

    public function getExam(){
        try {
            $exams = ExamMaster::where('active', 1)->pluck('exam', 'id');
            if ($exams->isNotEmpty()) {
                return response()->json([
                    'status' => 'success',
                    'message' => "All Exams",
                    'data' => $exams,
                ], 200);
            }else {
                return response()->json([
                    'status' => 'success',
                    'message' => "No Exam found",
                    'data' => [],
                ], 200);
            }
        } catch (\Exception $e) {
            return response()->json([
                'status' => 'error',
                'message' => "Failed to get exams " . $e->getMessage()
            ], 500);

        }
    }

    // public function softDelete($id)
    // {
    //     try {
    //         $examData = ['active' => 0];

    //         $exam = ExamMaster::find($id);
    //         if ($exam) {
    //             $exam->update($examData);
    //             return response()->json(['status' => 'success', 'message' => 'Exam deleted successfully.']);
    //         } else {
    //             return response()->json(['status' => 'error', 'message' => 'Failed to delete Exam.'], 404);
    //         }
    //     } catch (\Exception $e) {
    //         return response()->json(['status' => 'error', 'message' => 'An error occurred while deleting.'], 500);
    //     }
    // }
}
