<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Admin\ClassMaster;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class ClassMasterController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
        $query = ClassMaster::query();
        if ($query) {
            # code...
            $data['data'] = $query->where('active',1)->orderBy('sort', 'ASC')->paginate(10);
            return view('admin.class.index', $data);
        }else {
            return redirect()->back()->with('error', 'Something went wrong, please try again.');
        }

    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
        return view('admin.class.create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $request->validate([
            'class' => 'required|string|unique:class_masters,class,' . $request->id . ',id,active,1',
            'sort' => 'required|integer|unique:class_masters,sort,' . $request->id . ',id,active,1',

        ]);
        $user = Auth::user();
        $classData = [
            'class' => $request->class,
            'sort' => $request->sort,
            'add_user_id' => $user->id,
            'edit_user_id' => $user->id,
            'active' => 1,

        ];
        $query = ClassMaster::query();
        if ($query) {
            # code...
            if ($request->id !== '') {
                $class = $query->find($request->id);
                if ($class !== null) {
                    $classData['add_user_id'] = $class->add_user_id;
                }
            } else {
                $classData['add_user_id'] = $user->id;
            }

            $class = $query->updateOrCreate(['id' => $request->id], $classData);

            if ($class) {
                return redirect()->route('admin.class-master.index')->with('success', $request->id ? 'Class updated successfully.' : 'Class saved successfully.');
            } else {
                return redirect()->back()->with('error', 'Something went wrong, please try again.');
            }
        }else{
            return redirect()->back()->with('error', 'Something went wrong, please try again.');
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(ClassMaster $classMaster)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit($id)
    {
        //
        if ($id) {
            # code...
            $data['data'] = ClassMaster::where('id', $id)->first();
            return view('admin.class.create', $data);
        }else{
            return redirect()->back()->with('error', 'Something went wrong, please try again.');
        }
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, ClassMaster $classMaster)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */

    // public function softDelete($id)
    // {
    //     try {
    //         $classData = ['active' => 0];

    //         $class = ClassMaster::find($id);
    //         if ($class) {
    //             $class->update($classData);
    //             return response()->json(['status' => 'success', 'message' => 'Class Master deleted successfully.']);
    //         } else {
    //             return response()->json(['status' => 'error', 'message' => 'Failed to delete Class Master.'], 404);
    //         }
    //     } catch (\Exception $e) {
    //         return response()->json(['status' => 'error', 'message' => 'An error occurred while deleting.'], 500);
    //     }
    // }

    /**
     * Get all the classes
     */

    public function getClasses(){
        try {
            $classes = ClassMaster::where('active', 1)->orderBy('sort', 'ASC')->pluck('class', 'id');
            if ($classes->isNotEmpty()) {
                return response()->json([
                    'status' => 'success',
                    'message' => "All Classes",
                    'data' => $classes,
                ], 200);
            }else {
                return response()->json([
                    'status' => 'success',
                    'message' => "No Classes found",
                    'data' => [],
                ], 200);
            }
        } catch (\Exception $e) {
            return response()->json([
                'status' => 'error',
                'message' => "Failed to get classes " . $e->getMessage()
            ], 500);

        }
    }
}
