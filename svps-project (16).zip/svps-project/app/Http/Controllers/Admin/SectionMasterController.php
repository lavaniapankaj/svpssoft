<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Admin\ClassMaster;
use App\Models\Admin\SectionMaster;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;
use Illuminate\Validation\Rules\Unique;

class SectionMasterController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        $query =  SectionMaster::query();
        if ($query) {
            if (filled($request->class_id)) {
                $data['class'] = $request->class_id;
                $data['class'] =  $query->where('class_id', $request->class_id)->where('active', 1);
            }
            $data = $query->with('class')->where('active', 1)->orderBy('created_at', 'DESC')->paginate(10);
            if ($data !== null) {
                # code...
                return view('admin.section.index', compact('data'));
            }
        } else {
            return redirect()->back()->with('error', 'Something went wrong, please try again.');
        }
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('admin.section.create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //

        $request->validate([
            'section' => [
                'required',
                'string',
                Rule::unique('section_masters')->where(function ($query) use ($request) {
                    return $query->where('class_id', $request->class_id)->where('active', 1);
                })->ignore($request->id),
            ],
            'class_id' => 'required|exists:class_masters,id',
        ]);
        $user = Auth::user();

        $sectionData = [
            'section' => $request->section,
            'class_id' => $request->class_id,
            'edit_user_id' => $user->id,
            'active' => 1,

        ];
        $query = SectionMaster::query();
        if ($request->id !== '') {
            $section = $query->find($request->id);
            if ($section !== null) {
                $sectionData['add_user_id'] = $section->add_user_id;
            } else {
                $sectionData['add_user_id'] = $user->id;
            }
            $section = $query->updateOrCreate(['id' => $request->id], $sectionData);
            if ($section) {
                return redirect()->route('admin.section-master.index')->with('success', $request->id ? 'Section updated successfully.' : 'Section saved successfully.');
            }
        } else {
            return redirect()->back()->with('error', 'Something went wrong, please try again.');
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(SectionMaster $sectionMaster)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit($id)
    {
        if ($id) {
            $section = SectionMaster::findOrFail($id);
            if ($section !== null) {
                return view('admin.section.create', compact('section'));
            }
        } else {
            return redirect()->back()->with('error', 'Something went wrong, please try again.');
        }

        // $classes = ClassMaster::where('active', 1)->get();

    }


    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, SectionMaster $sectionMaster)
    {
        //
    }

    /**
     * get the sections according to the class
     */

    // public function getSections(Request $request)
    // {
    //     try {
    //         $validator = Validator::make($request->all(), [
    //             'class_id' => 'required|exists:class_masters,id',
    //         ]);
    //         if ($validator->fails()) {
    //             return response()->json([
    //                 'status' => 'error',
    //                 'message' => $validator->errors()
    //             ], 400);
    //         }
    //         $classId = $request->input('class_id');
    //         if (!empty($classId)) {
    //             $sections = SectionMaster::where('class_id', $classId)
    //                 ->where('active', 1)
    //                 ->pluck('section', 'id');
    //             if ($sections->isNotEmpty()) {
    //                 return response()->json([
    //                     'status' => 'success',
    //                     'message' => "All class sections",
    //                     'data' => $sections,
    //                 ], 200);
    //             }
    //         } else {
    //             return response()->json([
    //                 'status' => 'error',
    //                 'message' => "Please Select the class",
    //             ], 400);
    //         }
    //     } catch (\Exception $e) {
    //         return response()->json([
    //             'status' => 'error',
    //             'message' => "Failed to get sections " . $e->getMessage()
    //         ], 500);
    //     }
    // }




    public function getSections(Request $request)
    {
        try {
            $validator = Validator::make($request->all(), [
               'class_id' => 'required|exists:class_masters,id',
            ]);
            if ($validator->fails()) {
                return response()->json([
                    'status' => 'error',
                    'message' => $validator->errors()
                ], 400);
            }

            // $classIds = $request->input('class_id');
            $classIds = explode(",", $request->class_id);
            // dd($classIds);
            if (!empty($classIds)) {
                // Get sections for multiple class IDs
                $sections = SectionMaster::whereIn('class_id', $classIds)
                    ->where('active', 1)
                    ->pluck('section', 'id');

                if ($sections->isNotEmpty()) {
                    return response()->json([
                        'status' => 'success',
                        'message' => "All class sections",
                        'data' => $sections,
                    ], 200);
                } else {
                    return response()->json([
                        'status' => 'error',
                        'message' => "No sections found for the provided classes.",
                    ], 404);
                }
            } else {
                return response()->json([
                    'status' => 'error',
                    'message' => "Please Select the class",
                ], 400);
            }
        } catch (\Exception $e) {
            return response()->json([
                'status' => 'error',
                'message' => "Failed to get sections: " . $e->getMessage()
            ], 500);
        }
    }


    /**
     * Remove the specified resource from storage.
     */

    // public function softDelete($id)
    // {
    //     try {
    //         $sectionData = ['active' => 0];

    //         $section = SectionMaster::find($id);
    //         if ($section) {
    //         $section->update($sectionData);
    //             return response()->json(['status' => 'success', 'message' => 'Section Master deleted successfully.']);
    //         } else {
    //             return response()->json(['status' => 'error', 'message' => 'Failed to delete Section Master.'], 404);
    //         }
    //     } catch (\Exception $e) {
    //         return response()->json(['status' => 'error', 'message' => 'An error occurred while deleting.'], 500);
    //     }
    // }
}
