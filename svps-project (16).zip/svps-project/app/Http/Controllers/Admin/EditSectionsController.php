<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Admin\ClassMaster;
use App\Models\Admin\FeeMaster;
use App\Models\Admin\MarksMaster;
use App\Models\Admin\SectionMaster;
use App\Models\Admin\SessionMaster;
use App\Models\Fee\FeeDetail;
use App\Models\Marks\Marks;
use App\Models\Student\StudentMaster;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;

class EditSectionsController extends Controller
{
    //
    public function index()
    {
        return view('admin.editSections.index');
    }

    public function editStd()
    {
        return view('admin.editSections.std');
    }

    public function editStdAdmissionPromotion()
    {
        return view('admin.editSections.std_change_admission_promotion');
    }
    public function editStdAdmissionDate()
    {
        return view('admin.editSections.std_add_delete_admission_date');
    }
    public function editStdByPreSrno()
    {
        return view('admin.editSections.edit_std_prev_records');
    }
    public function editStdRollSection()
    {
        return view('admin.editSections.std_set_section_rollno');
    }
    public function editResult()
    {
        return view('admin.editSections.edit_result');
    }
    public function editRemoveRelativeStd()
    {
        return view('admin.editSections.edit_remove_relative_students');
    }
    public function editStdInfoClass()
    {
        return view('admin.editSections.edit_student_info_class_wise');
    }

    public function editStdMarks()
    {
        return view('admin.editSections.edit_std_marks');
    }

    public function editStdAttendance()
    {
        return view('admin.editSections.edit_std_attendance');
    }

    public function editRemoveStdFee()
    {
        return view('admin.editSections.edit_remove_std_fee_entry');
    }

    public function editStdFeeDetailsView()
    {
        return view('admin.editSections.edit_fee_details_std');
    }
    public function editResultStore(Request $request)
    {
        $request->validate([
            'session_id' => 'required|exists:session_masters,id',
            'resultDate' => 'required|date_format:Y-m-d',
        ]);
        // dd($request->all());
        $user = Auth::user();
        $sessionMaster = SessionMaster::where('id', $request->session_id)->where('active', 1)->first();

        if ($sessionMaster) {
            $sessionMaster->update(['result_date' => $request->resultDate]);
            return redirect()->route('admin.editSection.editResult')->with('success', 'Result Date updated successfully.');
        } else {
            return redirect()->back()->with('error', 'Active session not found. Please try again.');
        }
    }

    public function editStdMarksStore(Request $request)
    {
        try {
            $validator = Validator::make($request->all(), [
                'class_id' => 'required|exists:class_masters,id',
                'section_id' => 'required|exists:section_masters,id',
                'subject' => 'required|exists:subject_masters,id',
                'exam' => 'required|exists:exam_masters,id',
                'std_id' => 'required|exists:stu_main_srno,srno',
                'attendance' => 'required|in:1',
                'marks' => [
                    'required',
                    'numeric',
                    function ($attribute, $value, $fail) use ($request) {
                        //  marks not be greater than
                        $threshold = MarksMaster::where('session_id', $request->current_session)
                            ->where('class_id', $request->class_id)->where('subject_id', $request->subject)
                            ->where('exam_id', $request->exam)->where('active', 1)->value('max_marks');
                        if ($value > $threshold) {
                            $fail("The $attribute must not be greater than $threshold.");
                        }
                    },
                ],
            ]);

            if ($validator->fails()) {
                return response()->json([
                    'status' => 'error',
                    'message' => $validator->errors()
                ], 400);
            }

            $user = Auth::user();





            $marks = Marks::updateOrCreate(
                [
                    'session_id' => $request->current_session,
                    'class_id' => $request->class_id,
                    'srno' => $request->std_id,
                    'subject_id' => $request->subject,
                    'exam_id' => $request->exam,
                ],
                [
                    // 'session_id' => $request->current_session,
                    // 'class_id' => $request->class_id,
                    // 'exam_id' => $request->exam,
                    // 'subject_id' => $request->subject,
                    // 'srno' => $request->std_id,
                    'marks' => $request->marks,
                    'attendance' => $request->attendance,
                    'add_user_id' => $user->id,
                    'edit_user_id' => $user->id,
                    'active' => 1,
                ]
            );
            // dd($request->all());
            if ($marks) {
                return response()->json([
                    'status' => 'success',
                    'message' => "Student Marks updated successfully.",
                ], 200);
                // return redirect()->route('admin.class-master.index')->with('success', 'Student Marks updated successfully.');
            } else {
                // return redirect()->back()->with('error', 'Something went wrong, please try again.');
                return response()->json([
                    'status' => 'error',
                    'message' => 'Something went wrong, please try again.',
                ], 422);
            }
        } catch (\Exception $e) {
            return response()->json([
                'status' => 'error',
                'message' => "Failed to get std " . $e->getMessage()
            ], 500);
        }
    }

    public function editStdStore(Request $request)
    {
        $requiredFields = [
            'current_session',
            'srno',
            'school',
            'class',
            'section',
            'rollno',
            'age_proof',
            'gender',
            'religion',
            // 'admission_date',
            'name',
            // 'dob',
            'std_email',
            'mobile',
            'category_id',
            'state_id',
            'district_id',
            'pincode',
            'address',
            'f_name',
            'g_father',
            // 'f_mobile',
            'm_name',
            'parent_category_id',
            'f_occupation',
            'm_occupation',
            'parent_email',
            'parent_state_id',
            'parent_district_id',
            'pin_code',
            'parent_address'
        ];

        dd($request->all());
        $request->validate([
            'srno' => [
                'nullable',
                'string',
                'max:255',
                Rule::unique('stu_main_srno')->where(function ($query) use ($request) {
                    return $query->whereNotNull('admission_date')->whereNotNull('form_submit_date')->where('active', 1);
                })->ignore($request->id),
            ],
            'school' => 'nullable',
            'class' => 'nullable',
            'section' => 'nullable',
            'rollno' => 'nullable|numeric',
            'transport' => 'nullable',
            'age_proof' => 'nullable',
            'gender' => 'nullable',
            'religion' => 'nullable',
            'admission_date' => 'nullable|date_format:Y-m-d',
            'prev_srno' => 'nullable|string|max:255',
            'trans_1st_inst' => 'nullable|numeric|min:0',
            'trans_2nd_inst' => 'nullable|numeric|min:0',
            'trans_total' => 'nullable|numeric|min:0',
            'trans_discount' => 'nullable|numeric|min:0',
            'reason' => 'nullable|string|max:255',
            'TCRefNo' => 'nullable|string|max:100',
            'state_id' => 'nullable|exists:state_masters,id',
            'district_id' => 'nullable|exists:district_masters,id',
            'category_id' => 'nullable',
            'address' => 'nullable|string|max:255',
            'name' => 'nullable|string|max:255',
            'dob' => 'nullable|date_format:Y-m-d',
            'mobile' => 'nullable|regex:/^[0-9]{10}$/',
            'pincode' => 'nullable|regex:/^[0-9]{6}$/',
            'pre_school' => 'nullable|string|max:255',
            'pre_class' => 'nullable|string|max:50',
            'f_name' => 'nullable|string|max:255',
            'm_name' => 'nullable|string|max:255',
            'g_father' => 'nullable|string|max:255',
            'parent_email' => 'nullable|email|max:255',
            'std_email' => 'nullable|email|max:255',
            'f_mobile' => 'nullable|string|regex:/^[0-9]{10}$/',
            'pin_code' => 'nullable|string|regex:/^[0-9]{6}$/',
            'f_occupation' => 'nullable|string|max:255',
            'm_occupation' => 'nullable|string|max:255',
            'm_mobile' => 'nullable|string|regex:/^[0-9]{10}$/',
        ]);

        $user = Auth::user();
        $allFieldsFilled = collect($requiredFields)->every(function ($field) use ($request) {
            return !empty($request->input($field));
        });

        $studentData = [
            'srno' => $request->srno,
            'school' => $request->school,
            'class' => $request->class,
            'section' => $request->section,
            'rollno' => $request->rollno,
            'session_id' => $request->current_session,
            'transport' => $request->transport,
            'age_proof' => $request->age_proof,
            'gender' => $request->gender,
            'religion' => $request->religion,
            'admission_date' => $request->admission_date,
            'prev_srno' => $request->prev_srno,
            'form_submit_date' => Carbon::now()->format('Y-m-d'),
            'trans_1st_inst' => $request->trans_1st_inst,
            'trans_2nd_inst' => $request->trans_2nd_inst,
            'trans_total' => $request->trans_total,
            'trans_discount' => $request->trans_discount,
            'reason' => $request->reason,
            'TCRefNo' => $request->TCRefNo,
            'edit_user_id' => $user->id,
            'active' => $allFieldsFilled ? 1 : 0,
        ];

        $student = StudentMaster::updateOrCreate(
            ['id' => $request->id],
            array_merge($studentData, [
                'add_user_id' => $request->id ? StudentMaster::find($request->id)->add_user_id : $user->id,
            ])
        );

        $commonData = [
            'add_user_id' => $user->id,
            'edit_user_id' => $user->id,
            'active' =>  1,
        ];
        $stuDetailData = array_merge($commonData, [
            'name' => $request->name,
            'dob' => $request->dob,
            'mobile' => $request->mobile,
            'email' => $request->std_email,
            'pincode' => $request->pincode,
            'pre_school' => $request->pre_school,
            'pre_class' => $request->pre_class,
            'category_id' => $request->category_id,
            'state_id' => $request->state_id,
            'district_id' => $request->district_id,
            'address' => $request->address,
        ]);

        DB::table('stu_detail')->updateOrInsert(
            ['srno' => $request->srno],
            $stuDetailData
        );

        $parentsDetailData = array_merge($commonData, [
            'f_name' => $request->f_name,
            'm_name' => $request->m_name,
            'g_father' => $request->g_father,
            'email' => $request->parent_email,
            'f_mobile' => $request->f_mobile,
            'pin_code' => $request->pin_code,
            'f_occupation' => $request->f_occupation,
            'm_occupation' => $request->m_occupation,
            'm_mobile' => $request->m_mobile,
            'category_id' => $request->parent_category_id,
            'state_id' => $request->parent_state_id,
            'district_id' => $request->parent_district_id,
            'address' => $request->parent_address,
        ]);

        DB::table('parents_detail')->updateOrInsert(
            ['srno' => $request->srno],
            $parentsDetailData
        );

        $message = $request->id ? 'Student updated successfully.' : 'Student saved successfully.';
        // if ($request->controller === 'EditSectionsController') {
        //     return redirect()->route('admin.editSection.index')->with('success', $message);
        // } else {
        return redirect()->route('admin.editSection.std')->with('success', $message);
        // }
    }

    public function editStdEdit(string $id)
    {
        if ($id) {
            # code...
            $student = StudentMaster::findOrFail($id);
            if ($student !== null) {
                # code...
                $parent_detail = DB::table('parents_detail')->where('srno', $student->srno)->where('active', 1)->first();
                $student_detail = DB::table('stu_detail')->where('srno', $student->srno)->where('active', 1)->first();
                return view('admin.student.create', compact('student', 'parent_detail', 'student_detail'));
            }
        } else {
            return redirect()->back()->with('error', 'Something went wrong, please try again.');
        }
    }

    public function editStdRollSectionStore(Request $request)
    {
        $data = $request->validate([
            'students' => 'required|array',
            'students.*.srno' => 'required|exists:stu_main_srno,srno',
            'students.*.rollno' => 'nullable|numeric',
            'students.*.sectionSecond' => 'nullable|exists:section_masters,id',
            'students.*.sectionCheck' => 'sometimes|required|boolean',
        ]);

        foreach ($data['students'] as $std) {
            $student = StudentMaster::where('srno', $std['srno'])->where('ssid', 1)->first();
            $updates = [];
            if ($student) {
                if (isset($std['rollno'])) {
                    $updates['rollno'] = $std['rollno'];
                }
                if (isset($std['sectionCheck']) && $std['sectionCheck']  && isset($std['sectionSecond'])) {
                    $updates['section'] = $std['sectionSecond'];
                }
            }
            if (!empty($updates)) {
                $student->update($updates);
                return redirect()->route('admin.editSection.editStdRollSection')->with('success', 'Students updated successfully.');
            } else {
                return redirect()->back()->with('error', 'Something went wrong, please try again.');
            }
        }
    }
    public function editRemoveRelativeStdStore(Request $request)
    {
        $request->validate([
            'std_id' => 'required|exists:stu_main_srno,srno',
            'second_std_id' => 'required|exists:stu_main_srno,srno',
        ]);
        $std = StudentMaster::where('srno', $request->std_id)->where('ssid', 1)->first();
        $secondStd = StudentMaster::where('srno', $request->second_std_id)->where('ssid', 1)->first();

        if ($std || $secondStd) {
            $stdRelationCode = $std->relation_code;
            $secondStdRelationCode = $secondStd ? $secondStd->relation_code : null;

            if ($stdRelationCode === null && $secondStdRelationCode === null) {
                $maxRelationCode = StudentMaster::max('relation_code');
                $newRelationCode = $maxRelationCode ? $maxRelationCode + 1 : 1;
                $std->update(['relation_code' => $newRelationCode]);
                $secondStd->update(['relation_code' => $newRelationCode]);
            } else {
                if ($stdRelationCode !== null && $secondStdRelationCode === null) {
                    $secondStd->update(['relation_code' => $stdRelationCode]);
                }
            }
            return redirect()->route('admin.editSection.editRemoveRelativeStd')->with('success', 'Students updated successfully.');
        } else {
            return redirect()->back()->with('error', 'Something went wrong, please try again.');
        }
    }
    public function editRemoveRelativeStdRemove($id)
    {
        $stdData = ['relation_code' => null];
        $std = StudentMaster::where('srno', $id)->first();
        if ($std) {
            $std->update($stdData);
            return redirect()->route('admin.editSection.editRemoveRelativeStd')->with('success', 'Remove successfully.');
        } else {
            return redirect()->back()->with('error', 'Something went wrong, please try again.');
        }
    }

    public function editStdInfoClassStore(Request $request)
    {
        $data = $request->validate([
            'students' => 'required|array',
            'students.*.srno' => 'required|exists:stu_main_srno,srno',
            'students.*.student_name' => 'required|string',
            'students.*.f_name' => 'required|string|max:255',
            'students.*.m_name' => 'required|string|max:255',
            'students.*.g_f_name' => 'required|string|max:255',
            'students.*.dob' => 'required|date_format:Y-m-d',
            'students.*.f_mobile' => 'required|regex:/^[0-9]{10}$/',
            'students.*.m_mobile' => 'nullable|regex:/^[0-9]{10}$/',
            'students.*.age_proof' => 'required',
        ]);

        foreach ($data['students'] as $std) {
            $student = StudentMaster::where('srno', $std['srno'])->where('ssid', 1)->first();
            if ($student) {
                $stdDetail = DB::table('stu_detail')->where('srno', $student->srno);
                if ($stdDetail) {
                    $stdDetail->update(
                        [
                            'name' => $std['student_name'],
                            'dob' => $std['dob'],
                        ]
                    );
                }
                $stdParentDetail = DB::table('parents_detail')->where('srno', $student->srno);
                if ($stdParentDetail) {
                    $stdParentDetail->update(
                        [
                            'f_name' => $std['f_name'],
                            'm_name' => $std['m_name'],
                            'g_father' => $std['g_f_name'],
                            'f_mobile' => $std['f_mobile'],
                            'm_mobile' => $std['m_mobile'],
                        ]

                    );
                }
                $student->update(
                    [
                        'age_proof' => $std['age_proof']
                    ]
                );
            }
        }
        return redirect()->route('admin.editSection.editStdInfoClass')->with('success', 'Student updated successfully.');
    }

    public function editStdAdmissionDateStore(Request $request)
    {
        $request->validate(
            [
                'a_date' => 'required|date_format:Y-m-d'
            ]
        );
        $std = StudentMaster::where('srno', $request->hidden_srno)->where('active', 1)->first();
        if ($std) {
            $std->update(['admission_date' => $request->a_date]);
            return redirect()->route('admin.editSection.editStdAdmissionDate')->with('success', 'Student Admission Date updated successfully.');
        } else {
            return redirect()->back()->with('error', 'Something went wrong, please try again.');
        }
    }

    public function editStdByPreSrnoStore(Request $request)
    {
        // dd($request->all());
        $request->validate(
            [
                'std_name' => 'required|string|max:255',
                'f_name' => 'required|string|max:255',
                'm_name' => 'required|string|max:255',
                'dob' => 'required|date_format:Y-m-d',
                'category' => 'required',
                'address' => 'required',
            ]
        );
        $student = StudentMaster::where('srno', $request->std_srno)->where('active', 1)->first();
        if ($student) {
            $stdDetail = DB::table('stu_detail')->where('srno', $student->srno);
            if ($stdDetail) {
                $stdDetail->update(
                    [
                        'name' => $request->std_name,
                        'dob' => $request->dob,
                        'category_id' => $request->category,
                        'address' => $request->address,
                    ]
                );
            }
            $stdParentDetail = DB::table('parents_detail')->where('srno', $student->srno);
            if ($stdParentDetail) {
                $stdParentDetail->update(
                    [
                        'f_name' => $request->f_name,
                        'm_name' => $request->m_name,
                    ]

                );
            }
            return redirect()->route('admin.editSection.editStdByPreSrno')->with('success', 'Student updated successfully.');
        } else {
            return redirect()->back()->with('error', 'Something went wrong, please try again.');
        }
    }

    public function editStdAdmissionPromotionStore(Request $request)
    {

        $validates = $request->validate([
            'hidden_srno' => 'required|string|max:255',
            'hidden_a_date' => 'nullable|date_format:Y-m-d',
            'hidden_p_date' => 'nullable|date_format:Y-m-d',
            'a_p_date' => 'required|date_format:Y-m-d',
        ]);
        if ($validates) {
            # code...
            $query = StudentMaster::query();
            if (!empty($request->hidden_a_date)) {
                $query->where('srno', $request->hidden_srno)
                    ->where('admission_date', $request->hidden_a_date)
                    ->update(['admission_date' => $request->a_p_date]);
            } else {
                $query->where('srno', $request->hidden_srno)
                    ->where('form_submit_date', $request->hidden_p_date)
                    ->update(['form_submit_date' => $request->a_p_date]);
            }
            return redirect()->route('admin.editSection.editStdAdmissionPromotion')->with('success', 'Student updated successfully.');
        } else {
            return redirect()->back()->with('error', 'Something went wrong, please try again.');
        }
    }

    public function stdFeeDetailFetch(Request $request)
    {
        try {
            $validator = Validator::make($request->all(), [
                'srno' => 'required|exists:stu_main_srno,srno',
            ]);
            if ($validator->fails()) {
                return response()->json([
                    'status' => 'error',
                    'message' => $validator->errors()
                ], 400);
            }

            $feeDetails = FeeDetail::where('srno', $request->srno)->where('session_id', $request->session)
                ->get(['ref_slip_no', 'pay_date', 'academic_trans', 'fee_of', 'amount', 'paid_mercy', 'srno', 'id']);

            if ($feeDetails->isNotEmpty()) {
                # code...
                return response()->json([
                    'status' => 'success',
                    'data' => $feeDetails
                ], 200);
            } else {
                # code...
                return response()->json([
                    'status' => 'success',
                    'message' => 'No Fee Detail Found',
                    'data' => []
                ], 200);
            }
        } catch (\Exception $e) {
            return response()->json([
                'status' => 'error',
                'message' => "Failed to get student fee detail: " . $e->getMessage()
            ], 500);
        }
    }

    public function stdFeeEdit(Request $request)
    {
        try {
            $validator = Validator::make($request->all(), [
                'refSlip' => 'nullable|exists:fee_details,ref_slip_no',
                'pay_date' => 'required|date_format:Y-m-d',
                'academicTrans' => 'required|exists:fee_details,academic_trans',
                'feeOf' => 'required|string|max:255',
                'amount' => 'required|numeric',
                'paidMercy' => 'nullable|numeric',
                'srno' => 'required|exists:fee_details,srno',
            ]);
            if ($validator->fails()) {
                return response()->json([
                    'status' => 'error',
                    'message' => $validator->errors()
                ], 400);
            }

            $user = Auth::user();
            # code...
            FeeDetail::updateOrCreate([
                'srno' => $request->srno,
                'session_id' => $request->session,
                'fee_of' => $request->feeOf,
                'academic_trans' => $request->academicTrans,
                'paid_mercy' => $request->paidMercy,
                'ref_slip_no' => $request->refSlip ?? null,
            ], [
                'amount' => $request->amount,
                'pay_date' => $request->pay_date,
                'edit_user_id' => $user->id,

            ]);
            return response()->json([
                'status' => 'success',
                'message' => 'Fee Detail updated successfully',
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                'status' => 'error',
                'message' => "Failed to get student fee detail: " . $e->getMessage()
            ], 500);
        }
    }

    public function stdFeeRemove($id)
    {
        try {
            // $fee = FeeDetail::where('srno', $request->srno)->where('session_id', $request->session)->where('academic_trans', $request->academicTrans)->where('paid_mercy', $request->paidMercy)->where('ref_slip_no', $request->refSlip)->first();
            $fee = FeeDetail::find($id);
            if ($fee) {
                $fee->delete();
                return response()->json(['status' => 'success', 'message' => 'Student Fee Detail deleted successfully.']);
            } else {
                return response()->json(['status' => 'error', 'message' => 'Failed to delete Class Master.'], 404);
            }
        } catch (\Exception $e) {
            return response()->json(['status' => 'error', 'message' => 'An error occurred while deleting.'], 500);
        }
    }

    public function mercyFeeBoth()
    {
        return view('admin.editSections.edit_std_mercy_fee_both');
    }

    // public function mercyFeeBothStore(Request $request)
    // {
    //     try {
    //         //code...
    //         $academic_trans_value = isset($request->transport) ? $request->transport : 1;
    //         $session = $request->session;
    //         $student = StudentMaster::where('srno', $request->std_id)->where('active', 1)->where('ssid', 1)->first();
    //         if (!$student) {
    //             return response()->json([
    //                 'status' => 'error',
    //                 'message' => 'Student not found for the given SRNO.'
    //             ], 404);
    //         }

    //         $feeMaster = FeeMaster::where('class_id', $request->class)->where('session_id', $session)->where('active', 1)->first(
    //             ['admission_fee', 'inst_1', 'inst_2', 'inst_total', 'ins_discount']
    //         );

    //         if (isset($request->transport)) {
    //             # code...

    //             if ($student->transport == 0) {
    //                 # code...
    //                 return response()->json([
    //                     'status' => 'error',
    //                     'message' => 'No Transport Fee Applicable For This Student.'
    //                 ], 404);
    //             }
    //         }
    //         $tcsArray =  [
    //             'inst_1' => $student->trans_1st_inst,
    //             'inst_2' => $student->trans_2nd_inst,
    //             'inst_total' => $student->trans_total,
    //             'ins_discount' => $student->trans_discount,
    //         ];
    //         $tcs = (object) $tcsArray;
    //         $fee_master_fees = isset($request->transport) ? $tcs : $feeMaster;

    //         $admission_fee_paid = FeeDetail::where('srno', $request->std_id)->where('academic_trans', $academic_trans_value)->where('fee_of', 1)->exists();
    //         $baseQuery = FeeDetail::where('srno', $request->std_id)->where('session_id', $session)->where('academic_trans', $academic_trans_value)->get();
    //         // dd($baseQuery);
    //         $first_inst_fee_total = $baseQuery->where('fee_of', 2)->sum('amount');
    //         // dd($first_inst_fee_total);
    //         $second_inst_fee_total = $baseQuery->where('fee_of', 3)->sum('amount');
    //         $complete_fee_total = $baseQuery->where('fee_of', 4)->where('paid_mercy', 1)->sum('amount');
    //         $mercy_fee_total = $baseQuery->where('fee_of', 4)->where('paid_mercy', 2)->sum('amount');


    //         $first_inst_fee_exists = FeeDetail::where('srno', $request->std_id)->where('session_id', $session)->where('academic_trans', $academic_trans_value)->where('fee_of', 2)->where('paid_mercy', 1)->exists();
    //         // dd($first_inst_fee_exists);

    //         $second_inst_fee_exists = FeeDetail::where('srno', $request->std_id)->where('session_id', $session)->where('academic_trans', $academic_trans_value)->where('fee_of', 3)->where('paid_mercy', 1)->exists();

    //         $complete_fee_exists = FeeDetail::where('srno', $request->std_id)->where('session_id', $session)->where('academic_trans', $academic_trans_value)->where('fee_of', 4)->where('paid_mercy', 1)->exists();
    //         $mercy_fee_exists = FeeDetail::where('srno', $request->std_id)->where('session_id', $session)->where('academic_trans', $academic_trans_value)->where('fee_of', 4)->where('paid_mercy', 2)->exists();

    //         $validator = Validator::make($request->all(), [
    //             'class' => 'required|exists:class_masters,id',
    //             'section' => 'required|exists:section_masters,id',
    //             'session' => 'required|exists:session_masters,id',
    //             'mercy_date' => 'required|date_format:Y-m-d',
    //             'amount' => [
    //                 'required',
    //                 'regex:/^\d*(\.\d{2})?$/',
    //                 function ($attribute, $value, $fail) use ($first_inst_fee_exists, $second_inst_fee_exists, $complete_fee_exists, $mercy_fee_total, $request, $mercy_fee_exists, $fee_master_fees, $first_inst_fee_total, $second_inst_fee_total, $complete_fee_total) {
    //                     if (empty($request->first_inst_fee) && empty($request->second_inst_fee) && empty($request->complete_fee) && !empty($request->mercy_fee)) {
    //                         $totalPaid = 0;
    //                         if ($first_inst_fee_exists == true || $second_inst_fee_exists == true || $complete_fee_exists == true || $mercy_fee_exists == true) {
    //                             # code...
    //                             $totalPaid = $first_inst_fee_total + $second_inst_fee_total + $complete_fee_total + $mercy_fee_total;
    //                             if ($totalPaid == $fee_master_fees->inst_total) {
    //                                 # code...
    //                                 $fail('Already Paid Complete Fee.');
    //                             } else {
    //                                 # code...
    //                                 $dueAmount = $fee_master_fees->inst_total - $totalPaid;
    //                                 if ($request->mercy_fee > $dueAmount) {
    //                                     $fail('Only ' . $dueAmount . ' due of Complete Fee.');
    //                                 }
    //                             }
    //                         }
    //                     }
    //                 },
    //             ]
    //         ]);
    //         if ($validator->fails()) {
    //             return response()->json([
    //                 'status' => 'error',
    //                 'message' => $validator->errors()
    //             ], 400);
    //         }
    //         $recp_no = FeeDetail::max('recp_no');
    //         $user = Auth::user();

    //         if (!empty($request->amount)) {
    //             # code...
    //             $mercyData = [
    //                 'srno' => $request->std_id,
    //                 'session_id' => $session,
    //                 'academic_trans' => $academic_trans_value,
    //                 'pay_date' => $request->mercy_date,
    //                 'fee_of' => 4,
    //                 'amount' => $request->amount,
    //                 'paid_mercy' => 2,
    //                 'recp_no' => null,
    //                 'ref_slip_no' => null,
    //                 'active' => 1,
    //                 'add_user_id' => $user->id,
    //                 'edit_user_id' => $user->id,
    //             ];
    //             FeeDetail::create($mercyData);
    //         }
    //         return response()->json([
    //             'status' => 'success',
    //             'message' => "Fee Submitted Successfully. Slip No. " . ($recp_no ? $recp_no + 1 : 1),
    //         ], 200);
    //     } catch (\Exception $e) {
    //         return response()->json([
    //             'status' => 'error',
    //             'message' => "Failed to insert mercy amount: " . $e->getMessage()
    //         ], 500);
    //     }
    // }

    public function mercyFeeBothStore(Request $request)
    {
        try {
            $academic_trans_value = isset($request->transport) ? (int) $request->transport : 1;
            $session = $request->session;
            $student = StudentMaster::where('srno', $request->std_id)->where('active', 1)->where('ssid', 1)->first();

            if (!$student) {
                return response()->json([
                    'status' => 'error',
                    'message' => 'Student not found for the given SRNO.'
                ], 404);
            }

            $feeMaster = FeeMaster::where('class_id', $request->class)
                ->where('session_id', $session)
                ->where('active', 1)
                ->first(['admission_fee', 'inst_1', 'inst_2', 'inst_total', 'ins_discount']);

            if (isset($request->transport) && $student->transport == 0) {
                return response()->json([
                    'status' => 'error',
                    'message' => 'No Transport Fee Applicable For This Student.'
                ], 404);
            }

            $fee_master_fees = isset($request->transport)
                ? (object) [
                    'inst_1' => $student->trans_1st_inst,
                    'inst_2' => $student->trans_2nd_inst,
                    'inst_total' => $student->trans_total,
                    'ins_discount' => $student->trans_discount,
                ]
                : $feeMaster;

            $baseQuery = FeeDetail::where('srno', $request->std_id)
                ->where('session_id', $session)
                ->where('academic_trans', $academic_trans_value)->get();

            // dd($baseQuery->get());
            $first_inst_fee_total = $baseQuery->where('fee_of', 2)->sum('amount');
            $second_inst_fee_total = $baseQuery->where('fee_of', 3)->sum('amount');
            $complete_fee_total = $baseQuery->where('fee_of', 4)->where('paid_mercy', 1)->sum('amount');
            $mercy_fee_total = $baseQuery->where('fee_of', 4)->where('paid_mercy', 2)->sum('amount');

            $totalPaid = $first_inst_fee_total + $second_inst_fee_total + $complete_fee_total + $mercy_fee_total;

            $validator = Validator::make($request->all(), [
                'class' => 'required|exists:class_masters,id',
                'section' => 'required|exists:section_masters,id',
                'session' => 'required|exists:session_masters,id',
                'mercy_date' => 'required|date_format:Y-m-d',
                'amount' => [
                    'required',
                    'regex:/^\d*(\.\d{2})?$/',
                    function ($attribute, $value, $fail) use ($fee_master_fees, $totalPaid) {
                        if ($totalPaid == $fee_master_fees->inst_total) {
                            $fail('Complete fee has already been paid.');
                        } else {
                            $dueAmount = $fee_master_fees->inst_total - $totalPaid;
                            if ($value > $dueAmount) {
                                $fail("Only {$dueAmount} is due for Complete Fee.");
                            }
                        }
                    },
                ]
            ]);

            if ($validator->fails()) {
                return response()->json([
                    'status' => 'error',
                    'message' => $validator->errors()
                ], 400);
            }

            $user = Auth::user();
            $recp_no = FeeDetail::max('recp_no') + 1;

            FeeDetail::create([
                'srno' => $request->std_id,
                'session_id' => $session,
                'academic_trans' => $academic_trans_value,
                'pay_date' => $request->mercy_date,
                'fee_of' => 4,
                'amount' => $request->amount,
                'paid_mercy' => 2,
                'recp_no' => $recp_no,
                'ref_slip_no' => null,
                'active' => 1,
                'add_user_id' => $user->id,
                'edit_user_id' => $user->id,
            ]);

            return response()->json([
                'status' => 'success',
                'message' => "Mercy Fee Submitted Successfully.",
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                'status' => 'error',
                'message' => "Failed to insert mercy amount: " . $e->getMessage()
            ], 500);
        }
    }

    // public function editStdFeeGetInfo(Request $request)
    // {
    //     try {
    //         $validator = Validator::make($request->all(), [
    //             'computer_slip' => 'required_if:computer_slip,true|exists:fee_details,recp_no,active,'. 1,
    //             'school_slip' => 'required_if:school_slip,true|exists:fee_details,ref_slip_no,active,'. 1,
    //         ]);

    //         if ($validator->fails()) {
    //             return response()->json([
    //                 'status' => 'error',
    //                 'message' => $validator->errors()
    //             ], 400);
    //         }
    //         //code...
    //         // $data = FeeDetail::where('recp_no', $request->computer_slip)->where('active', 1)->where('paid_mercy', 2)->where('academic_trans', 1)->where('session_id', $request->session)->get();
    //         $academic_trans = $request->transport ? 2 : 1;
    //         $data = FeeDetail::query();
    //         if (!empty($request->computer_slip)) {
    //             # code...
    //             $data->where('recp_no', $request->computer_slip)->where('active', 1)->where('paid_mercy', 2)->where('academic_trans', $academic_trans)->where('session_id', $request->session)->get();
    //         }
    //         dd($data);
    //         if (!empty($request->school_slip)) {
    //             # code...
    //             $data->where('ref_slip_no', $request->school_slip)->where('active', 1)->where('paid_mercy', 2)->where('academic_trans', $academic_trans)->where('session_id', $request->session)->get();
    //         }
    //         return response()->json([
    //             'data' => $data,
    //            'status' =>'success',
    //         ], 200);
    //     } catch (\Exception $e) {
    //         return response()->json([
    //             'status' => 'error',
    //             'message' => "Failed to insert mercy amount: " . $e->getMessage()
    //         ], 500);
    //     }
    // }


    // public function editStdFeeGetInfo(Request $request)
    // {
    //     try {
    //         $validator = Validator::make($request->all(), [
    //             'computer_slip' => 'required_if:computer_slip,true|exists:fee_details,recp_no,active,' . 1,
    //             'school_slip' => 'required_if:school_slip,true|exists:fee_details,ref_slip_no,active,' . 1,
    //         ]);

    //         if ($validator->fails()) {
    //             return response()->json([
    //                 'status' => 'error',
    //                 'message' => $validator->errors()
    //             ], 400);
    //         }

    //         $academic_trans = $request->transport ? 2 : 1;
    //         $data = FeeDetail::query();

    //         if (!empty($request->computer_slip) && !empty($request->school_slip)) {
    //             $data->where(function ($query) use ($request) {
    //                 $query->where('recp_no', $request->computer_slip)
    //                     ->orWhere('ref_slip_no', $request->school_slip);
    //             })->where('academic_trans', $academic_trans)
    //                 ->where('session_id', $request->session)
    //                 ->where('active', 1);
    //         } elseif (!empty($request->computer_slip)) {
    //             $data->where('recp_no', $request->computer_slip)
    //                 // ->where('paid_mercy', 2)
    //                 ->where('academic_trans', $academic_trans)
    //                 ->where('session_id', $request->session)
    //                 ->where('active', 1);
    //         } elseif (!empty($request->school_slip)) {
    //             $data->where('ref_slip_no', $request->school_slip)
    //                 // ->where('paid_mercy', 2)
    //                 ->where('academic_trans', $academic_trans)
    //                 ->where('session_id', $request->session)
    //                 ->where('active', 1);
    //         }

    //         return response()->json([
    //             'data' => $data->get(),
    //             'status' => 'success',
    //         ], 200);
    //     } catch (\Exception $e) {
    //         return response()->json([
    //             'status' => 'error',
    //             'message' => "Failed to retrieve fee details: " . $e->getMessage()
    //         ], 500);
    //     }
    // }


    public function editStdFee()
    {
        return view('admin.editSections.edit_fee_details_std');
    }

    public function getStdFeeInfo1(Request $request)
    {
        try {
            $validator = Validator::make($request->all(), [
                'computer_slip' => 'required_if:computer_slip,true|exists:fee_details,recp_no',
                'school_slip' => 'required_if:school_slip,true|exists:fee_details,ref_slip_no',
            ]);

            if ($validator->fails()) {
                return response()->json([
                    'status' => 'error',
                    'message' => $validator->errors()
                ], 400);
            }
            $academic_trans_value = $request->transport;
            $session = $request->session;
            $feeDetails = FeeDetail::query();
            // dd($request->all());

            if ($request->computer_slip) {
                $feeDetails->where('academic_trans', $academic_trans_value)
                    ->where('active', 1)->where('paid_mercy', 1)
                    ->where('recp_no', $request->computer_slip)
                    ->where('session_id', $session);
            } elseif ($request->school_slip) {
                $feeDetails->where('academic_trans', $academic_trans_value)
                    ->where('active', 1)->where('paid_mercy', 1)
                    ->where('ref_slip_no', $request->school_slip)
                    ->where('session_id', $session);
            }

            $data = $feeDetails->get();
            // dd($data);

            if ($data->isEmpty()) {
                return response()->json([
                    'status' => 'error',
                    'message' => "No fee details found."
                ], 404);
            }

            // Assuming you want the first student's class and section.
            $student = StudentMaster::where('srno', $data[0]->srno)
                ->where('ssid', 1)
                ->where('active', 1)
                ->where('session_id', $session)
                ->first();

            if (!$student) {
                return response()->json([
                    'status' => 'error',
                    'message' => "Student not found."
                ], 404);
            }

            $class = ClassMaster::where('id', $student->class)->where('active', 1)->value('id'); // Adjust 'name' if needed
            $section = SectionMaster::where('id', $student->section)->where('active', 1)->value('id'); // Adjust 'name' if needed

            return response()->json([
                'status' => 'success',
                'message' => "Get student fee detail",
                'data' => $data,
                'class' => $class,
                'section' => $section,
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                'status' => 'error',
                'message' => "Failed to get student fee detail: " . $e->getMessage()
            ], 500);
        }
    }

    /**
     * edit student fee store
     */

     public function editStdFeeStore(Request $request)
     {
        try {
            // $academic_trans_value = isset($request->transport) ? $request->transport : 1;
            $academic_trans_value = $request->transport;
            $session = isset($request->session) ? $request->session : $request->current_session;
            $student = StudentMaster::where('srno', $request->std_id)->where('active', 1)->where('ssid', 1)->first();
            if (!$student) {
                return response()->json([
                    'status' => 'error',
                    'message' => 'Student not found for the given SRNO.'
                ], 404);
            }

            $feeMaster = FeeMaster::where('class_id', $request->class)->where('session_id', $session)->where('active', 1)->first(
                ['admission_fee', 'inst_1', 'inst_2', 'inst_total', 'ins_discount']
            );
            // dd($feeMaster);

            if (isset($request->transport) && $request->transport == 2) {
                # code...

                if ($student->transport == 0) {
                    # code...
                    return response()->json([
                        'status' => 'error',
                        'message' => 'No Transport Fee Applicable For This Student.'
                    ], 404);
                }
            }

            $tcsArray =  [
                'inst_1' => $student->trans_1st_inst,
                'inst_2' => $student->trans_2nd_inst,
                'inst_total' => $student->trans_total,
                'ins_discount' => $student->trans_discount,
            ];
            $tcs = (object) $tcsArray;
            $fee_master_fees = isset($request->transport) && $request->transport == 2 ? $tcs : $feeMaster;

            // dd($fee_master_fees);

            $admission_fee_paid = FeeDetail::where('srno', $request->std_id)->where('academic_trans', $academic_trans_value)->where('fee_of', 1)->exists();
            $baseQuery = FeeDetail::where('srno', $request->std_id)->where('session_id', $session)->where('academic_trans', $academic_trans_value)->get();
            // dd($baseQuery);
            $first_inst_fee_total = $baseQuery->where('fee_of', 2)->sum('amount');
            // dd($first_inst_fee_total);
            $second_inst_fee_total = $baseQuery->where('fee_of', 3)->sum('amount');
            $complete_fee_total = $baseQuery->where('fee_of', 4)->where('paid_mercy', 1)->sum('amount');
            $mercy_fee_total = $baseQuery->where('fee_of', 4)->where('paid_mercy', 2)->sum('amount');


            $first_inst_fee_exists = FeeDetail::where('srno', $request->std_id)->where('session_id', $session)->where('academic_trans', $academic_trans_value)->where('fee_of', 2)->where('paid_mercy', 1)->exists();
            // dd($first_inst_fee_exists);

            $second_inst_fee_exists = FeeDetail::where('srno', $request->std_id)->where('session_id', $session)->where('academic_trans', $academic_trans_value)->where('fee_of', 3)->where('paid_mercy', 1)->exists();

            $complete_fee_exists = FeeDetail::where('srno', $request->std_id)->where('session_id', $session)->where('academic_trans', $academic_trans_value)->where('fee_of', 4)->where('paid_mercy', 1)->exists();
            $mercy_fee_exists = FeeDetail::where('srno', $request->std_id)->where('session_id', $session)->where('academic_trans', $academic_trans_value)->where('fee_of', 4)->where('paid_mercy', 2)->exists();

            $rules = [
                'class' => 'required|exists:class_masters,id',
                'section' => 'required|exists:section_masters,id',
                'std_id' => 'required|exists:stu_main_srno,srno',
                'fee_date' => 'required|date_format:Y-m-d',
                'total_amount' => 'required|regex:/^\d*(\.\d{2})?$/',
                'ref_slip' => [
                    'required',
                    'string',
                    'unique:fee_details,ref_slip_no,',
                ],
                'admission_fee' => [
                    'required_if:admission_fee,true',
                    'nullable',
                    'regex:/^\d*(\.\d{2})?$/',
                    function ($attribute, $value, $fail) use ($fee_master_fees) {
                        if ($fee_master_fees && $value > $fee_master_fees->admission_fee) {
                            $fail('The admission fee must be equal to ' . $fee_master_fees->admission_fee . '.');
                        } elseif ($fee_master_fees && $value < $fee_master_fees->admission_fee) {
                            $fail('The admission fee must be equal to ' . $fee_master_fees->admission_fee . '.');
                        }
                    },
                    function ($attribute, $value, $fail) use ($student, $admission_fee_paid) {
                        if (is_null($student->admission_date) && $admission_fee_paid == true) {
                            $fail('The admission fee cannot be accepted because the admission fee is already paid.');
                        }
                    },
                ],
                'first_inst_fee' => [
                    'required_if:first_inst_fee,true',
                    'nullable',
                    'regex:/^\d*(\.\d{2})?$/',
                    function ($attribute, $value, $fail) use ($fee_master_fees, $first_inst_fee_exists) {
                        if ($fee_master_fees && $value > $fee_master_fees->inst_1 && $first_inst_fee_exists == false) {
                            $fail('The first installment fee must be equal to ' . $fee_master_fees->inst_1 . '.');
                        }
                    },
                    function ($attribute, $value, $fail) use ($fee_master_fees, $first_inst_fee_total, $mercy_fee_exists, $mercy_fee_total, $first_inst_fee_exists) {
                        $totalDue = $fee_master_fees->inst_1 - $first_inst_fee_total;
                        if ($first_inst_fee_exists == true && $mercy_fee_exists == true) {
                            # code...
                            $totalDue = $fee_master_fees->inst_1 - ($first_inst_fee_total + $mercy_fee_total);
                        }
                        // dd($totalDue);
                        if ($totalDue <= 0) {
                            $fail('Already Paid First Installment.');
                        } elseif ($value > $totalDue && $first_inst_fee_exists == true) {
                            $fail('Only ' . $totalDue . ' due of First Installment.');
                        }
                    },
                    function ($attribute, $value, $fail) use ($fee_master_fees, $first_inst_fee_total, $mercy_fee_total) {
                        $totalWithMercy = $first_inst_fee_total + $mercy_fee_total;
                        if ($totalWithMercy === $fee_master_fees->inst_1) {
                            # code...
                            $fail('Already Paid First Installment.');
                        }
                    },
                    function ($attribute, $value, $fail) use ($fee_master_fees, $first_inst_fee_exists, $second_inst_fee_total, $mercy_fee_exists, $mercy_fee_total, $second_inst_fee_exists) {
                        if (($second_inst_fee_exists == true || $mercy_fee_exists == true) && $first_inst_fee_exists == false) {
                            # code...
                            $total = $second_inst_fee_total + $mercy_fee_total;
                            if ($total == $fee_master_fees->inst_total) {
                                $fail('Already Paid complete fee');
                            }
                        }
                    },
                    function ($attribute, $value, $fail) use ($baseQuery) {
                        $completeFee = $baseQuery->where('fee_of', 4)->where('paid_mercy', 1)->first();
                        if ($completeFee) {
                            $fail("Fee previously enter as complete fee, now can't by insatllment. Please enter by complete fee");
                        }
                    },

                ],
                'second_inst_fee' => [
                    'required_if:second_inst__fee,true',
                    'nullable',
                    'regex:/^\d*(\.\d{2})?$/',
                    function ($attribute, $value, $fail) use ($fee_master_fees, $second_inst_fee_exists) {
                        if ($fee_master_fees && $value > $fee_master_fees->inst_2 && $second_inst_fee_exists == false) {
                            $fail('The second installment fee must be equal to ' . $fee_master_fees->inst_2 . '.');
                        }
                    },

                    function ($attribute, $value, $fail) use ($fee_master_fees, $second_inst_fee_total, $mercy_fee_exists, $mercy_fee_total, $second_inst_fee_exists) {
                        $totalDue = $fee_master_fees->inst_2 - $second_inst_fee_total;
                        if ($second_inst_fee_exists == true && $mercy_fee_exists == true) {
                            # code...
                            $totalDue = $fee_master_fees->inst_2 - ($second_inst_fee_total + $mercy_fee_total);
                        }
                        $totalWithMercy = $second_inst_fee_total + $mercy_fee_total;
                        if (($totalDue <= 0) || ($totalWithMercy === $fee_master_fees->inst_2)) {
                            $fail('Already Paid Second Installment.');
                        } elseif ($value > $totalDue && $second_inst_fee_exists == true) {
                            $fail('Only ' . $totalDue . ' due of Second Installment.');
                        }
                    },
                    function ($attribute, $value, $fail) use ($fee_master_fees, $first_inst_fee_exists, $first_inst_fee_total, $mercy_fee_exists, $mercy_fee_total, $second_inst_fee_exists) {
                        if (($first_inst_fee_exists == true || $mercy_fee_exists == true) && $second_inst_fee_exists == false) {
                            # code...
                            $total = $first_inst_fee_total + $mercy_fee_total;
                            if ($total == $fee_master_fees->inst_total) {
                                $fail('Already Paid complete fee');
                            }
                        }
                    },

                    function ($attribute, $value, $fail) use ($baseQuery) {
                        $completeFee = $baseQuery->where('fee_of', 4)->where('paid_mercy', 1)->first();
                        if ($completeFee) {
                            $fail("Fee previously enter as complete fee, now can't by insatllment. Please enter by complete fee");
                        }
                    },
                ],
                'complete_fee' => [
                    'required_if:complete_fee,true',
                    'nullable',
                    'regex:/^\d*(\.\d{2})?$/',
                    function ($attribute, $value, $fail) use ($fee_master_fees, $complete_fee_exists) {
                        if ($fee_master_fees && $value > $fee_master_fees->inst_total && $complete_fee_exists == false) {
                            $fail('The complete fee must be equal to ' . $fee_master_fees->inst_total . '.');
                        }
                    },

                    function ($attribute, $value, $fail) use ($fee_master_fees, $complete_fee_total, $mercy_fee_exists, $mercy_fee_total, $complete_fee_exists) {
                        $totalDue = $fee_master_fees->inst_total - $complete_fee_total;
                        if ($complete_fee_exists == true && $mercy_fee_exists == true) {
                            # code...
                            $totalDue = $fee_master_fees->inst_total - ($complete_fee_total + $mercy_fee_total);
                        }
                        $totalWithMercy = $complete_fee_total + $mercy_fee_total;
                        if (($totalDue <= 0) || ($totalWithMercy === $fee_master_fees->inst_total)) {
                            $fail('Already Paid Complete Fee.');
                        } elseif ($value > $totalDue && $complete_fee_exists == true) {
                            $fail('Only ' . $totalDue . ' due of Complete Fee.');
                        }
                    },



                    function ($attribute, $value, $fail) use ($request, $session, $academic_trans_value) {
                        $installFee = FeeDetail::where(function ($query) {
                            $query->where('fee_of', 2)->orWhere('fee_of', 3);
                        })
                            ->where('srno', $request->std_id)
                            ->where('session_id', $session)
                            ->where('academic_trans', $academic_trans_value)
                            ->first();

                        // $installFee = $baseQuery->where('fee_of', 2)->whereOr('fee_of', 3)->where('paid_mercy', 1)->first();
                        if ($installFee) {
                            $fail("If any installment is paid, then you can't enter complete fee. Please enter by installment.");
                        }
                    },
                ],
                // 'mercy_fee' => [
                //     'required_if:mercy_fee,true',
                //     'nullable',
                //     'regex:/^\d*(\.\d{2})?$/',
                //     function ($attribute, $value, $fail) use ($complete_fee_exists, $second_inst_fee_exists, $first_inst_fee_exists, $mercy_fee_total, $request, $fee_master_fees, $first_inst_fee_total, $second_inst_fee_total, $complete_fee_total, $mercy_fee_exists) {
                //         if (!empty($request->first_inst_fee) && !empty($request->mercy_fee)) {

                //             $first_inst_fee = $request->first_inst_fee ?? 0;
                //             $mercy_fee = $request->mercy_fee ?? 0;

                //             $first_inst = $first_inst_fee_total + $first_inst_fee + $mercy_fee;
                //             if ($first_inst_fee_exists == true && $mercy_fee_exists == true) {
                //                 # code...
                //                 $first_inst = $first_inst_fee_total + $mercy_fee_total + $first_inst_fee + $mercy_fee;
                //             }

                //             if ($first_inst > $fee_master_fees->inst_1) {
                //                 return $fail('If you want to pay mercy then deduct some amount from 1st Installment and enter only the rest balance');
                //             }
                //         } elseif (!empty($request->second_inst_fee) && !empty($request->mercy_fee)) {
                //             $second_inst_fee = $request->second_inst_fee ?? 0;
                //             $mercy_fee = $request->mercy_fee ?? 0;

                //             $second_inst = $second_inst_fee_total + $second_inst_fee + $mercy_fee;

                //             if ($second_inst_fee_exists == true && $mercy_fee_exists == true) {
                //                 $second_inst = $second_inst_fee_total + $mercy_fee_total + $second_inst_fee + $mercy_fee;
                //             }
                //             if ($second_inst > $fee_master_fees->inst_2) {
                //                 return $fail('If you want to pay mercy then deduct some amount from 2nd Installment and enter only the rest balance');
                //             }
                //         } elseif (!empty($request->complete_fee) && !empty($request->mercy_fee)) {
                //             $complete_fee = $request->complete_fee ?? 0;
                //             $mercy_fee = $request->mercy_fee ?? 0;

                //             $complete_inst = $complete_fee + $mercy_fee;
                //             // $complete_inst = $complete_fee_total + $complete_fee + $mercy_fee;

                //             // dd($complete_inst);
                //             if ($complete_fee_exists == true && $mercy_fee_exists == true) {
                //                 $complete_inst = $complete_fee_total + $mercy_fee_total + $complete_fee + $mercy_fee;
                //             }
                //             if ($complete_inst > $fee_master_fees->inst_total) {
                //                 return $fail('If you want to pay mercy then deduct some amount from Complete Fee and enter only the rest balance');
                //             }
                //         }
                //     },
                //     function ($attribute, $value, $fail) use ($first_inst_fee_exists, $second_inst_fee_exists, $complete_fee_exists, $mercy_fee_total, $request, $mercy_fee_exists, $fee_master_fees, $first_inst_fee_total, $second_inst_fee_total, $complete_fee_total) {
                //         if (empty($request->first_inst_fee) && empty($request->second_inst_fee) && empty($request->complete_fee) && !empty($request->mercy_fee)) {
                //             $totalPaid = 0;
                //             if ($first_inst_fee_exists == true || $second_inst_fee_exists == true || $complete_fee_exists == true || $mercy_fee_exists == true) {
                //                 # code...
                //                 $totalPaid = $first_inst_fee_total + $second_inst_fee_total + $complete_fee_total + $mercy_fee_total;
                //                 if ($totalPaid == $fee_master_fees->inst_total) {
                //                     # code...
                //                     $fail('Already Paid Complete Fee.');
                //                 } else {
                //                     # code...
                //                     $dueAmount = $fee_master_fees->inst_total - $totalPaid;
                //                     if ($request->mercy_fee > $dueAmount) {
                //                         $fail('Only ' . $dueAmount . ' due of Complete Fee.');
                //                     }
                //                 }
                //             }
                //         }
                //     },


                // ],
            ];
            $validator = Validator::make($request->all(), $rules);
            if ($validator->fails()) {
                return response()->json([
                    'status' => 'error',
                    'message' => $validator->errors()
                ], 400);
            }
            $recp_no = FeeDetail::where('session_id', $session)->where('academic_trans', $academic_trans_value)->max('recp_no');
            $user = Auth::user();

            FeeDetail::where('session_id', $session)->where('academic_trans', $academic_trans_value)->where('recp_no', $request->cSlip)->where('active', 1)->update(['active' => 0]);
            $sessionName = SessionMaster::where('id', $session)->where('active', 1)->value('session');
            $commonData = [
                'srno' => $request->std_id,
                'session_id' => $session,
                // 'academic_trans' => 1,
                'academic_trans' => $academic_trans_value,
                'pay_date' => $request->fee_date,
                'recp_no' => $request->cSlip,
                'ref_slip_no' => isset($request->ref_slip) ? $sessionName . $request->ref_slip : null,
                'active' => 1,
                'add_user_id' => $user->id,
                'edit_user_id' => $user->id,
            ];
            if (!empty($request->admission_fee)) {
                # code...
                $admissionData = array_merge($commonData, [
                    'fee_of' => 1,
                    'amount' => $request->admission_fee,
                    'paid_mercy' => 1,
                ]);
                FeeDetail::create($admissionData);
            }
            if (!empty($request->first_inst_fee)) {
                # code...
                $firstInstData = array_merge($commonData, [
                    'fee_of' => 2,
                    'amount' => $request->first_inst_fee,
                    'paid_mercy' => 1,
                ]);

                FeeDetail::create($firstInstData);
            }
            if (!empty($request->second_inst_fee)) {
                # code...
                $secondInstData = array_merge($commonData, [
                    'fee_of' => 3,
                    'amount' => $request->second_inst_fee,
                    'paid_mercy' => 1,
                ]);


                FeeDetail::create($secondInstData);
            }
            if (!empty($request->complete_fee)) {
                # code...
                $completeData = array_merge($commonData, [
                    'fee_of' => 4,
                    'amount' => $request->complete_fee,
                    'paid_mercy' => 1,
                ]);

                FeeDetail::create($completeData);
            }


            return response()->json([
                'status' => 'success',
                'message' => "Fee Updated Successfully. Slip No. " . ($request->cSlip),
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                'status' => 'error',
                'message' => "Failed to submit fee " . $e->getMessage() . 'At Line Number' . $e->getLine()
            ], 500);
        }
     }
}
