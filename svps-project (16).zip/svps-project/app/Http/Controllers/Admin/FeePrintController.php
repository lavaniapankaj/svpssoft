<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Fee\FeeDetail;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Rmunate\Utilities\SpellNumber;

class FeePrintController extends Controller
{
    //
    // public function index()
    // {
    //     return view('admin.reports.print_fee_slip');
    // }


    public function fillDetails(Request $request)
    {
        try {
            // Get query parameters
            // dd($request->all());
            $recp_no = $request->query('recpNo');
            $fee_id = $request->query('feeId');
            $sess = $request->query('session');

            // Handle fee_id == 1
            // if ($fee_id == 1) {
                $feeDetails = FeeDetail::select(
                    'stu_main_srno.gender',
                    'stu_main_srno.school',
                    'stu_detail.name',
                    'parents_detail.f_name',
                    'class_masters.class',
                    'section_masters.section',
                    'fee_details.amount',
                    'fee_details.fee_of',
                    'fee_details.pay_date',
                    'session_masters.session'
                )
                    ->join('stu_main_srno', 'stu_main_srno.srno', '=', 'fee_details.srno')
                    ->join('stu_detail', 'stu_detail.srno', '=', 'fee_details.srno')
                    ->join('parents_detail', 'parents_detail.srno', '=', 'fee_details.srno')
                    ->join('class_masters', 'class_masters.id', '=', 'stu_main_srno.class')
                    ->join('section_masters', 'section_masters.id', '=', 'stu_main_srno.section')
                    ->join('session_masters', 'session_masters.id', '=', 'fee_details.session_id')
                    ->where('fee_details.recp_no', $recp_no)
                    ->where('fee_details.academic_trans', $fee_id)
                    ->where('fee_details.session_id', $sess)
                    ->where('fee_details.paid_mercy', 1)
                    ->where('fee_details.active', 1)
                    ->where('stu_main_srno.ssid', 1)
                    ->where('stu_detail.active', 1)
                    ->where('parents_detail.active', 1)
                    ->get();
                    // dd($feeDetails);

                if ($feeDetails->count() > 0) {
                    $feeDetail = $feeDetails->first(); // Assuming only one record for the receipt number
                    $total = $feeDetails->sum('amount');

                    // dd((int) $total);
                    return view('admin.reports.print_fee_slip')
                        ->with('school', $feeDetail->school == 1 ? 'PLAY HOUSE' : 'Public School')
                        ->with('recp_no', $recp_no)
                        ->with('date', Carbon::parse($feeDetail->pay_date)->format('d-M-Y'))
                        ->with('name', $feeDetail->name)
                        ->with('father_name', $feeDetail->f_name)
                        ->with('gender', $feeDetail->gender)
                        ->with('class', $feeDetail->class)
                        ->with('section', $feeDetail->section)
                        ->with('total', (int) $total)
                        // ->with('wordstotal', SpellNumber::value((int) $total)->locale('en')->toLetters())
                        ->with('wordstotal', $this->convertToWords((int) $total))
                        ->with('fee_of', $feeDetail->fee_of == 1 ? 'Admission Fee ' : ($feeDetail->fee_of == 2 ? 'Ist Installment Fee ' : ($feeDetail->fee_of == 3 ? 'IInd Installment Fee ' : ($feeDetail->fee_of == 4 ? 'Complete Fee ' : ''))))
                        ->with('session', $feeDetail->session);
                } else {
                    return redirect()->back()->with('error', 'Details Not Found.');
                }
            // }
            // Handle fee_id == 2 (Transport Fee)
            // else if ($fee_id == 2) {
            //     $feeDetails = FeeDetail::select(
            //         'tbl_stu_main_srno.gender',
            //         'tbl_stu_main_srno.school',
            //         'tbl_stu_detail.name',
            //         'tbl_parents_detail.f_name',
            //         'tbl_class_master.class',
            //         'tbl_section_master.section',
            //         'tbl_fee_details.amount',
            //         'tbl_fee_details.fee_of',
            //         'tbl_fee_details.pay_date',
            //         'tbl_session_master.session'
            //     )
            //         ->join('tbl_stu_main_srno', 'tbl_stu_main_srno.srno', '=', 'tbl_fee_details.srno')
            //         ->join('tbl_stu_detail', 'tbl_stu_detail.srno', '=', 'tbl_fee_details.srno')
            //         ->join('tbl_parents_detail', 'tbl_parents_detail.srno', '=', 'tbl_fee_details.srno')
            //         ->join('tbl_class_master', 'tbl_class_master.id', '=', 'tbl_stu_main_srno.class')
            //         ->join('tbl_section_master', 'tbl_section_master.id', '=', 'tbl_stu_main_srno.section')
            //         ->join('tbl_session_master', 'tbl_session_master.id', '=', 'tbl_fee_details.session_id')
            //         ->where('tbl_fee_details.recp_no', $recp_no)
            //         ->where('tbl_fee_details.academic_trans', 2)
            //         ->where('tbl_fee_details.session_id', $sess)
            //         ->where('tbl_fee_details.paid_mercy', 1)
            //         ->where('tbl_fee_details.active', 1)
            //         ->where('tbl_stu_main_srno.active', 1)
            //         ->where('tbl_stu_detail.active', 1)
            //         ->where('tbl_parents_detail.active', 1)
            //         ->get();

            //     if ($feeDetails->count() > 0) {
            //         $feeDetail = $feeDetails->first();
            //         $total = $feeDetails->sum('amount');
            //         $words = $this->convertToWords($total);

            //         return view('fee_details_transport')
            //             ->with('recp_no', $recp_no)
            //             ->with('date', Carbon::parse($feeDetail->pay_date)->format('d-MMM-Y'))
            //             ->with('name', $feeDetail->name)
            //             ->with('father_name', $feeDetail->f_name)
            //             ->with('class', $feeDetail->class)
            //             ->with('section', $feeDetail->section)
            //             ->with('total', $total)
            //             ->with('words', $words)
            //             ->with('fee_of', $feeDetail->fee_of)
            //             ->with('session', $feeDetail->session);
            //     } else {
            //         return redirect()->back()->with('error', 'Details Not Found.');
            //     }
            // }
        } catch (\Exception $e) {
            return redirect()->back()->with('error', 'An error occurred: ' . $e->getMessage());
        }
    }

    // Helper function to convert number to words
    private function convertToWords($number)
    {

        $num  = ( string ) ( ( int ) $number );

        if( ( int ) ( $num ) && ctype_digit( $num ) )
        {
            $words  = array( );

            $num    = str_replace( array( ',' , ' ' ) , '' , trim( $num ) );

            $list1  = array('','one','two','three','four','five','six','seven',
                'eight','nine','ten','eleven','twelve','thirteen','fourteen',
                'fifteen','sixteen','seventeen','eighteen','nineteen');

            $list2  = array('','ten','twenty','thirty','forty','fifty','sixty',
                'seventy','eighty','ninety','hundred');

            $list3  = array('','thousand','million','billion','trillion',
                'quadrillion','quintillion','sextillion','septillion',
                'octillion','nonillion','decillion','undecillion',
                'duodecillion','tredecillion','quattuordecillion',
                'quindecillion','sexdecillion','septendecillion',
                'octodecillion','novemdecillion','vigintillion');

            $num_length = strlen( $num );
            $levels = ( int ) ( ( $num_length + 2 ) / 3 );
            $max_length = $levels * 3;
            $num    = substr( '00'.$num , -$max_length );
            $num_levels = str_split( $num , 3 );

            foreach( $num_levels as $num_part )
            {
                $levels--;
                $hundreds   = ( int ) ( $num_part / 100 );
                $hundreds   = ( $hundreds ? ' ' . $list1[$hundreds] . ' Hundred' . ( $hundreds == 1 ? '' : 's' ) . ' ' : '' );
                $tens       = ( int ) ( $num_part % 100 );
                $singles    = '';

                if( $tens < 20 ) { $tens = ( $tens ? ' ' . $list1[$tens] . ' ' : '' ); } else { $tens = ( int ) ( $tens / 10 ); $tens = ' ' . $list2[$tens] . ' '; $singles = ( int ) ( $num_part % 10 ); $singles = ' ' . $list1[$singles] . ' '; } $words[] = $hundreds . $tens . $singles . ( ( $levels && ( int ) ( $num_part ) ) ? ' ' . $list3[$levels] . ' ' : '' ); } $commas = count( $words ); if( $commas > 1 )
        {
            $commas = $commas - 1;
        }

            $words  = implode( ', ' , $words );

            $words  = trim( str_replace( ' ,' , ',' , ucwords( $words ) )  , ', ' );
            if( $commas )
            {
                $words  = str_replace( ',' , ' and' , $words );
            }
        }else if( ! ( ( int ) $num ) ){
            $words = 'Zero';
        }else{
            $words = '';
        }

        return $words;
    }
}
