<?php

namespace App\Http\Controllers\Fee;

use App\Http\Controllers\Controller;
use App\Models\Admin\SessionMaster;
use Illuminate\Foundation\Auth\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Password;
use Illuminate\Support\Facades\Session;

class FeeController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
        $current_session = SessionMaster::where('active', 1)->where('fee_current_session', 1)->first();
        Session::put('fee_current_session', $current_session);
        return view('fee.index');
    }
    /**
     * login(Fee Dashboard)
     */
    public function login(){
        return view('auth.login');
    }

    /**
     * change password
     */
    public function changePass(){
        return view('fee.change_pass');
    }
    public function changePassStore(Request $request){
        $request->validate([
            'user_name' => 'max:255|unique:users,name,' . $request->id,
            'user_pass' => ['required', Password::min(8)->mixedCase()->numbers()->symbols()],
        ],[
            'user_pass.required' => 'Password field is required.'
        ]);
        $user = User::where('id', $request->id)->first();
        if ($user) {
            $user->update([
                'name' => !empty($request->user_name) ? $request->user_name : $user->name,
                'password' => Hash::make($request->user_pass),
                'edit_delete_user_id' => $request->id,
            ]);
            return redirect()->route('fee.changePass')->with('success', 'Password updated successfully.');
        } else {
            return redirect()->back()->with('error', 'Something went wrong, please try again.');
        }
    }
}
