<?php

namespace App\Http\Controllers\Student;

use App\Http\Controllers\Controller;
use App\Models\Student\Attendance;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Symfony\Component\HttpFoundation\StreamedResponse;

class StdAttendanceController extends Controller
{
    //
    public function index()
    {
        return view('student.attendance.index');
    }

    public function store(Request $request)
    {
        // dd($request->all());
        try {
            //code...

            $data = $request->validate([
                'hidden_a_date' => 'required|date_format:Y-m-d',
                'students' => 'required|array',
                'students.*.srno' => 'required|exists:stu_main_srno,srno',
                'students.*.status' => 'in:1,0',
            ]);

            $user = Auth::user();
            $updatedCount = 0;

            foreach ($data['students'] as $std) {
                $student = Attendance::updateOrCreate(
                    [
                        'srno' => $std['srno'],
                        'class' => $request->hidden_class,
                        'section' => $request->hidden_section,
                        'a_date' => $request->hidden_a_date,
                        'session_id' => $request->current_session,
                    ],
                    [
                        'session_id' => $request->current_session,
                        'class' => $request->hidden_class,
                        'section' => $request->hidden_section,
                        'srno' => $std['srno'],
                        'a_date' => $request->hidden_a_date,
                        'status' => isset($std['status']) ? $std['status'] : 0,
                        'add_user_id' => $user->id,
                        'edit_user_id' => $user->id,
                    ]
                );

                if ($student) {
                    $updatedCount++;
                }
            }

            if ($updatedCount > 0) {
                return response()->json([
                    'status' => 'success',
                    'message' => "Attendance updated successfully for $updatedCount students."
                ], 200);
                // return redirect()->route('student.attendance.index')->with('success', 'Students attendance updated successfully.');
            } else {
                // return redirect()->back()->with('error', 'Something went wrong, please try again.');
                return response()->json([
                    'status' => 'error',
                    'message' => "Something went wrong, please try again."
                ], 200);
            }
        } catch (\Exception $e) {
            return response()->json([
                'status' => 'error',
                'message' => "Failed to update student attendance" . $e->getMessage()
            ], 500);
        }
    }

    public function report()
    {
        return view('student.attendance.report');
    }

    public function getReport(Request $request)
    {
        try {
            //code...
            $validator = Validator::make($request->all(), [
                // 'std_id' => 'required|exists:stu_main_srno,srno',
                'class' => 'required|exists:class_masters,id',
                'section' => 'required|exists:section_masters,id',
                'start_date' => 'required|date_format:Y-m-d',
                'end_date' => 'required|date_format:Y-m-d',
            ]);
            if ($validator->fails()) {
                return response()->json([
                    'status' => 'error',
                    'message' => $validator->errors()
                ], 400);
            }
            $std = explode(",", $request->std_id);
            // dd($std);
            $dates = [$request->start_date, $request->end_date];
            $baseQuery = Attendance::where('class', $request->class)->where('section', $request->section)->where('session_id', $request->current_session)->whereIn('srno', $std)->whereBetween('a_date', $dates)->orderBy('a_date', "asc");
            if ($baseQuery->count() === 0) {
                return response()->json([
                    'status' => 'success',
                    'message' => "No Record Found",
                ], 202);
            }

            $data = $baseQuery->get(['status', 'a_date']);
            $formattedData = $data->map(function ($item) {
                $item->a_date = Carbon::parse($item->a_date)->format('d M, Y');
                return $item;
            });
            $absent = $baseQuery->clone()->where('status', 0)->count();
            $present = $baseQuery->clone()->where('status', 1)->count();
            // dd($absent);
            return response()->json([
                'status' => 'success',
                'message' => "Student Attendance Report",
                'present' => $present,
                'absent' => $absent,
                'data' => $formattedData,
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                'status' => 'error',
                'message' => "Failed to get student attendance report " . $e->getMessage()
            ], 500);
        }
    }



    // public function downloadCsv()
    // {
    //     $data = [
    //         ['aaa', 'bbb', 'ccc', 'dddd'],
    //         ['123', '456', '789'],
    //         ['aaa', 'bbb'],
    //     ];

    //     $response = new StreamedResponse(function () use ($data) {
    //         $handle = fopen('php://output', 'w');
    //         foreach ($data as $row) {
    //             fputcsv($handle, $row);
    //         }
    //         fclose($handle);
    //     });

    //     $response->headers->set('Content-Type', 'text/csv');
    //     $response->headers->set('Content-Disposition', 'attachment; filename="sample.csv"');

    //     return $response;
    // }

    public function downloadCsv(Request $request)
    {
        try {
            // Validate the request (similar to your getReport method)
            $validator = Validator::make($request->all(), [
                'class' => 'required|exists:class_masters,id',
                'section' => 'required|exists:section_masters,id',
                'start_date' => 'required|date_format:Y-m-d',
                'end_date' => 'required|date_format:Y-m-d',
                'std_id' => 'required',
            ]);

            if ($validator->fails()) {
                return response()->json([
                    'status' => 'error',
                    'message' => $validator->errors()
                ], 400);
            }

            $std = explode(",", $request->std_id);
            $dates = [$request->start_date, $request->end_date];

            // Fetch the attendance data based on the provided criteria
            $baseQuery = Attendance::where('class', $request->class)
                ->where('section', $request->section)
                ->where('session_id', $request->current_session)
                ->whereIn('srno', $std)
                ->whereBetween('a_date', $dates);

            $data = $baseQuery->get(['status', 'a_date']);

            // Prepare the data for CSV
            $csvData = [];
            $csvData[] = ['Days', 'Present', 'Absent']; // Header row

            // Count present and absent
            $presentCount = 0;
            $absentCount = 0;
            $details = []; // For detailed attendance records

            foreach ($data as $item) {
                $formattedDate = Carbon::parse($item->a_date)->format('Y-m-d');
                $status = $item->status == 1 ? 'Present' : 'Absent';
                $details[] = [$formattedDate, $status];

                if ($item->status == 1) {
                    $presentCount++;
                } else {
                    $absentCount++;
                }
            }

            // Add summary row
            $csvData[] = ['', $presentCount, $absentCount]; // Summary row
            $csvData[] = ['Details']; // New section for details
            $csvData[] = ['Date', 'Status']; // Header for details

            foreach ($details as $detail) {
                $csvData[] = $detail;
            }

            // Create a CSV response
            $response = new StreamedResponse(function () use ($csvData) {
                $handle = fopen('php://output', 'w');
                foreach ($csvData as $row) {
                    fputcsv($handle, $row);
                }
                fclose($handle);
            });

            $response->headers->set('Content-Type', 'text/csv');
            $response->headers->set('Content-Disposition', 'attachment; filename="attendance_report.csv"');

            return $response;
        } catch (\Exception $e) {
            return response()->json([
                'status' => 'error',
                'message' => "Failed to download CSV: " . $e->getMessage()
            ], 500);
        }
    }

    // cumulative-attendance

    public function cumulativeAttendReport()
    {
        return view('student.cumulative_attendance.index');
    }

    // public function cumulativeReportData(Request $request)
    // {
    //     try {
    //         // Validate the request (similar to your getReport method)
    //         $validator = Validator::make($request->all(), [
    //             'class' => 'required|exists:class_masters,id',
    //             'section' => 'required|exists:section_masters,id',
    //             // 'std_id' => 'required',
    //         ]);

    //         if ($validator->fails()) {
    //             return response()->json([
    //                 'status' => 'error',
    //                 'message' => $validator->errors()
    //             ], 400);
    //         }
    //         $monthNames = ['Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec', 'Jan', 'Feb', 'Mar'];
    //         $results = [];

    //         $std = explode(",", $request->std_id);
    //         $cumulativePresentAttendance = 0;
    //         $stName = DB::table('stu_detail')->whereIn('srno', $std)->get('name');
    //         $stRollno = DB::table('stu_main_srno')->whereIn('srno', $std)->get('rollno');
    //         // dd($stName);
    //         foreach ($monthNames as $index => $monthName) {
    //             $monthNumber = ($index + 4) % 12;
    //             $currentYearAbsentAttendance = Attendance::where('class', $request->class)
    //                 ->where('section', $request->section)
    //                 ->where('session_id', $request->session)
    //                 ->whereIn('srno', $std)
    //                 ->where('status', 0)
    //                 ->whereMonth('a_date', $monthNumber)
    //                 ->count();

    //             $currentYearPresentAttendance = Attendance::where('class', $request->class)
    //                 ->where('section', $request->section)
    //                 ->where('session_id', $request->session)
    //                 ->whereIn('srno', $std)
    //                 ->where('status', 1)
    //                 ->whereMonth('a_date', $monthNumber)
    //                 ->count();

    //             $cumulativePresentAttendance += $currentYearPresentAttendance;

    //             $results[$monthName] = [

    //                 'P' => $currentYearPresentAttendance,
    //                 'A' => $currentYearAbsentAttendance,
    //                 'C' => $cumulativePresentAttendance,
    //             ];
    //         }
    //         $mergeArray = ['Name' => $stName,'Rollno' => $stRollno];
    //         return response()->json([
    //             'status' => 'success',
    //             'message' => 'Attendance',
    //             'data' => array_merge($mergeArray,$results)
    //         ], 200);
    //     } catch (\Exception $e) {
    //         return response()->json([
    //             'status' => 'error',
    //             'message' => "Failed to get cumulative attendance report: " . $e->getMessage()
    //         ], 500);
    //     }
    // }



    public function cumulativeReportData(Request $request)
    {
        try {
            // Validate the request
            $validator = Validator::make($request->all(), [
                'class' => 'required|exists:class_masters,id',
                'section' => 'required|exists:section_masters,id',
                'std_id' => 'required',
            ]);

            if ($validator->fails()) {
                return response()->json([
                    'status' => 'error',
                    'message' => $validator->errors()
                ], 400);
            }

            $monthNames = ['Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec', 'Jan', 'Feb', 'Mar'];
            $results = [];

            $std = explode(",", $request->std_id);
            $cumulativePresentAttendance = [];

            $students = DB::table('stu_detail')->whereIn('srno', $std)->get(['srno', 'name']);
            $rollNumbers = DB::table('stu_main_srno')->whereIn('srno', $std)->get(['srno', 'rollno']);

            foreach ($std as $id) {
                $cumulativePresentAttendance[$id] = 0;
            }

            foreach ($monthNames as $index => $monthName) {
                $monthNumber = ($index + 4) % 12;

                // Fetch attendance counts
                $currentYearPresentAttendance = Attendance::where('class', $request->class)
                    ->where('section', $request->section)
                    ->where('session_id', $request->session)
                    ->whereIn('srno', $std)
                    ->where('status', 1)
                    ->whereMonth('a_date', $monthNumber)
                    ->get();

                $currentYearAbsentAttendance = Attendance::where('class', $request->class)
                    ->where('section', $request->section)
                    ->where('session_id', $request->session)
                    ->whereIn('srno', $std)
                    ->where('status', 0)
                    ->whereMonth('a_date', $monthNumber)
                    ->get();

                // Calculate attendance for each student
                foreach ($std as $id) {
                    $presentCount = $currentYearPresentAttendance->where('srno', $id)->count();
                    $absentCount = $currentYearAbsentAttendance->where('srno', $id)->count();

                    $cumulativePresentAttendance[$id] += $presentCount;

                    $results[$id][$monthName] = [
                        'P' => $presentCount,
                        'A' => $absentCount,
                        'C' => $cumulativePresentAttendance[$id],
                    ];
                }
            }

            // Prepare the final data structure
            $mergeArray = [];
            foreach ($students as $student) {
                $mergeArray[$student->srno] = [
                    'Name' => $student->name,
                    'Rollno' => $rollNumbers->where('srno', $student->srno)->first()->rollno ?? null,
                    'Attendance' => $results[$student->srno] ?? []
                ];
            }

            return response()->json([
                'status' => 'success',
                'message' => 'Attendance',
                'data' => $mergeArray
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                'status' => 'error',
                'message' => "Failed to get cumulative attendance report: " . $e->getMessage()
            ], 500);
        }
    }
}
