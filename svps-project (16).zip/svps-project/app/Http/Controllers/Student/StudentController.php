<?php

namespace App\Http\Controllers\Student;

use App\Http\Controllers\Controller;
use App\Models\Admin\SessionMaster;
use App\Models\Student\StudentMaster;
use Illuminate\Foundation\Auth\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rules\Password;

class StudentController extends Controller
{
    // public function __construct()
    // {
    //     $this->middleware('auth');
    // }
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
        $current_session = SessionMaster::where('active', 1)->where('student_current_session', 1)->first();
        Session::put('std_current_session', $current_session);
        return view('student.index');
    }


    public function login(){
        return view('auth.login');
    }
    public function stReport(){
        return view('student.std_report.index');
    }

    public function updateMobile(){
        return view('student.update_mobile.index');
    }

    public function updateMobileStore(Request $request){
         $request->validate([
            'std_id' => 'required|exists:stu_main_srno,srno',
            'f_mobile' => 'nullable|string|regex:/^[0-9]{10}$/',
            'm_mobile' => 'nullable|string|regex:/^[0-9]{10}$/',
            'class' => 'required|exists:class_masters,id',
            'section' => 'required|exists:section_masters,id',
         ]);
         $std =  DB::table('parents_detail')->where('srno', $request->std_id);
        //  dd($std);
         if ($std) {
            # code...
            $std->update([
                'f_mobile' => $request->f_mobile,
                'm_mobile' => $request->m_mobile,
            ]);
            return redirect()->route('student.updateMobile.index')->with('success', 'Student Mobile Number Updated Successfully');
        } else {
            return redirect()->back()->with('error', 'Something went wrong, please try again.');
        }
    }

    public function changePass(){
        return view('student.change_pass');
    }
    public function changePassStore(Request $request){
        $request->validate([
            'user_name' => 'max:255|unique:users,name,' . $request->id,
            'user_pass' => ['required', Password::min(8)->mixedCase()->numbers()->symbols()],
        ],[
            'user_pass.required' => 'Password field is required.'
        ]);
        $user = User::where('id', $request->id)->first();
        if ($user) {
            $user->update([
                'name' => !empty($request->user_name) ? $request->user_name : $user->name,
                'password' => Hash::make($request->user_pass),
                'edit_delete_user_id' => $request->id,
            ]);
            return redirect()->route('student.changePass')->with('success', 'Password updated successfully.');
        } else {
            return redirect()->back()->with('error', 'Something went wrong, please try again.');
        }
    }

    /**
     * Student Report
     */

    //  public function studentReport(Request $request){
    //     $validator = Validator::make($request->all(), [
    //         'session_id' => 'nullable|exists:session_masters,id',
    //         'class_id' => 'nullable|exists:class_masters,id',
    //         'section_id' => 'nullable|exists:section_masters,id',
    //     ]);
    //     if ($validator->fails()) {
    //         return response()->json([
    //             'status' => 'error',
    //             'message' => $validator->errors()
    //         ], 400);
    //     }

    //     $student = StudentMaster::where
    //  }
}
