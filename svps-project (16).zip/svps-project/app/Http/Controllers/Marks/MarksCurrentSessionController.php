<?php

namespace App\Http\Controllers\Marks;

use App\Http\Controllers\Controller;
use App\Models\Admin\SessionMaster;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;

class MarksCurrentSessionController extends Controller
{
    //
    public function index()
    {
        //
        $data = SessionMaster::where('active', 1)->where('marks_current_session', 1)
            ->orderBy('created_at', 'DESC')
            ->paginate(10);

        return view('marks.current_session.index', compact('data'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('marks.current_session.create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $request->validate([
            'session_id' => 'required|exists:session_masters,id',
        ]);
        $user = Auth::user();
        SessionMaster::where('marks_current_session', 1)->where('active', 1)->update(['marks_current_session' => 0]);
        $sessionData = [
            'marks_current_session' => 1,
            'edit_user_id' => $user->id,
            'add_user_id' => $user->id,
        ];
        if ($request->id !== '') {
            $session = SessionMaster::find($request->id);
            if ($session !== null) {
                $sessionData['add_user_id'] = $session->add_user_id;
            }
        }
        $session = SessionMaster::updateOrCreate(['id' => $request->session_id],$sessionData);
        if ($session) {
            $current_session = SessionMaster::where('active', 1)->where('marks_current_session', 1)->first();
            Session::put('marks_current_session', $current_session);
            return redirect()->route('marks.current-session.index')->with('success', $request->session_id ? 'Current Session updated successfully.' : 'Current Session saved successfully.');
        } else {
            return redirect()->back()->with('error', 'Something went wrong, please try again.');
        }
    }


    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        if ($id) {
            # code...
            $data = SessionMaster::findOrFail($id);
            return view('marks.current_session.create', compact('data'));
        }else {
            return redirect()->back()->with('error', 'Something went wrong, please try again.');
        }
    }
}
