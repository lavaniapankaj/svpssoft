<?php

namespace App\Http\Controllers\Marks;

use App\Http\Controllers\Controller;
use App\Models\Admin\AttendanceSchedule;
use App\Models\Admin\ClassMaster;
use App\Models\Admin\ExamMaster;
use App\Models\Admin\MarksMaster;
use App\Models\Admin\SectionMaster;
use App\Models\Admin\SessionMaster;
use App\Models\Admin\SubjectMaster;
use App\Models\Marks\Marks;
use App\Models\Student\Attendance;
use App\Models\Student\StudentMaster;
use Carbon\Carbon;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;
use PhpParser\Node\Stmt\TryCatch;

class StdMarksController extends Controller
{
    //
    public function marksEntry()
    {
        return view('marks.marks_entry.index');
    }

    public function marksEntryStore(Request $request)
    {
        // dd($request->all());

        $data = $request->validate([
            'students' => 'required|array',
            'students.*.srno' => 'required|exists:stu_main_srno,srno',
            'students.*.status' => 'in:1,0',
            'students.*.marks' => [
                // 'sometimes',
                'nullable',
                'numeric',
                // Rule::unique('marks')
                //     ->where(function ($query) use ($request) {
                //         return $query->where('class_id', $request->hidden_class)
                //                      ->where('subject_id', $request->hidden_subject)
                //                      ->where('exam_id', $request->hidden_exam)
                //                      ->where('session_id', $request->current_session)
                //                      ->where('active', 1);
                //     })
                //     ->ignore($request->id),
                function ($attribute, $value, $fail) use ($request) {
                    //  marks not be greater than
                    $threshold = MarksMaster::where('session_id', $request->current_session)
                        ->where('class_id', $request->hidden_class)->where('subject_id', $request->hidden_subject)
                        ->where('exam_id', $request->hidden_exam)->where('active', 1)->value('max_marks');
                    if ($value > $threshold) {
                        $fail("The $attribute must not be greater than $threshold.");
                    }
                },
            ],
        ]);

        $user = Auth::user();
        $updatedCount = 0;
        foreach ($data['students'] as $std) {
            $st = Marks::where('srno', $std['srno'])->where('class_id', $request->hidden_class)->where('exam_id', $request->hidden_exam)->where('subject_id', $request->hidden_subject)->where('session_id', $request->current_session)->value('marks');
            $student = Marks::updateOrCreate(
                [
                    'srno' => $std['srno'],
                    'class_id' => $request->hidden_class,
                    'exam_id' => $request->hidden_exam,
                    'subject_id' => $request->hidden_subject,
                    'session_id' => $request->current_session,
                ],
                [
                    'session_id' => $request->current_session,
                    'class_id' => $request->hidden_class,
                    'exam_id' => $request->hidden_exam,
                    'subject_id' => $request->hidden_subject,
                    'srno' => $std['srno'],
                    'marks' => isset($std['marks']) ? $std['marks'] : $st,
                    'attendance' => isset($std['status']) ? $std['status'] : 0,
                    'add_user_id' => $user->id,
                    'edit_user_id' => $user->id,
                    'active' => 1,
                ]
            );

            if ($student) {
                $updatedCount++;
            }
        }

        if ($updatedCount > 0) {
            return redirect()->route('marks.marks-entry.index')->with('success', 'Students Marks Entered successfully.');
        } else {
            return redirect()->back()->with('error', 'Something went wrong, please try again.');
        }
    }

    public function marksReport()
    {
        return view('marks.marks_entry.report');
    }

    public function getMarksReport(Request $request)
    {
        try {
            // Validate the request
            $validator = Validator::make($request->all(), [
                'class' => 'required|exists:class_masters,id',
                'subject' => 'required|exists:subject_masters,id',
                'exam' => 'required|exists:exam_masters,id',
                // 'std_id' => 'required|exists:stu_main_srno,srno',
            ]);

            if ($validator->fails()) {
                return response()->json([
                    'status' => 'error',
                    'message' => $validator->errors()
                ], 400);
            }
            $sessionId = $request->session;
            $examId = $request->exam;
            $classId = $request->class;
            // $subjectIds = explode(",", $request->subject);
            $subjectIds = $request->subject;
            $studentIds = explode(",", $request->std_id);



            $marks = Marks::where('session_id', $sessionId)
                ->where('exam_id', $examId)
                ->where('class_id', $classId)
                ->whereIn('subject_id', $subjectIds)
                ->whereIn('srno', $studentIds)
                ->get();
            $marksGroup = $marks->groupBy(['subject_id', 'srno']);

            $subjects = SubjectMaster::whereIn('id', $subjectIds)->pluck('subject', 'id');

            $students = DB::table('stu_detail')
                ->whereIn('srno', $studentIds)
                ->pluck('name', 'srno');

            $rollNumbers = DB::table('stu_main_srno')
                ->whereIn('srno', $studentIds)
                ->pluck('rollno', 'srno');

            $report = [];

            foreach ($subjects as $subjectId => $subjectName) {
                $subjectReport = [
                    'subject' => $subjectName,
                    'students' => []
                ];

                foreach ($studentIds as $studentId) {
                    $studentMarks = $marksGroup[$subjectId][$studentId] ?? null;

                    $subjectReport['students'][] = [
                        'student_id' => $studentId,
                        'name' => $students[$studentId] ?? 'N/A',
                        'roll_number' => $rollNumbers[$studentId] ?? 'N/A',
                        'marks' => $studentMarks ? $studentMarks->first()->marks : 'N/A',
                    ];
                }

                $report[] = $subjectReport;
            }

            // dd($report);
            return response()->json([
                'status' => 200,
                'message' => "Subject Marks List",
                'data' => $report
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'status' => 'error',
                'message' => "Failed to get subjects " . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Marks-Report Excel File
     */

    // public function marksReportExcel(Request $request)
    // {
    //     try {
    //         $response = $this->getMarksReport($request);

    //         if ($response->getStatusCode() !== 200) {
    //             return response()->json([
    //                 'status' => 'error',
    //                 'message' => 'Failed to generate report: ' . $response->getContent()
    //             ], 500);
    //         }

    //         $decodedResponse = json_decode($response->getContent(), true);
    //         if (json_last_error() !== JSON_ERROR_NONE) {
    //             return response()->json(['status' => 'error', 'message' => 'Invalid JSON response: ' . json_last_error_msg()], 500);
    //         }

    //         $reportData = $decodedResponse['data'] ?? null;
    //         if (!$reportData) {
    //             return response()->json(['status' => 'error', 'message' => 'No data found'], 404);
    //         }

    //         $fileName = 'marks_report.csv';
    //         $output = fopen('php://output', 'w');
    //         if ($output === false) {
    //             throw new \Exception('Failed to open output stream.');
    //         }
    //         // Set the CSV column headers
    //         $subjects = [];
    //         $studentsData = [];

    //         // First pass: collect all subjects and initialize student data
    //         foreach ($reportData as $subjectData) {
    //             $subjects[] = $subjectData['subject'];

    //             foreach ($subjectData['students'] as $student) {
    //                 if (!isset($studentsData[$student['roll_number']])) {
    //                     $studentsData[$student['roll_number']] = [
    //                         'name' => $student['name'],
    //                         'marks' => []
    //                     ];
    //                 }
    //                 $studentsData[$student['roll_number']]['marks'][$subjectData['subject']] = $student['marks'];
    //             }
    //         }

    //         // Generate Table Header
    //         $headers = ['Student'];
    //         fputcsv($output, $headers);
    //         foreach ($subjects as $subject) {
    //             array_push($headers, $subject);
    //         }
    //         array_push($headers, 'Total');

    //         // Generate Table Body
    //         foreach ($studentsData as $rollNumber => $student) {
    //             $totalMarks = 0;
    //              fputcsv($output, [
    //                 $rollNumber . $student['name'],

    //             ]);

    //             foreach ($subjects as $subject) {
    //                 $mark = isset($student['marks'][$subject]) ? $student['marks'][$subject] : 'N/A';
    //                 $totalMarks += ($mark === 'N/A' || $mark === null) ? 0 : $mark;
    //                 fputcsv($output, [
    //                     $mark === null ? 'N/A' : $mark,
    //                 ]);
    //             }

    //             fputcsv($output, [
    //                 $totalMarks,
    //             ]);
    //         }



    //         fclose($output);

    //         return response('')->header('Content-Type', 'text/csv')
    //             ->header('Content-Disposition', 'attachment; filename="' . $fileName . '"');
    //     } catch (\Exception $e) {
    //         return response()->json([
    //             'status' => 'error',
    //             'message' => "Failed to export report: " . $e->getMessage()
    //         ], 500);
    //     }
    // }

    public function marksReportExcel(Request $request)
    {
        try {
            $response = $this->getMarksReport($request);

            if ($response->getStatusCode() !== 200) {
                return response()->json([
                    'status' => 'error',
                    'message' => 'Failed to generate report: ' . $response->getContent()
                ], 500);
            }

            $decodedResponse = json_decode($response->getContent(), true);
            if (json_last_error() !== JSON_ERROR_NONE) {
                return response()->json(['status' => 'error', 'message' => 'Invalid JSON response: ' . json_last_error_msg()], 500);
            }

            $reportData = $decodedResponse['data'] ?? null;
            if (!$reportData) {
                return response()->json(['status' => 'error', 'message' => 'No data found'], 404);
            }

            $fileName = 'marks_report.csv';
            $output = fopen('php://output', 'w');
            if ($output === false) {
                throw new \Exception('Failed to open output stream.');
            }

            // Collect all subjects and initialize student data
            $subjects = [];
            $studentsData = [];

            foreach ($reportData as $subjectData) {
                $subjects[] = $subjectData['subject'];

                foreach ($subjectData['students'] as $student) {
                    if (!isset($studentsData[$student['roll_number']])) {
                        $studentsData[$student['roll_number']] = [
                            'name' => $student['name'],
                            'marks' => []
                        ];
                    }
                    $studentsData[$student['roll_number']]['marks'][$subjectData['subject']] = $student['marks'];
                }
            }

            // Write headers
            $headers = ['Student'];
            foreach ($subjects as $subject) {
                $headers[] = $subject;
            }
            $headers[] = 'Total';
            fputcsv($output, $headers);

            // Write student data
            ksort($studentsData); // Sort by roll number
            foreach ($studentsData as $rollNumber => $student) {
                $row = [$student['name']];
                $totalMarks = 0;

                // Add marks for each subject
                foreach ($subjects as $subject) {
                    $mark = $student['marks'][$subject] ?? 'N/A';
                    $row[] = $mark;
                    if ($mark !== 'N/A' && $mark !== null) {
                        $totalMarks += (float)$mark;
                    }
                }

                // Add total
                $row[] = ($totalMarks > 0) ? $totalMarks : 0;

                // Write the complete row
                fputcsv($output, $row);
            }

            fclose($output);

            return response('')->header('Content-Type', 'text/csv')
                ->header('Content-Disposition', 'attachment; filename="' . $fileName . '"');
        } catch (\Exception $e) {
            return response()->json([
                'status' => 'error',
                'message' => "Failed to export report: " . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Marksheet
     */

    public function marksheet()
    {
        return view('marks.marksheet.index');
    }
    /**
     * Public School Exam-Wise
     */
    public function publicSchoolExamWise()
    {
        return view('marks.marksheet.exam_wise_public_report');
    }
    /**
     * Play School Exam-Wise
     */
    public function playSchoolExamWise()
    {
        return view('marks.marksheet.exam_wise_play_report');
    }

    public function signature()
    {
        return view('marks.marksheet.signature_upload');
    }

    public function uploadPrincipleSignature(Request $request)
    {
        $request->validate([
            'signature' => 'image|mimes:jpeg,jpg,png,svg|required|max:10000'
        ]);

        if ($request->hasFile('signature')) {
            $destinationPath = public_path('marks/images');

            // Delete any existing images in the folder
            $existingFiles = glob($destinationPath . '/*.{jpeg,jpg,png,svg}', GLOB_BRACE);
            foreach ($existingFiles as $file) {
                if (is_file($file)) {
                    unlink($file);
                }
            }

            $imageName = time() . '.' . $request->signature->getClientOriginalExtension();
            $request->signature->move($destinationPath, $imageName);

            return redirect()->route('marks.signature')->with('success', 'Principle Signature uploaded successfully.');
        }

        return redirect()->route('marks.signature')->with('error', 'No file uploaded.');
    }


    private function getGrade($total, $marks)
    {
        // dd($total);
        if ($total == 5) {
            if ($marks == 5) {
                return "A";
            } else if ($marks == 4) {
                return "B";
            } else if ($marks == 3) {
                return "C";
            } else {
                return "D";
            }
        } else if ($total == 10) {
            if ($marks >= 9 && $marks <= 10) {
                return "A";
            } else if ($marks >= 7 && $marks <= 8) {
                return "B";
            } else if ($marks >= 5 && $marks <= 6) {
                return "C";
            } else {
                return "D";
            }
        } else if ($total == 20) {
            if ($marks >= 17 && $marks <= 20) {
                return "A";
            } else if ($marks >= 13 && $marks <= 16) {
                return "B";
            } else if ($marks >= 9 && $marks <= 12) {
                return "C";
            } else {
                return "D";
            }
        } else if ($total == 25) {
            if ($marks >= 21 && $marks <= 25) {
                return "A";
            } else if ($marks >= 16 && $marks <= 20) {
                return "B";
            } else if ($marks >= 11 && $marks <= 15) {
                return "C";
            } else {
                return "D";
            }
        } else if ($total == 50) {
            if ($marks >= 41 && $marks <= 50) {
                return "A";
            } else if ($marks >= 31 && $marks <= 40) {
                return "B";
            } else if ($marks >= 21 && $marks <= 30) {
                return "C";
            } else {
                return "D";
            }
        } else if ($total == 70) {
            if ($marks >= 57 && $marks <= 70) {
                return "A";
            } else if ($marks >= 43 && $marks <= 56) {
                return "B";
            } else if ($marks >= 29 && $marks <= 42) {
                return "C";
            } else {
                return "D";
            }
        } else if ($total == 100) {
            if ($marks >= 81 && $marks <= 100) {
                return "A";
            } else if ($marks >= 61 && $marks <= 80) {
                return "B";
            } else if ($marks >= 41 && $marks <= 60) {
                return "C";
            } else {
                return "D";
            }
        } else if ($total == 150) {
            if ($marks >= 136 && $marks <= 150) {
                return "A+";
            } else if ($marks >= 121 && $marks <= 135) {
                return "A";
            } else if ($marks >= 91 && $marks <= 120) {
                return "B+";
            } else {
                return "B";
            }
        } else if ($total == 200) {
            if ($marks >= 161 && $marks <= 200) {
                return "A";
            } else if ($marks >= 121 && $marks <= 160) {
                return "B";
            } else if ($marks >= 81 && $marks <= 120) {
                return "C";
            } else {
                return "D";
            }
        }
    }
    // private function getGrade($percentage)
    // {
    //     if ($percentage >= 90 && $percentage <= 100) return 'A';
    //     if ($percentage >= 80 && $percentage <= 89) return 'B';
    //     if ($percentage >= 70 && $percentage <= 79) return 'C';
    //     if ($percentage >= 60 && $percentage <= 69) return 'D';
    //     return 'F';
    // }
    public function getMarkSheetReport(Request $request)
    {
        try {
            //code...
            $validator = Validator::make($request->all(), [
                'class' => 'required|exists:class_masters,id',
                'section' => 'required|exists:section_masters,id',
                'exam' => 'required|exists:exam_masters,id',
                // 'std_id' => 'required|exists:stu_main_srno,srno',
            ]);
            if ($validator->fails()) {
                return response()->json([
                    'status' => 'error',
                    'message' => $validator->errors()
                ], 400);
            }

            $sessionId = $request->session;
            $examId = $request->exam;
            $classId = $request->class;
            $sectionId = $request->section;
            $studentIds = explode(",", $request->std_id);
            $students = DB::table('stu_main_srno')
                ->whereIn('srno', $studentIds)
                ->where('class', $classId)
                ->where('section', $sectionId)
                ->where('active', 1)
                ->where('ssid', 1)
                ->where('session_id', $sessionId)->orderBy('rollno', 'asc')
                ->get(['rollno', 'srno', 'class', 'section', 'school']);
            if ($students->isNotEmpty()) {
                $exam = ExamMaster::where('id', $examId)->where('active', 1)->value('exam');
                $session = SessionMaster::where('id', $sessionId)->where('active', 1)->value('session');
                $report = [
                    'student' => []
                ];
                foreach ($students as $key => $st) {
                    # code...
                    $stDetail = DB::table('stu_detail')->where('srno', $st->srno)->where('active', 1)->get(['name', 'dob']);
                    if ($stDetail->isEmpty()) {
                        continue;
                    }
                    $fathername = DB::table('parents_detail')->where('srno', $st->srno)->where('active', 1)->value('f_name');
                    $class = ClassMaster::where('id', $st->class)->where('active', 1)->value('class');
                    $section = SectionMaster::where('id', $st->section)->where('active', 1)->value('section');
                    $subjects = SubjectMaster::where('class_id', $st->class)->where('active', 1)->get(['subject', 'id', 'subject_id', 'by_m_g', 'priority']);

                    $writtenSubjects = $subjects->whereNull('subject_id')->where('priority', 1)->values();
                    $oralSubjects = $subjects->whereNotNull('subject_id')->where('priority', 2)->values();
                    $practicalSubjects = $subjects->whereNotNull('subject_id')->where('priority', 3)->values();
                    $studentSubjects = [];

                    $marks = Marks::where('exam_id', $examId)
                        ->where('session_id', $sessionId)
                        ->where('class_id', $st->class)
                        ->where('srno', $st->srno)->where('attendance', 1)
                        ->where('active', 1)->get();

                    $marksMaster = MarksMaster::where('exam_id', $examId)
                        ->where('session_id', $sessionId)
                        ->where('class_id', $st->class)
                        ->where('active', 1)->get();


                    foreach ($writtenSubjects as $writtenSubject) {
                        $oral = $oralSubjects->where('subject_id', $writtenSubject->id)->where('by_m_g', $writtenSubject->by_m_g)->first();
                        $practical = $practicalSubjects->where('subject_id', $writtenSubject->id)->where('by_m_g', $writtenSubject->by_m_g)->first();

                        $writtenMarks = $marks->where('subject_id', $writtenSubject->id)->first();
                        $maxMarksWrittenGrade = $marksMaster->where('subject_id', $writtenSubject->id)->value('max_marks') ?? 0;

                        $oralMarks = null;
                        $maxMarksOralGrade = 0;
                        if ($oral) {
                            $oralMarks = $marks->where('subject_id', $oral->id)->first();
                            $maxMarksOralGrade = $marksMaster->where('subject_id', $oral->id)->value('max_marks') ?? 0;
                        }

                        $practicalMarks = null;
                        $maxMarksPracticalGrade = 0;
                        if ($practical) {
                            $practicalMarks = $marks->where('subject_id', $practical->id)->first();
                            $maxMarksPracticalGrade = $marksMaster->where('subject_id', $practical->id)->value('max_marks') ?? 0;
                        }

                        $writtenValue = $writtenMarks ? $writtenMarks->marks : null;
                        $oralValue = $oralMarks ? $oralMarks->marks : null;
                        $practicalValue = $practicalMarks ? $practicalMarks->marks : null;

                        $totalMarks = 0;
                        $totalMaxMarks = $maxMarksWrittenGrade + $maxMarksOralGrade + $maxMarksPracticalGrade;

                        if ($writtenValue !== null) $totalMarks += $writtenValue;
                        if ($oralValue !== null) $totalMarks += $oralValue;
                        if ($practicalValue !== null) $totalMarks += $practicalValue;

                        if ($writtenSubject->by_m_g == 1) {
                            $studentSubjects[] = [
                                'name' => $writtenSubject->subject,
                                'by_m_g' => $writtenSubject->by_m_g,
                                'written' => $st->school == 1 ? ($writtenValue !== null ? ($maxMarksWrittenGrade !== 0 ? $this->getGrade($maxMarksWrittenGrade, $writtenValue) : '') : '') : $writtenValue,
                                'oral' => $st->school == 1 ? ($oralValue !== null ? ($maxMarksOralGrade !== 0 ? $this->getGrade($maxMarksOralGrade, $oralValue) : '') : '') : $oralValue,
                                'practical' => $st->school == 1 ? ($practicalValue !== null ? ($maxMarksPracticalGrade !== 0 ? $this->getGrade($maxMarksPracticalGrade, $practicalValue) : '') : '') : $practicalValue,
                                'total' => $st->school == 1 ? (($writtenValue !== null || $oralValue !== null || $practicalValue !== null) ? ($totalMaxMarks !== 0 ? $this->getGrade($totalMaxMarks, $totalMarks) : '') : '') : $totalMarks,
                            ];
                        } else {
                            $studentSubjects[] = [
                                'name' => $writtenSubject->subject,
                                'by_m_g' => $writtenSubject->by_m_g,
                                // 'written' => $writtenValue !== null ? ($maxMarksWrittenGrade !== 0 ? $this->getGrade(($writtenValue / $maxMarksWrittenGrade) * 100) : '') : '',
                                'written' => $writtenValue !== null ? ($maxMarksWrittenGrade !== 0 ? $this->getGrade($maxMarksWrittenGrade, $writtenValue) : '') : '',
                                'oral' => $oralValue !== null ? ($maxMarksOralGrade !== 0 ? $this->getGrade($maxMarksOralGrade, $oralValue) : '') : '',
                                'practical' => $practicalValue !== null ? ($maxMarksPracticalGrade !== 0 ? $this->getGrade($maxMarksPracticalGrade, $practicalValue) : '') : '',
                                'total' => ($writtenValue !== null || $oralValue !== null || $practicalValue !== null) ? ($totalMaxMarks !== 0 ? $this->getGrade($totalMaxMarks, $totalMarks) : '') : '',
                            ];
                        }
                    }

                    $grandTotalMarks = array_sum(array_map(function ($item) {
                        if ($item['by_m_g'] == 1) {
                            # code...
                            return $item['total'];
                        } else {

                            return 0;
                        }
                    }, $studentSubjects));
                    // $destinationPath = public_path('marks/images');

                    // // get any existing images in the folder
                    // $existingFiles = glob($destinationPath . '/*.{jpeg,jpg,png,svg}', GLOB_BRACE);
                    // $signature = '';
                    // foreach ($existingFiles as $file) {
                    //     if (is_file($file)) {
                    //         $signature = $file;
                    //     }
                    // }

                    $directoryPath = public_path('marks/images'); // Path to the directory
                    $files = File::files($directoryPath); // Get all files in the directory

                    $image = null;
                    // Loop through the files and get their names
                    foreach ($files as $file) {
                        $image = $file->getFilename(); // Outputs the file name (e.g., some_image.jpg)
                    }


                    $report['student'][] = [
                        'session' => $session,
                        'logo' => config('myconfig.mylogo'),
                        'school' => $st->school == 1 ? 'St. Vivekanand Play House' : 'St. Vivekanand Public Secondary School',
                        'srno' => $st->srno,
                        'name' => $stDetail[0]->name ?? 'N/A',
                        'rollno' => $st->rollno,
                        'dob' => $stDetail[0]->dob ? date('d-M-Y', strtotime($stDetail[0]->dob)) : 'N/A',
                        'father_name' => $fathername,
                        'class_name' => $class,
                        'section_name' => $section,
                        'exam_name' => $exam,
                        'principle_sign' => $image,
                        'subjects' => $studentSubjects,
                        'grand_total_marks' => $grandTotalMarks,
                        // 'grand_total_grade' => $grandTotalGrade,
                    ];
                }
                return response()->json([
                    'status' => 200,
                    'message' => "Student With Marks List",
                    'data' => $report
                ]);
            } else {
                return response()->json([
                    'status' => 202,
                    'message' => "Student Not Found",
                    'data' => []
                ]);
            }
        } catch (\Exception $e) {
            return response()->json([
                'status' => 'error',
                'message' => "Failed to get report " . $e->getMessage() . " at line number " . $e->getLine()
            ], 500);
        }
    }


    /**
     * Rank Report
     */

    public function rankReport()
    {
        return view('marks.marks_entry.rank_class_wise');
    }

    /**
     * Class Wise Rank Report Get
     */

    public function classWiseRankReport(Request $request)
    {
        try {
            //code...
            $validator = Validator::make($request->all(), [
                'class' => 'required|exists:class_masters,id',
            ]);

            if ($validator->fails()) {
                return response()->json([
                    'status' => 'error',
                    'message' => $validator->errors()
                ], 400);
            }

            $sessionId = $request->session;
            $classId = $request->class;
            $students = StudentMaster::where('class', $classId)->where('session_id', $sessionId)
                ->where('active', 1)
                ->where('ssid', 1)
                ->get(['rollno', 'srno', 'class', 'section']);
            // return $students;
            if ($students->isNotEmpty()) {
                # code...
                $report = [];
                foreach ($students as $st) {

                    $stDetail = DB::table('stu_detail')->where('srno', $st->srno)->where('active', 1)->value('name');
                    $class = ClassMaster::where('id', $st->class)->where('active', 1)->value('class');
                    $section = SectionMaster::where('id', $st->section)->where('active', 1)->value('section');
                    $marks = Marks::where('srno', $st->srno)->where('session_id', $sessionId)
                        // ->where('by_m_g', 1)
                        ->where('active', 1)
                        ->get(['subject_id', 'marks']);
                    $totalMarks = $marks->sum('marks');
                    $totalMeeting = 0;

                    // Get total meetings
                    $totalMeetingsData = AttendanceSchedule::where('session_id', $sessionId)->sum('status');

                    if ($totalMeetingsData) {
                        $totalMeeting = $totalMeetingsData * 2;
                    }

                    $meetingsAttended = Attendance::where('session_id', $sessionId)->where('srno', $st->srno)->where('class', $st->class)->sum('status');
                    $meetingsAttended = $meetingsAttended ? ($meetingsAttended * 2) : 0;

                    $report[] = [
                        'class' => $class,
                        'section' => $section,
                        'srno' => $st->srno,
                        'rollno' => $st->rollno,
                        'name' => $stDetail,
                        'total_marks' => $totalMarks,
                        'total_meeting' => $totalMeeting,
                        'meeting_attended' => $meetingsAttended,
                        // 'rank' => $rank,
                    ];
                }
                usort($report, function ($a, $b) {
                    return $b['total_marks'] <=> $a['total_marks'];
                });
                // $rank = 1;
                // foreach ($report as $key => $item) {
                //     $report[$key]['rank'] = $rank;
                //     $rank++;
                // }

                $rank = 1;
                $previousMarks = null;
                $skipCount = 0;

                foreach ($report as $key => $item) {
                    if ($previousMarks === $item['total_marks']) {
                        // Same marks as previous student, assign same rank
                        $report[$key]['rank'] = $report[$key - 1]['rank'];
                        $skipCount++;
                    } else {
                        // Different marks, assign new rank considering skipped positions
                        $report[$key]['rank'] = $rank + $skipCount;
                        $previousMarks = $item['total_marks'];
                    }
                    $rank++;
                }
                return response()->json([
                    'status' => 200,
                    'message' => "Class-Wise Rank Report",
                    'data' => $report
                ]);
            } else {
                # code...
                return response()->json([
                    'status' => 200,
                    'message' => "Class-Wise Rank Report",
                    'data' => []
                ]);
            }
        } catch (\Exception $e) {
            return response()->json([
                'status' => 'error',
                'message' => "Failed to get Class-Wise Rank Report " . $e->getMessage() . " at line number " . $e->getLine()
            ], 500);
        }
    }

    /**
     * Class-Wise Rank Report Excel File
     */

    public function classWiseRankReportExcel(Request $request)
    {
        try {
            $response = $this->classWiseRankReport($request);

            if ($response->getStatusCode() !== 200) {
                return response()->json([
                    'status' => 'error',
                    'message' => 'Failed to generate report: ' . $response->getContent()
                ], 500);
            }

            $decodedResponse = json_decode($response->getContent(), true);
            if (json_last_error() !== JSON_ERROR_NONE) {
                return response()->json(['status' => 'error', 'message' => 'Invalid JSON response: ' . json_last_error_msg()], 500);
            }

            $reportData = $decodedResponse['data'] ?? null;
            // return $reportData;
            if (!$reportData) {
                return response()->json(['status' => 'error', 'message' => 'No data found'], 404);
            }

            $fileName = 'class_wise_rank_report.csv';
            $output = fopen('php://output', 'w');
            if ($output === false) {
                throw new \Exception('Failed to open output stream.');
            }
            // Set the CSV column headers
            $headers = ['Class', 'Section', 'SRNO', 'Name', 'Total Obt. Marks', 'Rank', 'Total Meetings', 'Meetings Attended'];
            fputcsv($output, $headers);

            foreach ($reportData as $row) {
                fputcsv($output, [
                    $row['class'],
                    $row['section'],
                    $row['srno'],
                    $row['name'],
                    $row['total_marks'],
                    $row['rank'],
                    $row['total_meeting'],
                    $row['meeting_attended'],

                ]);
            }
            fclose($output);

            return response('')->header('Content-Type', 'text/csv')
                ->header('Content-Disposition', 'attachment; filename="' . $fileName . '"');
        } catch (\Exception $e) {
            return response()->json([
                'status' => 'error',
                'message' => "Failed to export report: " . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Final Marksheet Only For Class PG And Nursary
     */

    public function finalMarksheetOnlyForClassPGAndNursary()
    {
        return view('marks.marksheet.marksheet_final_pg_nur');
    }

    /**
     * Final Marksheet Only For Class PG And Nuursary Report
     */
    public function finalMarksheetClassPGAndNursaryReport(Request $request)
    {
        try {
            // Validate input parameters
            $validated = $request->validate([
                'class' => 'required|integer',
                'section' => 'required|integer'
            ]);

            // Get current active session
            $session = DB::table('session_masters')
                ->where('marks_current_session', 1)
                ->where('active', 1)
                ->first();

            if (!$session) {
                return response()->json([
                    'error' => 'No active session found',
                    'message' => 'Set Current Session'
                ], 400);
            }
            $srno = explode(",", $request->std_id);
            // Get students for this session, class, and section
            $students = DB::table('stu_main_srno')
                ->where('session_id', $session->id)
                ->where('class', $validated['class'])
                ->where('section', $validated['section'])
                ->whereIn('srno', $srno)
                ->where('active', 1)
                ->whereIn('ssid', [1, 2, 4, 5])
                ->orderBy('rollno')
                ->get();
            // dd($students);

            if ($students->isEmpty()) {
                return response()->json([
                    'error' => 'No students found',
                    'message' => 'No students in this class and section'
                ], 404);
            }

            $studentReports = [];
            $directoryPath = public_path('marks/images'); // Path to the directory
            $files = File::files($directoryPath); // Get all files in the directory

            $image = null;
            // Loop through the files and get their names
            foreach ($files as $file) {
                $image = $file->getFilename(); // Outputs the file name (e.g., some_image.jpg)
            }

            foreach ($students as $student) {
                // Get student details
                $studentDetail = DB::table('stu_main_srno')
                    ->join('stu_detail', 'stu_main_srno.srno', '=', 'stu_detail.srno')
                    ->join('parents_detail', 'stu_main_srno.srno', '=', 'parents_detail.srno')
                    ->join('class_masters', 'stu_main_srno.class', '=', 'class_masters.id')
                    ->join('section_masters', 'stu_main_srno.section', '=', 'section_masters.id')
                    ->where('stu_main_srno.srno', $student->srno)
                    ->where('stu_main_srno.session_id', $session->id)
                    ->where('parents_detail.active', 1)
                    ->where('stu_detail.active', 1)
                    ->first();

                // Get subjects for this class
                $subjects = DB::table('subject_masters')
                    ->where('class_id', $validated['class'])
                    ->where('active', 1)
                    ->get();

                // Get exams
                $exams = DB::table('exam_masters')
                    ->where('active', 1)
                    ->get();

                $subjectMarks = [];
                $totalMax = 0;
                $totalObtained = 0;

                // Calculate marks for each subject and exam
                foreach ($subjects as $subject) {
                    $subjectResult = [
                        'subject_name' => $subject->subject,
                        'exams' => []
                    ];
                    // dd($subjectResult);

                    $subjectTotalMax = 0;
                    $subjectTotalObtained = 0;

                    foreach ($exams as $exam) {
                        // Check if marks exist for this exam and subject
                        $marksCheck = DB::table('marks')
                            ->where('class_id', $validated['class'])
                            ->where('exam_id', $exam->id)
                            ->where('active', 1)
                            ->exists();

                        if ($marksCheck) {
                            $marks = DB::table('marks_masters')
                                ->join('marks', function ($join) use ($exam, $subject, $student, $session, $validated) {
                                    $join->on('marks_masters.exam_id', '=', 'marks.exam_id')
                                        ->on('marks_masters.subject_id', '=', 'marks.subject_id')
                                        ->where('marks_masters.exam_id', $exam->id)
                                        ->where('marks_masters.subject_id', $subject->id)
                                        ->where('marks.session_id', $session->id)
                                        ->where('marks.class_id', $validated['class'])
                                        ->where('marks.srno', $student->srno);
                                })
                                ->first();

                            if ($marks) {
                                $subjectResult['exams'][] = [
                                    'exam_name' => $exam->exam,
                                    'obtained_marks' => $marks->marks ?? 0,
                                    'max_marks' => $marks->max_marks ?? 0,
                                    'status' => $marks->marks ? 'Present' : 'Absent'
                                ];

                                $subjectTotalMax += $marks->max_marks ?? 0;
                                $subjectTotalObtained += $marks->marks ?? 0;
                            } else {
                                $subjectResult['exams'][] = [
                                    'exam_name' => $exam->exam,
                                    'obtained_marks' => 0,
                                    'max_marks' => 0,
                                    'status' => 'Absent'
                                ];
                            }
                        }
                    }

                    $subjectResult['total_max'] = $this->getGrade($subjectTotalMax, $subjectTotalObtained) ?? 'Abst';
                    $subjectResult['total_obtained'] = $this->getGrade($subjectTotalMax, $subjectTotalObtained) ?? 'Abst';
                    // $subjectResult['total_max'] = $subjectTotalMax;
                    // $subjectResult['total_obtained'] = $subjectTotalObtained;

                    $totalMax += $subjectTotalMax;
                    $totalObtained += $subjectTotalObtained;

                    $subjectMarks[] = $subjectResult;
                }

                // Calculate attendance
                $totalAttendanceDays = DB::table('attendance_schedule')
                    ->where('session_id', $session->id)
                    ->sum('status');
                $studentAttendance = 0;
                if ($totalAttendanceDays > 0 || $totalObtained !== '') {
                    # code...

                    $studentAttendance = DB::table('attendance')
                        ->where('session_id', $session->id)
                        ->where('srno', $student->srno)
                        ->where('class', $validated['class'])
                        ->sum('status');
                }

                $studentReports[] = [
                    'student_details' => [
                        'name' => $studentDetail->name,
                        'sr_no' => $student->srno,
                        'father_name' => $studentDetail->f_name,
                        'class' => $studentDetail->class,
                        'section' => $studentDetail->section,
                        'roll_no' => $student->rollno,
                        'dob' => $studentDetail->dob ? Carbon::parse($studentDetail->dob)->format('d-M-Y') : 'N/A'
                    ],
                    'subject_marks' => $subjectMarks,
                    'total_marks' => [
                        'max_marks' => $totalMax,
                        'obtained_marks' => $totalObtained,
                    ],
                    'attendance' => [
                        'days_present' => $studentAttendance * 2,
                        'total_days' => $totalAttendanceDays * 2,

                    ],
                    'logo' => [
                        'school_logo' => config('myconfig.mylogo'),
                        'principal_sign' => asset('public/marks/images/' . $image)
                    ],
                    'result_data' => [
                        'result' => 'Pass', // You might want to implement a more complex result calculation
                        'result_date_message' => $request->dateMessage ?? '',
                        'session_start_message' => $request->sessionMessage ?? '',
                    ]
                ];
            }

            return response()->json([
                'session' => $session->session,
                'students' => $studentReports
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'error' => 'Access Denied',
                'message' => $e->getMessage()
            ], 500);
        }
    }

    // public function finalMarksheetClassPGAndNursaryReport(Request $request)
    // {
    //     try {
    //         // Get current session
    //         $session = DB::table('session_masters')
    //         ->where('marks_current_session', 1)
    //         ->where('active', 1)
    //         ->first();

    //         if (!$session) {
    //             return response()->json(['error' => 'Set Current Session...'], 400);
    //         }

    //         // Extract parameters from the request
    //         $class = $request->query('class');
    //         $section = $request->query('section');
    //         $student = $request->query('student');

    //         // Get subject details
    //         $subjects = DB::table('subject_masters')
    //             ->where('class_id', $class)
    //             ->where('active', 1)
    //             ->get();

    //         if ($subjects->isEmpty()) {
    //             return response()->json(['error' => 'Access Denied...'], 400);
    //         }

    //         // Get student details
    //         $srno = explode(",", $request->std_id);
    //         $studentDetails = DB::table('stu_main_srno')
    //             ->join('stu_detail', 'stu_main_srno.srno', '=', 'stu_detail.srno')
    //             ->join('parents_detail', 'stu_main_srno.srno', '=', 'parents_detail.srno')
    //             ->join('class_masters', 'class_masters.id', '=', 'stu_main_srno.class_id')
    //             ->join('section_masters', 'section_masters.id', '=', 'stu_main_srno.section')
    //             ->whereIn('stu_main_srno.srno', $srno)
    //             ->where('stu_main_srno.session_id', $session->id)
    //             ->whereIn('stu_main_srno.ssid', [1, 2, 4, 5])
    //             ->where('parents_detail.active', 1)
    //             ->where('stu_detail.active', 1)
    //             ->where('class_masters.id', $class)
    //             ->get();

    //         if (!$studentDetails) {
    //             return response()->json(['error' => 'Student not found...'], 400);
    //         }

    //         // Get exam details
    //         $exams = DB::table('exam_masters')
    //             ->where('active', 1)
    //             ->get();

    //         // Get attendance details
    //         $attendance = DB::table('attendance_schedule')
    //             ->where('session_id', $session->id)
    //             ->sum('status');

    //         // Get student's attendance
    //         $studentAttendance = DB::table('attendance')
    //             ->where('session_id', $session->id)
    //             ->where('srno', $student)
    //             ->where('class', $class)
    //             ->sum('status');

    //         $attendanceSummary = [
    //             'total_attendance' => $attendance * 2,
    //             'attended' => $studentAttendance * 2,
    //             'result' => 'Pass'
    //         ];

    //         // Build the HTML output with Bootstrap
    //         $html = view('report.student_details', compact('studentDetails', 'subjects', 'exams', 'attendanceSummary', 'session'))->render();

    //         return response()->json(['html' => $html]);

    //     } catch (\Exception $e) {
    //         return response()->json(['error' => 'Access Denied...'], 400);
    //     }
    // }
    /**
     * Final Marksheet Only For Class KG
     */

    public function finalMarksheetOnlyForClassKG()
    {
        return view('marks.marksheet.marksheet_final_kg');
    }

    /**
     * Final Marksheet Only For Class KG Report
     */
    // public function finalMarksheetClassKGReport(Request $request)
    // {
    //     try {
    //         // Validate input parameters
    //         $validator = Validator::make($request->all(), [
    //             'class' => 'required|integer',
    //             'section' => 'required|integer'
    //         ]);
    //         if ($validator->fails()) {
    //             return response()->json([
    //                 'status' => 'error',
    //                 'message' => $validator->errors()
    //             ], 400);
    //         }

    //         // Get the current session
    //         $session = DB::table('session_masters')
    //             ->where('marks_current_session', 1)
    //             ->where('active', 1)
    //             ->first(['id','session']);

    //         if ($session) {
    //             $class = $request->class;
    //             $section = $request->section;
    //             $students = explode(",", $request->student); // Handle multiple student IDs
    //             $sessionId = $session->id;

    //             // Get subjects for the class
    //             $subjects = DB::table('subject_masters')
    //                 ->where('class_id', $class)
    //                 ->where('active', 1)
    //                 ->get(["id","subject","class_id","subject_id","by_m_g","priority"]);

    //             // Get student details for each student
    //             $studentDetails = DB::table('stu_main_srno')
    //                 ->join('stu_detail', 'stu_main_srno.srno', '=', 'stu_detail.srno')
    //                 ->join('parents_detail', 'stu_main_srno.srno', '=', 'parents_detail.srno')
    //                 ->join('class_masters', 'class_masters.id', '=', 'stu_main_srno.class')
    //                 ->join('section_masters', 'section_masters.id', '=', 'stu_main_srno.section')
    //                 ->whereIn('stu_main_srno.srno', $students)
    //                 ->where('stu_main_srno.session_id', $sessionId)
    //                 ->whereIn('stu_main_srno.ssid', [1, 2, 4, 5])
    //                 ->where('parents_detail.active', 1)
    //                 ->where('stu_detail.active', 1)
    //                 ->where('class_masters.id', $class)
    //                 ->select('stu_main_srno.srno','stu_main_srno.rollno', 'stu_detail.dob', 'stu_detail.name', 'parents_detail.f_name', 'class_masters.class', 'section_masters.section')
    //                 ->get();

    //             if ($studentDetails->isNotEmpty()) {
    //                 // Start building HTML for multiple students
    //                 $html = [];
    //                 foreach ($studentDetails as $studentDetail) {
    //                     $exam = ExamMaster::where('active', 1)->get(['id', 'exam']);
    //                     $marks
    //                     // $marks = Marks::where('active', 1)->where('class_id', $class)->where('exam_id', $studentDetail->)->where('session_id', $studentDetail->session_id)->where('Attendance', 1)->value('id');

    //                     $html[] = [
    //                         'session' => $session,
    //                         'studentDetails' => $studentDetail,
    //                         // 'class_e' => $class,
    //                         // 'student' => $students,
    //                         'subjects' => $subjects
    //                     ];
    //                 }

    //                 // Return the generated HTML for all students
    //                 return response()->json([
    //                     'data' => $html
    //                 ]);
    //             } else {
    //                 return response()->json([
    //                     'error' => 'Student details not found.'
    //                 ], 404);
    //             }
    //         } else {
    //             return response()->json([
    //                 'error' => 'No active session found.'
    //             ], 404);
    //         }
    //     } catch (\Exception $e) {
    //         // Handle any errors
    //         return response()->json([
    //             'error' => 'Access Denied: ' . $e->getMessage()
    //         ], 500);
    //     }
    // }

    // public function finalMarksheetClassKGReport(Request $request)
    // {
    //      // Validate basic inputs
    //      $validated = $request->validate([
    //         'class' => 'required|integer',
    //         'section' => 'nullable|integer',
    //         'students' => 'required|string',
    //     ]);

    //     // Explode student IDs
    //     $students = explode(",", $request->students);

    //     $reportCards = [];

    //     foreach ($students as $student) {
    //         try {

    //             $reportCard = $this->generateSingleReportCard(
    //                 trim($student),
    //                 $validated['class'],
    //                 $validated['section'] ?? null
    //             );

    //             $reportCards[] = $reportCard;
    //         } catch (\Exception $e) {
    //             $reportCards[] = [
    //                 'student_id' => trim($student),
    //                 'error' => $e->getMessage()
    //             ];
    //         }
    //     }

    //     // Return JSON response
    //     return response()->json([
    //         'success' => true,
    //         'report_cards' => $reportCards,
    //         'class_id' => $validated['class']
    //     ]);
    // }
    // private function generateSingleReportCard($student, $classId, $sectionId = null)
    // {
    //     // Get current active session
    //     $session = SessionMaster::where('marks_current_session', 1)
    //     ->where('active', 1)
    //     ->first(['id','session']);

    //     if (!$session) {
    //         return response()->json([
    //             'error' => 'Session Error',
    //             'message' => 'No active session found'
    //         ], 404);
    //         // throw new \Exception('No active session found');
    //     }

    //     // Fetch student details with multiple table joins
    //     $detail = DB::table('stu_main_srno')
    //         ->join('stu_detail', 'stu_main_srno.srno', '=', 'stu_detail.srno')
    //         ->join('parents_detail', 'stu_main_srno.srno', '=', 'parents_detail.srno')
    //         ->join('class_masters', 'stu_main_srno.class', '=', 'class_masters.id')
    //         ->join('section_masters', 'stu_main_srno.section', '=', 'section_masters.id')
    //         ->where('stu_main_srno.srno', $student)
    //         ->where('stu_main_srno.class', $classId)
    //         ->where('stu_main_srno.section', $sectionId)
    //         ->where('stu_main_srno.session_id', $session->id)
    //         ->where(function($query) {
    //             $query->whereIn('stu_main_srno.ssid', [1, 2, 4, 5]);
    //         })
    //         ->where('parents_detail.active', 1)
    //         ->where('stu_detail.active', 1)
    //         ->first();

    //     // if (!$detail) {
    //     //     throw new \Exception("Student details not found for $student");
    //     // }
    //     if (!$detail) {
    //         return response()->json([
    //             'error' => 'No students found',
    //             'message' => 'No students in this class and section'
    //         ], 404);
    //     }

    //     // Fetch subjects for the class
    //     $subjects = DB::table('subject_masters')
    //         ->where('class_id', $classId)
    //         ->where('active', 1)
    //         ->get();

    //     // Fetch exams
    //     $exams = DB::table('exam_masters')
    //         ->where('active', 1)
    //         ->get();

    //     // Calculate marks and grades
    //     $marksData = $this->calculateMarksData($student, $classId, $session->id, $subjects, $exams);

    //     return [
    //         'student_id' => $student,
    //         'student_details' => [
    //             'name' => $detail->name,
    //             'father_name' => $detail->f_name,
    //             'class' => $detail->class,
    //             'section' => $detail->section,
    //             'roll_no' => $detail->rollno,
    //             'dob' => $detail->dob,
    //             'ssid'=>$detail->ssid,
    //         ],
    //         'session' => [
    //             'name' => $session->session,
    //             'id' => $session->id
    //         ],
    //         'marks_data' => $marksData,
    //         'summary' => $this->calculateReportSummary($marksData)
    //     ];
    // }

    public function finalMarksheetClassKGReport(Request $request)
    {
        // Validate basic inputs
        $validated = $request->validate([
            'class' => 'required|integer',
            'section' => 'nullable|integer',
            'students' => 'nullable|string', // Make students optional
        ]);

        // Fetch students based on class and section if no specific students are provided
        $studentsQuery = DB::table('stu_main_srno')
            ->where('class', $validated['class'])
            ->where('session_id', SessionMaster::where('marks_current_session', 1)->value('id'))
            ->where(function ($query) {
                $query->whereIn('ssid', [1, 2, 4, 5]);
            });

        // Add section filter if provided
        if (isset($validated['section'])) {
            $studentsQuery->where('section', $validated['section']);
        }

        // If specific students are provided, filter the query
        if (!empty($request->students)) {
            $studentIds = explode(",", $request->students);
            $studentsQuery->whereIn('srno', $studentIds);
        }

        // Get the list of student IDs
        $students = $studentsQuery->pluck('srno');

        $reportCards = [];

        foreach ($students as $student) {
            try {
                $reportCard = $this->generateSingleReportCard(
                    $student,
                    $validated['class'],
                    $validated['section'] ?? null
                );

                $reportCards[] = $reportCard;
            } catch (\Exception $e) {
                $reportCards[] = [
                    'student_id' => $student,
                    'error' => $e->getMessage()
                ];
            }
        }

        // Return JSON response
        return response()->json([
            'success' => true,
            'report_cards' => $reportCards,
            'class_id' => $validated['class'],
            'section_id' => $validated['section'] ?? null,
            'total_students' => count($reportCards)
        ]);
    }

    private function generateSingleReportCard($student, $classId, $sectionId = null)
    {
        // Get current active session
        $session = SessionMaster::where('marks_current_session', 1)
            ->where('active', 1)
            ->first(['id', 'session']);

        if (!$session) {
            return response()->json([
                'error' => 'Session Error',
                'message' => 'No active session found'
            ], 404);
        }

        // Build the base query for student details with multiple joins
        $query = DB::table('stu_main_srno')
            ->join('stu_detail', 'stu_main_srno.srno', '=', 'stu_detail.srno')
            ->join('parents_detail', 'stu_main_srno.srno', '=', 'parents_detail.srno')
            ->join('class_masters', 'stu_main_srno.class', '=', 'class_masters.id')
            ->join('section_masters', 'stu_main_srno.section', '=', 'section_masters.id')
            ->where('stu_main_srno.srno', $student)
            ->where('stu_main_srno.class', $classId)
            ->where('stu_main_srno.session_id', $session->id)
            ->where(function ($query) {
                $query->whereIn('stu_main_srno.ssid', [1, 2, 4, 5]);
            })
            ->where('parents_detail.active', 1)
            ->where('stu_detail.active', 1);

        // Add section filter if provided
        if ($sectionId !== null) {
            $query->where('stu_main_srno.section', $sectionId);
        }

        // Fetch student details
        $detail = $query->first();

        if (!$detail) {
            return response()->json([
                'error' => 'No students found',
                'message' => 'No students in this class and section'
            ], 404);
        }

        // Fetch subjects for the class
        $subjects = DB::table('subject_masters')
            ->where('class_id', $classId)
            ->where('active', 1)
            ->get();

        // Fetch exams
        $exams = DB::table('exam_masters')
            ->where('active', 1)
            ->get();

        // Calculate marks and grades
        $marksData = $this->calculateMarksData($student, $classId, $session->id, $subjects, $exams);

        return [
            'student_id' => $student,
            'student_details' => [
                'name' => $detail->name,
                'father_name' => $detail->f_name,
                'class' => $detail->class,
                'section' => $detail->section,
                'roll_no' => $detail->rollno,
                'dob' => $detail->dob,
                'ssid' => $detail->ssid,
            ],
            'session' => [
                'name' => $session->session,
                'id' => $session->id
            ],
            'marks_data' => $marksData,
            'summary' => $this->calculateReportSummary($marksData)
        ];
    }

    private function calculateMarksData($student, $classId, $sessionId, $subjects, $exams)
    {
        $marksData = [];

        foreach ($subjects as $subject) {
            $subjectMarks = [];
            $totalMaxMarks = 0;
            $totalObtainedMarks = 0;

            foreach ($exams as $exam) {
                // Fetch marks for the subject and exam
                $marks = DB::table('marks')
                    ->where('srno', $student)
                    ->where('class_id', $classId)
                    ->where('session_id', $sessionId)
                    ->where('exam_id', $exam->id)
                    ->where('subject_id', $subject->id)
                    ->first();

                // Fetch max marks
                $maxMarks = DB::table('marks_masters')
                    ->where('class_id', $classId)
                    ->where('session_id', $sessionId)
                    ->where('exam_id', $exam->id)
                    ->where('subject_id', $subject->id)
                    ->value('max_marks');

                $obtainedMarks = $marks ? $marks->marks : null;
                $grade = $this->calculateGrade($obtainedMarks, $maxMarks);

                $subjectMarks[] = [
                    'exam_id' => $exam->id,
                    'exam_name' => $exam->exam,
                    'max_marks' => $maxMarks,
                    'obtained_marks' => $obtainedMarks,
                    'grade' => $grade
                ];

                // Accumulate total marks
                if ($maxMarks !== null) {
                    $totalMaxMarks += $maxMarks;
                    $totalObtainedMarks += $obtainedMarks ?? 0;
                }
            }

            // Calculate subject-level summary
            $marksData[] = [
                'subject_id' => $subject->id,
                'subject_name' => $subject->subject,
                'by_m_g' => $subject->by_m_g,
                'exam_marks' => $subjectMarks,
                'total_max_marks' => $totalMaxMarks,
                'total_obtained_marks' => $totalObtainedMarks,
                'percentage' => $totalMaxMarks > 0
                    ? round(($totalObtainedMarks / $totalMaxMarks) * 100, 2)
                    : null,
                'overall_grade' => $this->calculateGrade($totalObtainedMarks, $totalMaxMarks)
            ];
        }

        return $marksData;
    }

    private function calculateReportSummary($marksData)
    {
        $totalMaxMarks = 0;
        $totalObtainedMarks = 0;
        $subjectGrades = [];

        foreach ($marksData as $subject) {
            $totalMaxMarks += $subject['total_max_marks'];
            $totalObtainedMarks += $subject['total_obtained_marks'];
            $subjectGrades[] = $subject['overall_grade'];
        }

        return [
            'total_max_marks' => $totalMaxMarks,
            'total_obtained_marks' => $totalObtainedMarks,
            'overall_percentage' => $totalMaxMarks > 0
                ? round(($totalObtainedMarks / $totalMaxMarks) * 100, 2)
                : null,
            'subject_grades' => $subjectGrades,
            'overall_result' => $this->determineOverallResult($subjectGrades)
        ];
    }

    private function calculateGrade($obtainedMarks, $maxMarks)
    {
        if ($maxMarks == 0 || $obtainedMarks === null) return 'N/A';

        $percentage = ($obtainedMarks / $maxMarks) * 100;

        return match (true) {
            $percentage >= 90 => 'A+',
            $percentage >= 80 => 'A',
            $percentage >= 70 => 'B+',
            $percentage >= 60 => 'B',
            $percentage >= 50 => 'C',
            $percentage >= 40 => 'D',
            default => 'F'
        };
    }

    private function determineOverallResult($grades)
    {
        // Simple result determination based on grades
        $failGrades = array_filter($grades, function ($grade) {
            return $grade == 'F' || $grade == 'D';
        });

        return count($failGrades) > 0 ? 'Fail' : 'Pass';
    }



    // public function finalMarksheetClassKGReport(Request $request)
    // {
    //     try {
    //         // Fetch session data where current session is 1 and flag is 0
    //         $session = DB::table('session_masters')
    //             ->where('marks_current_session', 1)
    //             ->where('active', 1)
    //             ->first(['id', 'session']);

    //         if ($session) {
    //             $class = $request->class;
    //             $section = $request->section;
    //             $students = explode(",", $request->student);


    //             // Fetch subjects
    //             $subjects = DB::table('subject_masters')
    //                 ->where('class_id', $class)
    //                 ->where('active', 1)
    //                 ->get();

    //             if ($subjects->isNotEmpty()) {
    //                 // Prepare an array to hold results for multiple students
    //                 $studentsResults = [];

    //                 foreach ($students as $student) {
    //                     // Fetch student details
    //                     $studentDetails = DB::table('stu_main_srno')
    //                         ->join('stu_detail', 'stu_main_srno.srno', '=', 'stu_detail.srno')
    //                         ->join('parents_detail', 'stu_main_srno.srno', '=', 'parents_detail.srno')
    //                         ->join('class_masters', 'class_masters.id', '=', 'stu_main_srno.class')
    //                         ->join('section_masters', 'section_masters.id', '=', 'stu_main_srno.section')
    //                         ->where('stu_main_srno.srno', $student)
    //                         ->where('stu_main_srno.session_id', $session->id)
    //                         ->whereIn('stu_main_srno.ssid', [1, 2, 4, 5])
    //                         ->where('parents_detail.active', 1)
    //                         ->where('stu_detail.active', 1)
    //                         ->where('class_masters.id', $class)
    //                         ->first();

    //                     if ($studentDetails) {
    //                         // Initialize student result
    //                         $result = [
    //                             'student' => [
    //                                 'name' => $studentDetails->name,
    //                                 'srno' => $student,
    //                                 'father_name' => $studentDetails->f_name,
    //                                 'class' => $studentDetails->class,
    //                                 'dob' => $studentDetails->dob ? Carbon::parse($studentDetails->dob)->format('d-MMM-Y') : 'N/A',
    //                                 'section' => $studentDetails->section,
    //                                 'rollno' => $studentDetails->rollno,
    //                                 'session' => $session->session,
    //                             ]
    //                         ];

    //                         // Fetch exams
    //                         $exams = DB::table('exam_masters')
    //                             ->where('active', 1)
    //                             ->get();

    //                         $examResults = [];
    //                         $totalMarks = 0;
    //                         $obtainedMarks = 0;

    //                         foreach ($subjects as $subject) {
    //                             $subjectResult = [
    //                                 'subject' => $subject->subject,
    //                                 'exam_results' => [],
    //                                 'grades' => [],
    //                             ];

    //                             foreach ($exams as $exam) {
    //                                 $marks = DB::table('marks')
    //                                     ->join('marks_masters', 'marks.exam_id', '=', 'marks_masters.exam_id')
    //                                     ->where('marks.class_id', $class)
    //                                     ->where('marks.exam_id', $exam->id)
    //                                     ->where('marks.subject_id', $subject->id)
    //                                     ->where('marks.srno', $student)
    //                                     ->where('marks.session_id', $session->id)
    //                                     ->select(DB::raw('SUM(marks.marks) as total_marks, SUM(marks_masters.max_marks) as max_marks'))
    //                                     ->first();

    //                                 if ($marks) {
    //                                     $subjectResult['exam_results'][] = [
    //                                         'exam' => $exam->exam,
    //                                         'max_marks' => $marks->max_marks,
    //                                         'marks_obtained' => $marks->total_marks,
    //                                     ];
    //                                     $subjectResult['grades'][] = $this->gradeDisplay($marks->total_marks, $marks->max_marks);

    //                                     // Update total marks and obtained marks
    //                                     $totalMarks += $marks->max_marks;
    //                                     $obtainedMarks += $marks->total_marks;
    //                                 } else {
    //                                     $subjectResult['exam_results'][] = [
    //                                         'exam' => $exam->exam,
    //                                         'max_marks' => 'Abst',
    //                                         'marks_obtained' => 'Abst',
    //                                     ];
    //                                     $subjectResult['grades'][] = 'Abst';
    //                                 }
    //                             }

    //                             $examResults[] = $subjectResult;
    //                         }

    //                         $percentage = ($totalMarks > 0) ? round(($obtainedMarks * 100) / $totalMarks, 2) : 0;

    //                         // Add the result to the student array
    //                         $result['marks'] = [
    //                             'exam_results' => $examResults,
    //                             'total_marks' => $totalMarks,
    //                             'obtained_marks' => $obtainedMarks,
    //                             'percentage' => $percentage,
    //                             'result' => $percentage >= 35 ? 'Pass' : 'Fail',
    //                         ];

    //                         // Append student result to the list
    //                         $studentsResults[] = $result;
    //                     } else {
    //                         // If student not found or inactive, add an error message for that student
    //                         $studentsResults[] = [
    //                             'student' => [
    //                                 'srno' => $student,
    //                                 'error' => 'Student not found or inactive'
    //                             ]
    //                         ];
    //                     }
    //                 }

    //                 // Return results for all students
    //                 return response()->json($studentsResults, 200);
    //             } else {
    //                 return response()->json(['error' => 'No active subjects found for the class'], 404);
    //             }
    //         } else {
    //             return response()->json(['error' => 'No active session found'], 404);
    //         }
    //     } catch (\Exception $e) {
    //         return response()->json(['error' => 'Access Denied or an error occurred: ' . $e->getMessage() . $e->getLine()], 500);
    //     }
    // }

    private function gradeDisplay($marksObtained, $maxMarks)
    {
        if ($marksObtained == 'Abst') {
            return 'Abst';
        }

        $percentage = ($maxMarks > 0) ? ($marksObtained * 100) / $maxMarks : 0;

        // Define grade based on percentage
        if ($percentage >= 90) {
            return 'A+';
        } elseif ($percentage >= 80) {
            return 'A';
        } elseif ($percentage >= 70) {
            return 'B+';
        } elseif ($percentage >= 60) {
            return 'B';
        } elseif ($percentage >= 50) {
            return 'C';
        } elseif ($percentage >= 40) {
            return 'D';
        } else {
            return 'F';
        }
    }

    /**
     * Final Marksheet Only For Class First And Second
     */

    public function finalMarksheetOnlyForClassFirstSecond()
    {
        return view('marks.marksheet.marksheet_final_first_second');
    }
}
