@extends('marks.index')

@section('sub-content')
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        {{ 'Print Report Exam Wise' }}
                        <a href="{{ route('marks.marksheet') }}" class="btn btn-warning btn-sm" style="float: right;">Back</a>
                    </div>
                    <div class="card-body">
                        <form id="class-section-form">
                            <div class="row">
                                <div class="form-group col-md-4">
                                    <input type="hidden" name="current_session" value='' id="current_session">
                                    <label for="class_id" class="mt-2">Class <span class="text-danger">*</span></label>
                                    <input type="hidden" id="initialClassId"
                                        value="{{ old('initialClassId', request()->get('class_id') !== null ? request()->get('class_id') : '') }}">
                                    <select name="class" id="class_id"
                                        class="form-control @error('class') is-invalid @enderror" required>
                                        <option value="">Select Class</option>
                                    </select>
                                    @error('class')
                                        <span class="invalid-feedback form-invalid fw-bold"
                                            role="alert">{{ $message }}</span>
                                    @enderror
                                    <img src="{{ config('myconfig.myloader') }}" alt="Loading..." class="loader"
                                        id="loader" style="display:none; width:10%;">
                                </div>
                                <div class="form-group col-md-4">
                                    <label for="section_id" class="mt-2">Section <span
                                            class="text-danger">*</span></label>
                                    <input type="hidden" id="initialSectionId"
                                        value="{{ old('initialSectionId', request()->get('section_id') !== null ? request()->get('section_id') : '') }}">
                                    <select name="section" id="section_id"
                                        class="form-control @error('section') is-invalid @enderror" required>
                                        <option value="">Select Section</option>

                                    </select>
                                    @error('section')
                                        <span class="invalid-feedback form-invalid fw-bold"
                                            role="alert">{{ $message }}</span>
                                    @enderror
                                </div>
                                <div class="form-group col-md-4">
                                    <label for="std_id" class="mt-2">Student <span class="text-danger">*</span></label>
                                    <select name="std_id" id="std_id"
                                        class="form-control @error('std_id') is-invalid @enderror" required>
                                        <option value="">All Students</option>
                                    </select>
                                    @error('std_id')
                                        <span class="invalid-feedback form-invalid fw-bold"
                                            role="alert">{{ $message }}</span>
                                    @enderror
                                </div>
                            </div>
                            <div class="row">
                                <div class="form-group col-md-6">
                                    <label for="result-date-message" class="mt-2">Result Date Message <span class="text-danger">*</span></label>
                                    <input type="text" name="result_date_message" value="" id="result-date-message" class="form-control">
                                    <span class="invalid-feedback form-invalid fw-bold result-date-message-error" role="alert"></span>
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="session-start-message" class="mt-2">Session Start Message<span class="text-danger">*</span></label>
                                    <input type="text" name="session_start_message" value="" id="session-start-message" class="form-control">
                                    <span class="invalid-feedback form-invalid fw-bold session-start-message-error" role="alert"></span>
                                </div>
                            </div>
                            <div class="mt-3">
                                <button type="button" id="show-details" class="btn btn-primary">
                                    Show Details</button>
                            </div>

                        </form>
                        <div class="row">
                            <div class="marksheet-div">
                                <div class="marksheet">
                                    <div class="container mt-4">
                                        <!-- Header Section -->
                                        <div class="row mb-4 text-center">
                                            <div class="col-2">
                                                <img src="/api/placeholder/80/80" alt="School Logo" class="img-fluid rounded-circle">
                                            </div>
                                            <div class="col-10">
                                                <h2 class="font-italic">St. Vivekanand Public Secondary School</h2>
                                                <p class="text-muted">(English Medium)</p>
                                                <p class="small">Vivekanand Chowk, Chirawa, 01596 - 220877</p>
                                                <p class="small">Session : 2024-25</p>
                                            </div>
                                        </div>

                                        <!-- Student Details -->
                                        <div class="row mb-4">
                                            <div class="col-md-6">
                                                <div class="row mb-2">
                                                    <div class="col-5">Name of Student:</div>
                                                    <div class="col-7">Aadhaya Jangir</div>
                                                </div>
                                                <div class="row mb-2">
                                                    <div class="col-5">Father's Name:</div>
                                                    <div class="col-7">NITESH JANGIR</div>
                                                </div>
                                                <div class="row mb-2">
                                                    <div class="col-5">Class:</div>
                                                    <div class="col-7">1st Class Daisy</div>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="row mb-2">
                                                    <div class="col-5">S.R.No.:</div>
                                                    <div class="col-7">2732</div>
                                                </div>
                                                <div class="row mb-2">
                                                    <div class="col-5">Roll No.:</div>
                                                    <div class="col-7">1</div>
                                                </div>
                                                <div class="row mb-2">
                                                    <div class="col-5">Date of Birth:</div>
                                                    <div class="col-7">08-Aug-2018</div>
                                                </div>
                                            </div>
                                        </div>

                                        <!-- Academic Performance -->
                                        <div class="row mb-4">
                                            <div class="col-12">
                                                <table class="table table-bordered">
                                                    <thead>
                                                        <tr>
                                                            <th>Subject</th>
                                                            <th class="text-center">M.M.</th>
                                                            <th class="text-center">Grand Total</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <tr>
                                                            <td>Hindi</td>
                                                            <td class="text-center">-</td>
                                                            <td class="text-center">0</td>
                                                        </tr>
                                                        <tr>
                                                            <td>English</td>
                                                            <td class="text-center">-</td>
                                                            <td class="text-center">0</td>
                                                        </tr>
                                                        <tr>
                                                            <td>Mathematics</td>
                                                            <td class="text-center">-</td>
                                                            <td class="text-center">0</td>
                                                        </tr>
                                                        <tr>
                                                            <td>Environmental Studies</td>
                                                            <td class="text-center">-</td>
                                                            <td class="text-center">0</td>
                                                        </tr>
                                                        <tr>
                                                            <td colspan="2" class="text-end fw-bold">Total</td>
                                                            <td class="text-center">0</td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>

                                        <!-- Grades Section -->
                                        <div class="row mb-4">
                                            <div class="col-md-5">
                                                <table class="table table-bordered">
                                                    <tr>
                                                        <td>Work Experience</td>
                                                        <td class="text-center">D</td>
                                                    </tr>
                                                </table>
                                            </div>
                                            <div class="col-md-5">
                                                <table class="table table-bordered">
                                                    <tr>
                                                        <td>Health Education</td>
                                                        <td class="text-center">D</td>
                                                    </tr>
                                                </table>
                                            </div>
                                            <div class="col-md-2">
                                                <table class="table table-bordered">
                                                    <tr>
                                                        <td><p>Percentage: NaN</p> <p>Result: Pass</p></td>
                                                    </tr>
                                                </table>
                                                {{-- <p>Percentage: NaN</p>
                                                <p>Result: Pass</p> --}}
                                            </div>
                                        </div>

                                        <!-- Attendance Record -->
                                        <div class="row mb-4">
                                            <div class="col-12">
                                                <table class="table table-bordered text-center">
                                                    <thead>
                                                        <tr>
                                                            <th>Months</th>
                                                            <th>April</th>
                                                            <th>May</th>
                                                            <th>June</th>
                                                            <th>July</th>
                                                            <th>August</th>
                                                            <th>September</th>
                                                            <th>October</th>
                                                            <th>November</th>
                                                            <th>December</th>
                                                            <th>January</th>
                                                            <th>February</th>
                                                            <th>March</th>
                                                            <th>Total</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <tr>
                                                            <td>Total Meetings</td>
                                                            <td>270</td>
                                                            <td>274</td>
                                                            <td>240</td>
                                                            <td>298</td>
                                                            <td>290</td>
                                                            <td>282</td>
                                                            <td>288</td>
                                                            <td>256</td>
                                                            <td>248</td>
                                                            <td>248</td>
                                                            <td>226</td>
                                                            <td>246</td>
                                                            <td>3166</td>
                                                        </tr>
                                                        <tr>
                                                            <td>Attended</td>
                                                            <td>0</td>
                                                            <td>0</td>
                                                            <td>0</td>
                                                            <td>0</td>
                                                            <td>0</td>
                                                            <td>0</td>
                                                            <td>0</td>
                                                            <td>0</td>
                                                            <td>0</td>
                                                            <td>0</td>
                                                            <td>0</td>
                                                            <td>0</td>
                                                            <td>0</td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>

                                        <!-- Signatures -->
                                        <div class="row mt-5">
                                            <div class="col-4 text-center">
                                                <p>Sign of Class Teacher</p>
                                            </div>
                                            <div class="col-4 text-center">
                                                <p>Sign of Checker</p>
                                            </div>
                                            <div class="col-4 text-center">
                                                <p>Sign of Principal</p>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                                <div class="mt-3">
                                    <button type="button" id="print-marksheet" class="btn btn-primary">Print
                                        Marksheet</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
@section('marks-scripts')
    <script>
        $(document).ready(function() {
            let initialClassId = $('#initialClassId').val();
            let initialSectionId = $('#initialSectionId').val();
            getClassSection(initialClassId, initialSectionId);
            getStd();
            // marksheetPrint();
            // $('#class_id, #section_id, #exam_id, #std_id').change(function() {
            //     let marksheetDiv = $('.marksheet-div');
            //     marksheetDiv.hide();
            // });

        });
    </script>
@endsection
