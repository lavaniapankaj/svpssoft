@extends('fee.index')
@section('sub-content')
    <div class="container">
        @if (Session::has('success'))
            @section('scripts')
                <script>
                    swal("Good job!", "{{ Session::get('success') }}", "success").then(() => {
                        location.reload();
                    });
                </script>
            @endsection
        @endif

        @if (Session::has('error'))
            @section('scripts')
                <script>
                    swal("Oops...", "{{ Session::get('error') }}", "error");
                </script>
            @endsection
        @endif
        <div class="row justify-content-center">
            <div class="col-md-14">
                <div class="card">
                    <div class="card-header">
                        {{ 'Fee Entry' }}

                    </div>
                    <div class="card-body">
                        <a href="{{ route('fee.fee-entry.academic') }}" class="btn btn-sm btn-primary">Academic Fee Entry</a>
                        <a href="{{ route('fee.fee-entry.transport') }}" class="btn btn-sm btn-primary">Transport Fee Entry</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

