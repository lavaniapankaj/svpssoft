<div class="container">
    <div class="flex">
        <div class="align-center">
            <a href="{{ route('admin.login') }}" class="ml-5 fs-1"
                style="font-size: -webkit-xxx-large;
            margin: 150px;"><img src="{{ config('myconfig.admin') }}"
                    alt="Admin"></a>
            <a href="{{ route('fee.login') }}" class="ml-5fs-1"
                style="font-size: -webkit-xxx-large;
            margin: 150px;"><img src="{{ config('myconfig.fee') }}"
                    alt="Fee"></a>
            <a href="{{ route('student.login') }}" class="ml-5 fs-1"
                style="font-size: -webkit-xxx-large;
            margin: 150px;"><img
                    src="{{ config('myconfig.student') }}" alt="Std"></a>
            <a href="{{ route('marks.login') }}" class="ml-5 fs-1"
                style="font-size: -webkit-xxx-large;
            margin: 150px;"><img
                    src="{{ config('myconfig.marks') }}" alt="Marks"></a>
            <a href="{{ route('inventory.login') }}" class="ml-5 fs-1"
                style="font-size: -webkit-xxx-large;
            margin: 150px;"><img
                    src="{{ config('myconfig.inventory') }}" alt="Inventory"></a>
        </div>
    </div>
</div>


<script>
    window.onload = function() {
        // Try to clear the browser cache using JavaScript (browser specific)
        if ('caches' in window) {
            caches.keys().then(function(cacheNames) {
                cacheNames.forEach(function(cacheName) {
                    caches.delete(cacheName);
                });
            });
        }
    };
</script>
