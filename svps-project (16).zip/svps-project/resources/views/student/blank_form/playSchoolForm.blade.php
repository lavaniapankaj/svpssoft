<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <title>St. Vivekanand Play House</title>
</head>
<body>
    <form name="form1" method="post" action="./blank_form_play_school.aspx" id="form1">
        <div>
        <input type="hidden" name="__VIEWSTATE" id="__VIEWSTATE" value="/wEPDwUJNzgzNDMwNTMzZGSvTapqYuGkit37t3l0YG7OBgRhcQ==" />
        </div>

        <div>

            <input type="hidden" name="__VIEWSTATEGENERATOR" id="__VIEWSTATEGENERATOR" value="C5B7BE7C" />
        </div>
            <table width="900px" border="0" cellspacing="0" cellpadding="0">
                <tr>
                    <td>
                        <table width="900px" border="0" cellspacing="0" cellpadding="0">
                            <tr>
                                <td rowspan="9" align="left" width="100px">
                                    <img src="{{ config('myconfig.blank') }}" alt="Loading...">
                                </td>
                                <td align="center" width="700px" style="letter-spacing: 3px;">
                                    <font face="Verdana" size="6"><strong>St. VIVEKANAND PLAY HOUSE</strong></font>
                                </td>
                                <td>
                                </td>
                            </tr>
                            <tr>
                                <td height="5px">
                                </td>
                            </tr>
                            <tr>
                                <td align="center">
                                    <font face="Verdana" size="3"><strong>Near Baager,CHIRAWA-333026</strong></font>
                                </td>
                                <td align="right" rowspan="7" width="100px">
                                    <img src="{{ config('myconfig.blank') }}" alt="Loading...">
                                </td>
                            </tr>
                            <tr>
                                <td height="5px">
                                </td>
                            </tr>
                            <tr>
                                <td align="center">
                                    <font face="Verdana" size="3"><strong>Ph. 01596-220877 Mob. 9829059133</strong></font>
                                </td>
                            </tr>
                            <tr>
                                <td height="5px">
                                </td>
                            </tr>
                            <tr>
                                <td align="center">
                                    <font face="Verdana" size="3"><strong><u>APPLICATION FOR ADMISSION</u></strong></font>
                                </td>
                            </tr>
                            <tr>
                                <td align="center">
                                    <font face="Verdana" size="2">Note:Read the form carefully and fill it. The form should<br />
                                        be filled in by the paents/gaurdian of the child.Strike off<br>
                                        the entries which are not applicable.</font>
                                </td>
                            </tr>
                            <tr>
                                <td height="5px">
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
                <tr>
                    <td>
                        <font face="Verdana" size="2"><strong>1. Name of the Student&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</strong>............................................................</font>
                    </td>
                </tr>
                <tr>
                    <td height="5px">
                    </td>
                </tr>
                <tr>
                    <td>
                        <font face="Verdana" size="2"><strong>2. Date of Birth&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</strong>............................................................</font>
                    </td>
                </tr>
                <tr>
                    <td height="5px">
                    </td>
                </tr>
                <tr>
                    <td>
                        <font face="Verdana" size="2"><strong>3. Nationality&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</strong>.............................................&nbsp;&nbsp;&nbsp;
                            Caste-Gen./OBC/SC/St/Other(Specifty )................</font>
                    </td>
                </tr>
                <tr>
                    <td height="5px">
                    </td>
                </tr>
                <tr>
                    <td>
                        <font face="Verdana" size="2"><strong>4. Father's Name&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</strong>............................................................</font>
                    </td>
                </tr>
                <tr>
                    <td height="5px">
                    </td>
                </tr>
                <tr>
                    <td>
                        <font face="Verdana" size="2"><strong>Father's Profession/occupation &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</strong>...........................................................</font>
                    </td>
                </tr>
                <tr>
                    <td height="5px">
                    </td>
                </tr>
                <tr>
                    <td>
                        <font face="Verdana" size="2"><strong>With Office Address&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</strong>............................................<strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Ph.</strong>...........................................</font>
                    </td>
                </tr>
                <tr>
                    <td height="5px">
                    </td>
                </tr>
                <tr>
                    <td>
                        <font face="Verdana" size="2"><strong>5.Mother's Name&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</strong>............................................................</font>
                    </td>
                </tr>
                <tr>
                    <td height="5px">
                    </td>
                </tr>
                <tr>
                    <td>
                        <font face="Verdana" size="2"><strong>Father's Profession/occupationp&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</strong>............................................................</font>
                    </td>
                </tr>
                <tr>
                    <td>
                        <font face="Verdana" size="2"><strong>With Office Address&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;</strong>............................................<strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Ph.</strong>...........................................</font>
                    </td>
                </tr>
                <tr>
                    <td height="5px">
                    </td>
                </tr>
                <tr>
                    <td>
                        <font face="Verdana" size="2"><strong>6. Guardian's Name&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</strong>.............................................
                        </font>
                    </td>
                </tr>
                <tr>
                    <td height="5px">
                    </td>
                </tr>
                <tr>
                    <td>
                        <font face="Verdana" size="2"><strong>Guardian's Profession/Occupation &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</strong>............................................<strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</strong></font>
                    </td>
                </tr>
                <tr>
                    <td height="5px">
                    </td>
                </tr>
                <tr>
                    <td>
                        <font face="Verdana" size="2"><strong>With Office Address&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</strong>............................................<strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Ph.</strong>...........................................</font>
                    </td>
                </tr>
                <tr>
                    <td height="5px">
                    </td>
                </tr>
                <tr>
                    <td>
                        <font face="Verdana" size="2"><strong>7.Permanent Address&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</strong>.....................................................................................</font>
                    </td>
                </tr>
                <tr>
                    <td height="5px">
                    </td>
                </tr>
                <tr>
                    <td>
                        <font face="Verdana" size="2">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;............................................<strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Ph.</strong>...........................................</font>
                    </td>
                </tr>
                <tr>
                    <td height="5px">
                    </td>
                </tr>
                <tr>
                    <td>
                        <font face="Verdana" size="2"><strong>8.Details of last examination passed (if any):-
                        </strong></font>
                    </td>
                </tr>
                <tr>
                    <td height="5px">
                    </td>
                </tr>
                <tr>
                    <td>
                        <table width="900px" border="1" cellspacing="0" cellpadding="0">
                            <tr>
                                <td width="300px">
                                    <strong>Name of Examination</strong>
                                </td>
                                <td width="200px">
                                    <strong>Passing Year</strong>
                                </td>
                                <td width="200px">
                                    <strong>Name of the School</strong>
                                </td>
                                <td width="200px">
                                    <strong>Marks%age obtained</strong>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    &nbsp; &nbsp;
                                </td>
                                <td>
                                    &nbsp;&nbsp; &nbsp;
                                </td>
                                <td>
                                </td>
                                <td>
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
                <tr>
                    <td height="5px">
                    </td>
                </tr>
                <tr>
                    <td>
                        <font face="Verdana" size="2"><strong>9.Stanard in Which admission is saught____________________________________________________
                        </strong></font>
                    </td>
                </tr>
                <tr>
                    <td height="5px">
                    </td>
                </tr>
                <tr>
                    <td>
                        <font face="Verdana" size="2"><strong>10.Whether Child's brother/Sister Studies in S.V.P.S.____________________________________________________
                        </strong></font>
                    </td>
                </tr>
                <tr>
                    <td>
                        <font face="Verdana" size="2"><strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; (if
                            yes, Please give his/her name with class)____________________________________________________
                        </strong></font>
                    </td>
                </tr>
                <tr>
                    <td height="5px">
                    </td>
                </tr>
                <tr>
                    <td>
                        <font face="Verdana" size="2"><strong>11. Enclosures : Attested Copies of : </strong>
                        </font>
                    </td>
                </tr>
                <tr>
                    <td height="5px">
                    </td>
                </tr>
                <tr>
                    <td>
                        <font face="Verdana" size="2"><strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;1.
                            Birth Certificate </strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<strong>2.Last
                                Progress Report(s)</strong></font>
                    </td>
                </tr>
                <tr>
                    <td height="5px">
                    </td>
                </tr>
                <tr>
                    <td>
                        <font face="Verdana" size="2"><strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;3.
                            School Transfer Certificate (T.C.) </strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<strong>4.
                                Other (Pl. Specify)</strong></font>
                    </td>
                </tr>
                <tr>
                    <td height="15px">
                    </td>
                </tr>
                <tr>
                    <td align="right">
                        <font face="Verdana" size="2"><strong>Signature of Parents/Guardian</strong></font>
                    </td>
                </tr>
                <tr>
                    <td height="15px">
                    </td>
                </tr>
                <tr>
                    <td align="center">
                        <font face="Verdana" size="4"><strong><u>DECLARATION BY PARENT OR GUARDIAN</u></strong></font>
                    </td>
                </tr>
                <tr>
                    <td height="15px">
                    </td>
                </tr>
                <tr>
                    <td>
                        <font face="Verdana" size="2"><strong>i,_______________________________father/guardian/mother
                            of ___________________________<br />
                            Solemnly declare and affirm on oath that:</strong></font>
                    </td>
                </tr>
                <tr>
                    <td height="5px">
                    </td>
                </tr>
                <tr>
                    <td>
                        <font face="Verdana" size="2"><strong>i) i have read the rules and regulations of the
                            play house as given in the Prospectus and agree to abide by them. </strong></font>
                    </td>
                </tr>
                <tr>
                    <td height="5px">
                    </td>
                </tr>
                <tr>
                    <td>
                        <font face="Verdana" size="2"><strong>ii) All the information given in this form is
                            correct to the best of my knowledge. </strong></font>
                    </td>
                </tr>
                <tr>
                    <td height="5px">
                    </td>
                </tr>
                <tr>
                    <td>
                        <font face="Verdana" size="2"><strong>iii) i undertak to let my ward remain in the school
                            as a disciplined student and abide by the others issud by the school authorities
                            from time to time. </strong></font>
                    </td>
                </tr>
                <tr>
                    <td height="5px">
                    </td>
                </tr>
                <tr>
                    <td>
                        <font face="Verdana" size="2"><strong>iv) i understand that if any information provided
                            in this form found to be false,the admission of the child will stand cancelled..
                        </strong></font>
                    </td>
                </tr>
                <tr>
                    <td height="5px">
                    </td>
                </tr>
                <tr>
                    <td align="right">
                        <font face="Verdana" size="2"><strong>Signature of Parents/Guardian </strong></font>
                    </td>
                </tr>
                <tr>
                    <td height="5px">
                    </td>
                </tr>
                <tr>
                    <td align="center">
                        <font face="Verdana" size="3"><strong>For Office Use </strong></font>
                    </td>
                </tr>
                <tr>
                    <td height="5px">
                    </td>
                </tr>
                <tr>
                    <td>
                        <font face="Verdana" size="2"><strong>Admission No.________________________________
                        </strong><strong>Standard_________________________</strong></font>
                    </td>
                </tr>
                <tr>
                    <td height="5px">
                    </td>
                </tr>
                <tr>
                    <td>
                        <font face="Verdana" size="2"><strong>Grade Provided to child at the time of interview________________________________
                        </strong><strong>by_________________________</strong></font>
                    </td>
                </tr>
                <tr>
                    <td height="5px">
                    </td>
                </tr>
                <tr>
                    <td align="right">
                        <font face="Verdana" size="2"><strong>Admission granted/rejected </strong></font>
                    </td>
                </tr>
                <tr>
                    <td height="10px">
                    </td>
                </tr>
                <tr>
                    <td align="right">
                        <font face="Verdana" size="2"><strong>Principal </strong></font>
                    </td>
                </tr>
            </table>
            </form></body>
</html>
