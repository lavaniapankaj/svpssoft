@extends('student.index')
@section('sub-content')
    <div class="container">
        @if (Session::has('success'))
            @section('scripts')
                <script>
                    swal("Good job!", "{{ Session::get('success') }}", "success").then(() => {
                        $('#std-form').hide();
                        location.reload();
                    });
                </script>
            @endsection
        @endif

        @if (Session::has('error'))
            @section('scripts')
                <script>
                    swal("Oops...", "{{ Session::get('error') }}", "error");
                </script>
            @endsection
        @endif
        <div class="row justify-content-center">
            <div class="col-md-14">
                <div class="card">
                    <div class="card-header">
                        {{ 'Cumulative Attendance Report' }}
                        <a href="{{ route('student.attendance.report') }}" class="btn btn-warning btn-sm"
                            style="float: right;">Back</a>

                    </div>
                    <div class="card-body">
                        <form id="class-section-form" method="GET">

                            <div class="row">
                                <div class="form-group col-md-4">
                                    <label for="class_id" class="mt-2">Class <span class="text-danger">*</span></label>
                                    <input type="hidden" id="initialClassId"
                                        value="{{ old('initialClassId', request()->get('class_id') !== null ? request()->get('class_id') : '') }}">
                                    <select name="class" id="class_id"
                                        class="form-control @error('class') is-invalid @enderror" required>
                                        <option value="">Select Class</option>
                                    </select>
                                    @error('class')
                                        <span class="invalid-feedback form-invalid fw-bold"
                                            role="alert">{{ $message }}</span>
                                    @enderror
                                    <img src="{{ config('myconfig.myloader') }}" alt="Loading..." class="loader"
                                        id="loader" style="display:none; width:10%;">
                                </div>


                                <div class="form-group col-md-4">
                                    <label for="section_id" class="mt-2">Section <span
                                            class="text-danger">*</span></label>
                                    <input type="hidden" id="initialSectionId"
                                        value="{{ old('initialSectionId', request()->get('section_id') !== null ? request()->get('section_id') : '') }}">
                                    <select name="section" id="section_id"
                                        class="form-control @error('section') is-invalid @enderror" required>
                                        <option value="">Select Section</option>

                                    </select>
                                    <input type="hidden" name="current_session" value='' id="current_session">
                                    @error('section')
                                        <span class="invalid-feedback form-invalid fw-bold"
                                            role="alert">{{ $message }}</span>
                                    @enderror
                                </div>
                                <div class="form-group col-md-4">
                                    <label for="std_id" class="mt-2">Student <span class="text-danger">*</span></label>
                                    <select name="std_id" id="std_id"
                                        class="form-control @error('std_id') is-invalid @enderror" required>
                                        <option value="">All Students</option>
                                    </select>
                                    @error('std_id')
                                        <span class="invalid-feedback form-invalid fw-bold"
                                            role="alert">{{ $message }}</span>
                                    @enderror
                                </div>
                            </div>

                            <div class="mt-3">
                                <button type="button" id="show-report" class="btn btn-primary"> Show Report</button>
                                <span class="text-danger fw-bold" id="no-data"></span>
                            </div>

                        </form>
                        <div id="report-table">

                            <div class="row table mt-2 table-responsive" id="">
                                <table id="report-excel" class="table table-striped table-bordered">
                                    <thead>
                                        <tr>
                                            <th>Rollno</th>
                                            <th>Student </th>
                                            <th colspan="3">April</th>
                                            <th colspan="3">May</th>
                                            <th colspan="3">June</th>
                                            <th colspan="3">July</th>
                                            <th colspan="3">August</th>
                                            <th colspan="3">September</th>
                                            <th colspan="3">October</th>
                                            <th colspan="3">November</th>
                                            <th colspan="3">December</th>
                                            <th colspan="3">January</th>
                                            <th colspan="3">February</th>
                                            <th colspan="3">March</th>
                                        </tr>

                                        <tr>
                                            <td></td>
                                            <td></td>
                                            <th>P</th>
                                            <th>A</th>
                                            <th>Cum.</th>
                                            <th>P</th>
                                            <th>A</th>
                                            <th>Cum.</th>
                                            <th>P</th>
                                            <th>A</th>
                                            <th>Cum.</th>
                                            <th>P</th>
                                            <th>A</th>
                                            <th>Cum.</th>
                                            <th>P</th>
                                            <th>A</th>
                                            <th>Cum.</th>
                                            <th>P</th>
                                            <th>A</th>
                                            <th>Cum.</th>
                                            <th>P</th>
                                            <th>A</th>
                                            <th>Cum.</th>
                                            <th>P</th>
                                            <th>A</th>
                                            <th>Cum.</th>
                                            <th>P</th>
                                            <th>A</th>
                                            <th>Cum.</th>
                                            <th>P</th>
                                            <th>A</th>
                                            <th>Cum.</th>
                                            <th>P</th>
                                            <th>A</th>
                                            <th>Cum.</th>
                                            <th>P</th>
                                            <th>A</th>
                                            <th>Cum.</th>

                                        </tr>
                                    </thead>
                                    <tbody id="report-body">


                                    </tbody>

                                </table>
                            </div>
                            <button id="download-excel" class="btn btn-primary mt-2">Download Excel</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
@section('std-scripts')
    <script>
        var initialClassId =
            '{{ old('initialClassId', request()->get('class_id') !== null ? request()->get('class_id') : '') }}';
        var initialSectionId =
            '{{ old('initialSectionId', request()->get('section_id') !== null ? request()->get('section_id') : '') }}';
        getClassSection(initialClassId, initialSectionId);

        $(document).ready(function() {
            var loader = $('#loader');
            var reportTable = $('#report-table');
            reportTable.hide();
            $('#no-data').hide();
            $('#class-section-form').validate({
                rules: {
                    std_id: {
                        required: true,
                    },
                    class: {
                        required: true,
                    },
                    section: {
                        required: true,
                    },
                },
                messages: {
                    std_id: {
                        required: "Please select student.",
                    },
                    class: {
                        required: "Please select a class.",
                    },
                    section: {
                        required: "Please select a section.",
                    },
                },
            });
            getStudentDropdown();

            // var stdSelect = $('#std_id');
            // $('#section_id').change(function() {
            //     let classId = $('#class_id').val();
            //     let sectionId = $('#section_id').val();
            //     let sessionId = $('#current_session').val();

            //     if (classId && sectionId && sessionId) {
            //         loader.show();
            //         $.ajax({
            //             url: '{{ route('stdNameFather.get') }}',
            //             type: 'GET',
            //             dataType: 'JSON',
            //             data: {
            //                 class_id: classId,
            //                 section_id: sectionId,
            //                 session_id: sessionId,
            //             },
            //             success: function(students) {
            //                 stdSelect.empty();
            //                 let options = '<option value="" selected>All Students</option>';
            //                 const allStudentSrnos = [];

            //                 if (students.length > 0) {
            //                     $.each(students, function(index, student) {
            //                         allStudentSrnos.push(student.srno);
            //                         options += '<option value="' + student.srno + '">' +
            //                             student.rollno + '. ' + student.student_name +
            //                             '/' +
            //                             student.f_name + '</option>';
            //                     });
            //                 } else {
            //                     // options += '<option value="">No students found</option>';
            //                     stdSelect.find('option[value=""]').text('No students found');
            //                 }

            //                 stdSelect.html(options);
            //                 stdSelect.find('option[value=""]').val(allStudentSrnos);

            //             },
            //             complete: function() {
            //                 loader.hide();
            //             },
            //             error: function(xhr) {
            //                 console.error(xhr.responseText);
            //             }
            //         });
            //     }
            // });

            function stdTable() {
                let classId = $('#class_id').val();
                let sectionId = $('#section_id').val();
                let sessionId = $('#current_session').val();
                let stdSelect = $('#std_id').val();
                if (classId && sectionId && sessionId && stdSelect) {
                    loader.show();
                    $.ajax({
                        url: '{{ route('student.cumulative-attendance.report') }}',
                        type: 'GET',
                        dataType: 'JSON',
                        data: {
                            class: classId,
                            section: sectionId,
                            session: sessionId,
                            std_id: stdSelect,
                        },
                        success: function(data) {
                            let row = '';
                            if (data.data !== 0) {
                                $.each(data.data, function(index, student) {

                                    const rollno = student.Rollno;
                                    const name = student.Name;

                                    row += `<tr>
                                        <td>${rollno}</td>
                                        <td>${name}</td>`;

                                    const months = ["Apr", "May", "Jun", "Jul", "Aug", "Sep",
                                        "Oct", "Nov",
                                        "Dec", "Jan", "Feb", "Mar"
                                    ];

                                    months.forEach(month => {
                                        row += `
                                            <td class="fw-bold text-success">${student.Attendance[month].P}</td>
                                            <td class="fw-bold text-danger">${student.Attendance[month].A}</td>
                                            <td class="fw-bold text-primary">${student.Attendance[month].C}</td>`;
                                    });

                                    row += `</tr>`;
                                });
                                $("#report-body").html(row);
                            } else {
                                row += `<tr><td colspan="37">No Student Found<td></tr>`;
                                $("#report-body").html(row);
                            }
                        },
                        complete: function() {
                            loader.hide();
                        },
                        error: function(xhr) {
                            console.error(xhr.responseText);
                        }
                    });
                }
            }

            $('#std_id').change(function() {
                stdTable();
            });
            $('#show-report').on('click', function() {
                if ($('#class-section-form').valid()) {
                    reportTable.show();
                    stdTable();
                }
            });
        });
    </script>
@endsection
