@extends('student.index')
@section('sub-content')
    <div class="container">
        @if (Session::has('success'))
            @section('scripts')
                <script>
                    swal("Good job!", "{{ Session::get('success') }}", "success").then(() => {
                        $('#std-form').hide();
                        location.reload();
                    });
                </script>
            @endsection
        @endif

        @if (Session::has('error'))
            @section('scripts')
                <script>
                    swal("Oops...", "{{ Session::get('error') }}", "error");
                </script>
            @endsection
        @endif
        <div class="row justify-content-center">
            <div class="col-md-14">
                <div class="card">
                    <div class="card-header">
                        {{ 'Attendance Report' }}
                        <a href="{{ route('student.attendance.report') }}" class="btn btn-warning btn-sm"
                            style="float: right;">Back</a>

                    </div>
                    <div class="card-body">
                        <form id="class-section-form" method="GET">

                            <div class="row">
                                <div class="form-group col-md-4">
                                    <label for="class_id" class="mt-2">Class <span class="text-danger">*</span></label>
                                    <input type="hidden" id="initialClassId"
                                        value="{{ old('initialClassId', request()->get('class_id') !== null ? request()->get('class_id') : '') }}">
                                    <select name="class" id="class_id"
                                        class="form-control @error('class') is-invalid @enderror" required>
                                        <option value="">Select Class</option>
                                    </select>
                                    @error('class')
                                        <span class="invalid-feedback form-invalid fw-bold"
                                            role="alert">{{ $message }}</span>
                                    @enderror
                                    <img src="{{ config('myconfig.myloader') }}" alt="Loading..." class="loader"
                                        id="loader" style="display:none; width:10%;">
                                </div>


                                <div class="form-group col-md-4">
                                    <label for="section_id" class="mt-2">Section <span
                                            class="text-danger">*</span></label>
                                    <input type="hidden" id="initialSectionId"
                                        value="{{ old('initialSectionId', request()->get('section_id') !== null ? request()->get('section_id') : '') }}">
                                    <select name="section" id="section_id"
                                        class="form-control @error('section') is-invalid @enderror" required>
                                        <option value="">Select Section</option>

                                    </select>
                                    <input type="hidden" name="current_session" value='' id="current_session">
                                    @error('section')
                                        <span class="invalid-feedback form-invalid fw-bold"
                                            role="alert">{{ $message }}</span>
                                    @enderror
                                </div>
                                <div class="form-group col-md-4">
                                    <label for="std_id" class="mt-2">Student <span class="text-danger">*</span></label>
                                    <select name="std_id" id="std_id"
                                        class="form-control @error('std_id') is-invalid @enderror" required>
                                        <option value="">All Students</option>
                                    </select>
                                    @error('std_id')
                                        <span class="invalid-feedback form-invalid fw-bold"
                                            role="alert">{{ $message }}</span>
                                    @enderror
                                </div>
                            </div>
                            <div class="row">
                                <div class="form-group col-md-6">
                                    <label for="start_date" class="mt-2">Enter Start Date <span
                                            class="text-danger">*</span></label>
                                    <input type="date" name="start_date" id="start_date"
                                        class="form-control @error('start_date') is-invalid @enderror" required>
                                    @error('start_date')
                                        <span class="invalid-feedback form-invalid fw-bold"
                                            role="alert">{{ $message }}</span>
                                    @enderror
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="end_date" class="mt-2">Enter End Date <span
                                            class="text-danger">*</span></label>
                                    <input type="date" name="end_date" id="end_date"
                                        class="form-control @error('end_date') is-invalid @enderror" required>
                                    @error('end_date')
                                        <span class="invalid-feedback form-invalid fw-bold"
                                            role="alert">{{ $message }}</span>
                                    @enderror
                                </div>
                            </div>
                            <div class="mt-3">
                                <button type="button" id="show-report" class="btn btn-primary"> Show Report</button>
                                <span class="text-danger fw-bold" id="no-data"></span>
                            </div>

                        </form>
                        <div class="row table mt-2" id="report-table">
                            <table id="report-excel" class="table table-striped table-bordered">
                                <thead>
                                    <tr>
                                        <th colspan="3">Summary</th>
                                    </tr>
                                    <tr>
                                        <th>Days</th>
                                        <th>Present</th>
                                        <th>Absent</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td></td>
                                        <td id="present"></td>
                                        <td id="absent"></td>
                                    </tr>
                                    <tr>
                                        <th colspan="3">Details</th>
                                    </tr>
                                    <tr id="details-row">
                                        <th colspan="2">Date</th>
                                        <th>Status</th>
                                    </tr>

                                </tbody>

                            </table>
                            <button id="download-csv" type="button" class="btn btn-primary mt-2">Download Excel</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
@section('std-scripts')
    {{-- <script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.17.0/xlsx.full.min.js"></script> --}}
    {{-- <script src="https://cdn.jsdelivr.net/gh/linways/table-to-excel@v1.0.4/dist/tableToExcel.js"></script> --}}
    {{-- <script src="//cdn.rawgit.com/rainabba/jquery-table2excel/1.1.0/dist/jquery.table2excel.min.js"></script> --}}
    {{-- <script src="extensions/export/bootstrap-table-export.js"></script> --}}
    <script>
        var initialClassId =
            '{{ old('initialClassId', request()->get('class_id') !== null ? request()->get('class_id') : '') }}';
        var initialSectionId =
            '{{ old('initialSectionId', request()->get('section_id') !== null ? request()->get('section_id') : '') }}';
        getClassSection(initialClassId, initialSectionId);

        $(document).ready(function() {
            var loader = $('#loader');
            var reportTable = $('#report-table');
            reportTable.hide();
            $('#no-data').hide();
            $('#class-section-form').validate({
                rules: {
                    start_date: {
                        required: true,
                    },
                    end_date: {
                        required: true,
                    },
                    std_id: {
                        required: true,
                    },
                    class: {
                        required: true,
                    },
                    section: {
                        required: true,
                    },
                },
                messages: {
                    start_date: {
                        required: "Please select start date.",
                    },
                    end_date: {
                        required: "Please select end date.",
                    },
                    std_id: {
                        required: "Please select student.",
                    },
                    class: {
                        required: "Please select a class.",
                    },
                    section: {
                        required: "Please select a section.",
                    },
                },
            });
            getStudentDropdown();

            // $('#section_id').change(function() {
            //     var classId = $('#class_id').val();
            //     var sectionId = $(this).val();
            //     var sessionId = $('#current_session').val();
            //     var stdSelect = $('#std_id');

            //     if (classId && sectionId && sessionId) {
            //         loader.show();
            //         $.ajax({
            //             url: '{{ route('stdNameFather.get') }}',
            //             type: 'GET',
            //             dataType: 'JSON',
            //             data: {
            //                 class_id: classId,
            //                 section_id: sectionId,
            //                 session_id: sessionId,
            //             },
            //             success: function(students) {
            //                 stdSelect.empty();

            //                 let options = '<option value="" selected>All Students</option>';
            //                 const allStudentSrnos = [];

            //                 if (students.length > 0) {
            //                     $.each(students, function(index, student) {
            //                         allStudentSrnos.push(student.srno);
            //                         options += '<option value="' + student.srno + '">' +
            //                             student.rollno + '. ' + student.student_name +
            //                             '/' +
            //                             student.f_name + '</option>';
            //                     });
            //                 } else {
            //                     options += '<option value="">No students found</option>';
            //                 }

            //                 stdSelect.html(options);

            //                 stdSelect.find('option[value=""]').val(allStudentSrnos);

            //             },
            //             complete: function() {
            //                 loader.hide();
            //             },
            //             error: function(xhr) {
            //                 console.error(xhr.responseText);
            //             }
            //         });
            //     }
            // });

            $('#show-report').on('click', function() {
                if ($('#class-section-form').valid()) {
                    const classId = $('#class_id').val();
                    const section = $('#section_id').val();
                    const startDate = $('#start_date').val();
                    const endDate = $('#end_date').val();
                    const std = $('#std_id').val();
                    const session = $('#current_session').val();

                    $.ajax({
                        url: '{{ route('student.attendance.report.get') }}',
                        type: 'GET',
                        dataType: 'JSON',
                        data: {
                            class: classId,
                            section: section,
                            start_date: startDate,
                            end_date: endDate,
                            std_id: std,
                            current_session: session,
                        },
                        success: function(data) {
                            $('#details-row').nextAll().remove();
                            if (data.message === 'No Record Found') {
                                console.log(data.message);
                                $('#no-data').show().text(data.message);
                                reportTable.hide();
                            } else {
                                $('#present').text(data.present);
                                $('#absent').text(data.absent);
                                $.each(data.data, function(index, value) {
                                    var rowHtml = `
                                     <tr>
                                        <td colspan="2">${value.a_date ?? 'N/A'}</td>
                                        <td>${(value.status == 1 ? 'P' : 'A') ?? 'N/A'}</td>
                                     </tr>
                                    `;
                                    $('#details-row').after(rowHtml);
                                });

                                reportTable.show();
                                $('#no-data').hide();
                            }
                        },
                        complete: function() {
                            loader.hide();
                        },
                        error: function(xhr) {
                            console.error(xhr.responseText);
                        }
                    });
                } else {
                    reportTable.hide();
                }
            });

            $('#download-csv').on('click', function() {
                const classId = $('#class_id').val();
                const section = $('#section_id').val();
                const startDate = $('#start_date').val();
                const endDate = $('#end_date').val();
                const std = $('#std_id').val();
                const session = $('#current_session').val();

                // Redirect to the download route with parameters
                window.location.href = '{{ route('student.download.attendance.csv') }}?class=' + classId +
                    '&section=' + section + '&start_date=' + startDate + '&end_date=' + endDate +
                    '&std_id=' + std + '&current_session=' + session;
            });


            // $('#download-excel').on('click', function() {
            //     // Create a new workbook
            //     const wb = XLSX.utils.book_new();

            //     // Prepare data for a single worksheet
            //     const wsData = [
            //         ['Summary'],
            //         ['Days', 'Present', 'Absent'],
            //         ['', $('#present').text(), $('#absent').text()],
            //         [], // Empty row for spacing
            //         ['Details'],
            //         ['Date', 'Status']
            //     ];

            //     // Add the details rows
            //     $('#example tbody tr').each(function() {
            //         const date = $(this).find('td:first').text();
            //         const status = $(this).find('td:last').text();
            //         wsData.push([date, status]);
            //     });

            //     // Create the worksheet
            //     const ws = XLSX.utils.aoa_to_sheet(wsData);

            //     // Apply styling
            //     const range = XLSX.utils.decode_range(ws['!ref']);
            //     for (let R = range.s.r; R <= range.e.r; ++R) {
            //         for (let C = range.s.c; C <= range.e.c; ++C) {
            //             const cellRef = XLSX.utils.encode_cell({
            //                 r: R,
            //                 c: C
            //             });
            //             if (!ws[cellRef]) continue;

            //             ws[cellRef].s = {
            //                 border: {
            //                     top: {
            //                         style: 'thin',
            //                         color: {
            //                             rgb: "000000"
            //                         }
            //                     },
            //                     bottom: {
            //                         style: 'thin',
            //                         color: {
            //                             rgb: "000000"
            //                         }
            //                     },
            //                     left: {
            //                         style: 'thin',
            //                         color: {
            //                             rgb: "000000"
            //                         }
            //                     },
            //                     right: {
            //                         style: 'thin',
            //                         color: {
            //                             rgb: "000000"
            //                         }
            //                     }
            //                 }
            //             };

            //             // Add gray background to headers
            //             if (R === 0 || R === 1 || R === 4 || R === 5) {
            //                 ws[cellRef].s.fill = {
            //                     fgColor: {
            //                         rgb: "DDDDDD"
            //                     }
            //                 };
            //                 ws[cellRef].s.font = {
            //                     bold: true
            //                 };
            //             }
            //         }
            //     }

            //     // Adjust column widths
            //     ws['!cols'] = [{
            //         wch: 20
            //     }, {
            //         wch: 20
            //     }, {
            //         wch: 20
            //     }];

            //     // Add the worksheet to the workbook
            //     XLSX.utils.book_append_sheet(wb, ws, 'Attendance Report');

            //     // Export the workbook
            //     XLSX.writeFile(wb, 'attendance_report.xlsx');
            // });

            // $("#download-excel").click(function() {
            //     TableToExcel.convert(document.getElementById("report-excel"), {
            //         name: "Traceability.xls",
            //         sheet: {
            //             name: "Sheet1"
            //         },
            //         preserveColors: true,
            //     });
            // });

            // $('#download-excel').on('click', function () {
            //     $("#report-excel").table2excel({
            //         filename: "employeeData.xls",
            //         preserveColors: true,
            //         preserveStyle: true,
            //     });
            // });

            // $('#download-excel').bootstrapExcelExport({ tableSelector : '#report-excel' });

        });
    </script>
@endsection
