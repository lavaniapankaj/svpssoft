@extends('admin.index')
@section('sub-content')
    <div class="container">

        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">{{ __('Student Full Detail') }}
                        <a class="btn btn-warning btn-sm" style="float: right;" onclick="history.back()">Back</a>
                    </div>

                    <div class="card-body">
                        <input type="hidden" name="prev_srno" id="prev-srno"
                            value="{{ $prevSrno !== 'null' ? $prevSrno : $srno }}">
                        <input type="hidden" name="srno" id="srno" value="{{ $srno }}">
                        {{-- Optional: Add debug output in development --}}


                        {{-- previous records  --}}

                        <div class="table" id="prev_record">
                            <h4 class="text-danger fw-bold">Previous Details</h4>
                            <table id="example" class="table table-striped table-bordered">
                                <thead>
                                    <tr>
                                        <th>Session</th>
                                        <th>Class</th>
                                        <th>Section</th>
                                        <th>Rollno</th>
                                        <th>Gender</th>
                                        <th>Religion</th>
                                        <th>Admission Date</th>
                                    </tr>
                                </thead>
                                <tbody></tbody>

                            </table>


                        </div>

                        {{-- Current Details   --}}

                        <div class="table table-responsive" id="current_details">
                            <h4 class="text-danger fw-bold">Current Details</h4>
                            <table id="example" class="table table-striped table-bordered">
                                <thead>
                                    <tr>
                                        <th>SRNO</th>
                                        <th>Name</th>
                                        <th>DOB</th>
                                        <th>Address</th>
                                        <th>Category</th>
                                        <th>E-Mail</th>
                                        <th>Mobile</th>
                                        <th>Father's Name</th>
                                        <th>Mother's Name</th>
                                        <th>Address</th>
                                        <th>F. Mobile</th>
                                        <th>M. Mobile</th>
                                        <th>F. Occupation</th>
                                        <th>M. Occupation</th>
                                    </tr>
                                </thead>
                                <tbody></tbody>

                            </table>


                        </div>

                    </div>

                </div>
            </div>
        </div>
    </div>
@endsection
@section('admin-scripts')
    <script>
        $(document).ready(function() {
            let prevRecord = $('#prev_record');
            let currentDetail = $('#current_details');
            let prevsrno = $('#prev-srno').val();
            let srno = $('#srno').val();
            if (prevsrno) {
                // prevRecord.show();
                $.ajax({
                    url: '{{ route('admin.getStdWithSrno') }}',
                    type: 'GET',
                    data: {
                        srno: prevsrno
                    },
                    success: function(students) {
                        let stdHtml = '';
                        $.each(students.data, function(index, std) {
                            stdHtml += `<tr>
                                    <td>${std.session_name}</td>
                                    <td>${std.class_name}</td>
                                    <td>${std.section_name}</td>
                                    <td>${std.rollno}</td>
                                    <td>${std.gender === 1 ? 'Male' : std.gender === 2 ? 'Female' : 'Others'}</td>
                                    <td>${std.religion === 1 ? 'Hinduism' : std.religion === 2 ? 'Christianity' : 'Islam'}</td>
                                    <td>${std.form_submit_date ?? ''}</td>
                                </tr>`;
                        });
                        $('#prev_record table tbody').html(stdHtml);
                    },
                    error: function(xhr) {
                        console.error(xhr.responseText);
                    }
                });
            } else {
                // prevRecord.hide();

            }

            if (srno) {
                // currentDetail.show();
                $.ajax({
                    url: '{{ route('admin.getStdWithSrno') }}',
                    type: 'GET',
                    data: {
                        srno: srno
                    },
                    success: function(students) {
                        let std = students.data[0];
                        let stdHtml = '';
                        stdHtml += `<tr>
                                    <td>${std.srno}</td>
                                    <td>${std.student_name}</td>
                                    <td>${std.dob}</td>
                                    <td>${std.address}</td>
                                    <td>${std.category === 1 ? 'General' : std.category === 2 ? 'OBC' : 'SC/ST'}</td>
                                    <td>${std.student_email}</td>
                                    <td>${std.student_mobile}</td>
                                    <td>${std.f_name}</td>
                                    <td>${std.m_name}</td>
                                    <td>${std.parent_address}</td>
                                    <td>${std.f_mobile ?? 'N/A'}</td>
                                    <td>${std.m_mobile ?? 'N/A'}</td>
                                    <td>${std.f_occupation}</td>
                                    <td>${std.m_occupation}</td>
                                </tr>`;
                        $('#current_details table tbody').html(stdHtml);
                    },
                    error: function(xhr) {
                        console.error(xhr.responseText);
                    }
                });
            } else {
                // currentDetail.hide();
            }
        });
    </script>
@endsection
