@extends('admin.index')

@section('sub-content')
    <div class="container">

        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card">
                        <div class="card-header">
                            {{ isset($marks) && isset($marks->id) ? 'Edit Marks' : 'Add New Marks' }}
                            <a href="{{ route('admin.marks-master.index') }}" class="btn btn-warning btn-sm"
                                    style="float: right;">Back</a>

                        </div>

                        <div class="card-body">
                            <form action="{{ route('admin.marks-master.store') }}" method="POST"
                                enctype="multipart/form-data" id="basic-form">
                                @csrf
                                <input type="hidden" name="id" id="id"
                                    value="{{ isset($marks) ? $marks->id : '' }}">

                                <div class="row">
                                    <div class="form-group col-md-4">
                                        <input type="hidden" name="current_session" value='' id="current_session">
                                        <label for="class_id" class="mt-2">Class <span
                                                class="text-danger">*</span></label>
                                        <input type="hidden" id="initialClassId"
                                            value="{{ isset($marks) ? $marks->class_id : '' }}">
                                        <select name="class_id" id="class_id"
                                            class="form-control @error('class_id') is-invalid @enderror" required>
                                            <option value="">Select Class</option>

                                        </select>
                                        @error('class_id')
                                            <span class="invalid-feedback form-invalid fw-bold" role="alert">
                                                {{ $message }}
                                            </span>
                                        @enderror
                                    </div>
                                    <div class="form-group col-md-4">

                                        <label for="subject_id" class="mt-2">Subject <span
                                                class="text-danger">*</span></label>
                                        <input type="hidden" id="initialClassId"
                                            value="{{ isset($marks) ? $marks->subject_id : '' }}">
                                        <select name="subject_id" id="subject_id"
                                            class="form-control @error('subject_id') is-invalid @enderror" required>
                                            <option value="">Select Subject</option>
                                        </select>
                                        @error('subject_id')
                                            <span class="invalid-feedback form-invalid fw-bold" role="alert">
                                                {{ $message }}
                                            </span>
                                        @enderror
                                    </div>
                                    <div class="form-group col-md-4">
                                        <label for="exam_id" class="mt-2">Exam <span
                                                class="text-danger">*</span></label>
                                        <input type="hidden" id="initialExamId"
                                            value="{{ isset($marks) ? $marks->exam_id : '' }}">
                                        <select name="exam_id" id="exam_id"
                                            class="form-control @error('exam_id') is-invalid @enderror" required>
                                            <option value="">Select Exam</option>
                                            {{-- @foreach ($exams as $exam)
                                                <option value="{{ $exam->id }}" {{ old('exam_id', isset($marks) ? $marks->exam_id : '') == $exam->id ? 'selected' : '' }}>{{ $exam->exam }}</option>
                                            @endforeach --}}
                                        </select>
                                        @error('exam_id')
                                            <span class="invalid-feedback form-invalid fw-bold" role="alert">
                                                {{ $message }}
                                            </span>
                                        @enderror
                                    </div>
                                    <img src="{{ config('myconfig.myloader') }}" alt="Loading..." class="loader"
                                        id="loader" style="display:none; width:10%;">
                                </div>

                                <div class="row">
                                    <div class="form-group col-md-6">
                                        <label for="min_marks" class="mt-2">Enter Minimum Marks <span
                                                class="text-danger">*</span></label>
                                        <input type="text" name="min_marks"
                                            class="form-control @error('min_marks') is-invalid @enderror"
                                            placeholder="Minimum Marks"
                                            value="{{ old('min_marks', isset($marks) ? $marks->min_marks : '') }}" id="min_marks" required>
                                        @error('min_marks')
                                            <span class="invalid-feedback form-invalid fw-bold" role="alert">
                                                {{ $message }}
                                            </span>
                                        @enderror
                                    </div>
                                    <div class="form-group col-md-6">
                                        <label for="max_marks" class="mt-2">Enter Maximum Marks <span
                                                class="text-danger">*</span></label>
                                        <input type="text" name="max_marks"
                                            class="form-control @error('max_marks') is-invalid @enderror"
                                            placeholder="Maximum Marks"
                                            value="{{ old('max_marks', isset($marks) ? $marks->max_marks : '') }}" id="max_marks" required>
                                        @error('max_marks')
                                            <span class="invalid-feedback form-invalid fw-bold" role="alert">
                                                {{ $message }}
                                            </span>
                                        @enderror
                                    </div>
                                </div>
                                <div class="mt-3">
                                    <input class="btn btn-primary" type="submit"
                                        value="{{ isset($marks) && isset($marks->id) ? 'Update' : 'Save' }}">
                                </div>
                            </form>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
@endsection
@section('admin-scripts')
    <script>
        var initialClassId = '{{ old('class_id', isset($marks) ? $marks->class_id : '') }}';
        getClassSection(initialClassId);
        var initialSubjectId = '{{ old('subject_id', isset($marks) ? $marks->subject_id : '') }}';
        getClassSubject(initialClassId,initialSubjectId);
        var initialExamId = '{{ old('exam_id', isset($marks) ? $marks->exam_id : '') }}';
        getExams(initialExamId);
    </script>
@endsection
