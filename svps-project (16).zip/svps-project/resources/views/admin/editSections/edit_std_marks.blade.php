@extends('admin.index')
@section('sub-content')
    <div class="container">

        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">
                        {{ 'Edit/Remove Relative Students' }}
                        <a href="{{ route('admin.editSection.index') }}" class="btn btn-warning btn-sm"
                            style="float: right;">Back</a>

                    </div>
                    <div class="card-body">
                        {{-- <form method="POST" action="{{ route('admin.editSection.editStdMarks.store') }}" id="update-form"> --}}
                        <form method="POST" action="" id="update-form">
                            @csrf
                            <div class="row">
                                <div class="form-group col-md-4">
                                    <label for="class_id" class="mt-2">Class <span class="text-danger">*</span></label>
                                    <input type="hidden" name="current_session" value='' id="current_session">
                                    <input type="hidden" id="initialClassId" name="initialClassId"
                                        value="{{ old('initialClassId', request()->get('class_id') !== null ? request()->get('class_id') : '') }}">
                                    <select name="class_id" id="class_id"
                                        class="form-control mx-1 @error('class_id') is-invalid @enderror">
                                        <option value="">Select Class</option>
                                    </select>
                                    {{-- @error('class_id') --}}
                                    <span class="invalid-feedback form-invalid fw-bold class-error" role="alert">

                                    </span>
                                    {{-- @enderror --}}
                                </div>
                                <div class="form-group col-md-4">
                                    <label for="section_id" class="mt-2">Section<span class="text-danger">*</span></label>
                                    <input type="hidden" id="initialSectionId" name="initialSectionId"
                                        value="{{ old('initialSectionId', request()->get('section_id') !== null ? request()->get('section_id') : '') }}">
                                    <select name="section_id" id="section_id"
                                        class="form-control mx-1 @error('section_id') is-invalid @enderror section-error">
                                        <option value="">Select Section</option>
                                    </select>
                                    {{-- @error('section_id') --}}
                                    <span class="invalid-feedback form-invalid fw-bold section-error" role="alert">

                                    </span>
                                    {{-- @enderror --}}
                                </div>
                                <div class="form-group col-md-4">
                                    <label for="section_id" class="mt-2">Student<span class="text-danger">*</span></label>
                                    <input type="hidden" id="initialStdId" name="initialStdId"
                                        value="{{ old('initialStdId', request()->get('std_id') !== null ? request()->get('std_id') : '') }}">
                                    <select name="std_id" id="std_id"
                                        class="form-control mx-1 @error('std_id') is-invalid @enderror">
                                        <option value="">Select Student</option>
                                    </select>
                                    {{-- @error('std_id') --}}
                                    <span class="invalid-feedback form-invalid fw-bold student-error" role="alert">

                                    </span>
                                    {{-- @enderror --}}
                                </div>
                                <img src="{{ config('myconfig.myloader') }}" alt="Loading..." class="loader" id="loader"
                                    style="display:none; width:10%;">
                            </div>
                            <div class="row">
                                <div class="form-group col-md-6">
                                    <label for="subject_id" class="mt-2">Subject <span
                                            class="text-danger">*</span></label>
                                    <input type="hidden" id="initialSubjectId"
                                        value="{{ old('initialSubjectId', request()->get('subject_id') !== null ? request()->get('subject_id') : '') }}">
                                    <select name="subject" id="subject_id"
                                        class="form-control @error('subject') is-invalid @enderror">
                                        <option value="">Select Subject</option>
                                    </select>
                                    {{-- @error('subject') --}}
                                    <span class="invalid-feedback form-invalid fw-bold subject-error" role="alert"></span>
                                    {{-- @enderror --}}

                                </div>
                                <div class="form-group col-md-6">
                                    <label for="exam_id" class="mt-2">Exam <span class="text-danger">*</span></label>
                                    <input type="hidden" id="initialExamId"
                                        value="{{ old('initialExamId', request()->get('exam_id') !== null ? request()->get('exam_id') : '') }}">
                                    <select name="exam" id="exam_id"
                                        class="form-control @error('exam') is-invalid @enderror">
                                        <option value="">Select Exam</option>

                                    </select>
                                    {{-- @error('exam') --}}
                                    <span class="invalid-feedback form-invalid fw-bold exam-error" role="alert"></span>
                                    {{-- @enderror --}}
                                </div>
                            </div>
                            <div class="row">
                                <div class="form-group col-md-6">
                                    <label for="marks" class="mt-2">Enter Marks <span
                                            class="text-danger">*</span></label>
                                    <input type="text" name="marks" id="marks"
                                        class="form-control @error('marks') is-invalid @enderror">
                                    {{-- @error('marks') --}}
                                    <span class="invalid-feedback form-invalid fw-bold marks-error" role="alert"></span>
                                    {{-- @enderror --}}
                                </div>

                                <div class="form-group col-md-6">
                                    <label class="form-check-label mt-4" for="flexCheckDefault">Attendance(Check for
                                        Present) <span class="text-danger">*</span></label>
                                    <input type="checkbox" name="attendance" id="flexCheckDefault" value="1"
                                        class="form-check-input mt-4 border border-black @error('attendance') is-invalid @enderror">
                                    {{-- @error('attendance') --}}
                                    <span class="invalid-feedback form-invalid fw-bold attendance-error"
                                        role="alert"></span>
                                    {{-- @enderror --}}
                                </div>
                            </div>
                            <div class="mt-3">
                                <button type="button" class="btn btn-primary" id="marks-updateBtn">Update Marks</button>

                            </div>

                        </form>


                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
@section('admin-scripts')
    <script>
        $(document).ready(function() {
            let initialClassId = $('#class_id').val();
            let initialSectionId = $('#section_id').val();
            let initialStdId = $('#std_id').val();
            getClassSection(initialClassId, initialSectionId);
            getStdDropdown();
            let initialSubjectId = $('#subject_id').val();
            getClassSubject(initialClassId, initialSubjectId);
            let initialExamId = $('#exam_id').val();
            getExams(initialExamId);

            $('#marks-updateBtn').on('click', function() {
                $.ajax({
                    url: "{{ route('admin.editSection.editStdMarks.store') }}",
                    type: "POST",
                    dataType: 'JSON',
                    data: $('#update-form').serialize(),
                    success: function(data) {
                       if (data.status == 'success') {

                            Swal.fire({
                                title: 'Good job!',
                                text: data.message,
                                icon: 'success',
                                confirmButtonColor: 'rgb(122 190 255)',
                            }).then(() => {
                                location.reload();
                            });
                        }else{
                            Swal.fire({
                                title: 'Oops...',
                                text: data.message,
                                icon: 'error',
                                confirmButtonColor: 'rgb(122 190 255)',
                            });
                        }

                    },
                    error: function(data) {
                        // console.log(data);
                        let message = data.responseJSON.message;
                        $('.marks-error').hide().html('');
                        $('.subject-error').hide().html('');
                        $('.class-error').hide().html('');
                        $('.section-error').hide().html('');
                        $('.student-error').hide().html('');
                        $('.exam-error').hide().html('');
                        $('.attendance-error').hide().html('');


                        if (message.class_id) {
                            $('.class-error').show().html(message.class_id);
                        }
                        if (message.section_id) {
                            $('.section-error').show().html(message.section_id);
                        }
                        if (message.std_id) {
                            $('.student-error').show().html(message.std_id);
                        }
                        if (message.subject) {
                            $('.subject-error').show().html(message.subject);
                        }
                        if (message.exam) {
                            $('.exam-error').show().html(message.exam);
                        }
                        if (message.marks) {
                            $('.marks-error').show().html(message.marks);
                        }
                        if (message.attendance) {
                            $('.attendance-error').show().html(message.attendance);
                        }
                    }
                });
                // }
            });

        });
    </script>
@endsection
