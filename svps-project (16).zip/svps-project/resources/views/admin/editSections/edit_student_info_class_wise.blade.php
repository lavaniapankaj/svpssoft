@extends('admin.index')
@section('sub-content')
    <div class="container">
        @if (Session::has('success'))
            @section('scripts')
                <script>
                    swal("Good job!", "{{ Session::get('success') }}", "success").then(() => {
                        $('#std-form').hide();
                        location.reload();
                    });
                </script>
            @endsection
        @endif

        @if (Session::has('error'))
            @section('scripts')
                <script>
                    swal("Oops...", "{{ Session::get('error') }}", "error");
                </script>
            @endsection
        @endif
        <div class="row justify-content-center">
            <div class="col-md-14">
                <div class="card">
                    <div class="card-header">
                        {{ 'Update Student Info. Class Wise' }}
                        <a href="{{ route('admin.editSection.index') }}" class="btn btn-warning btn-sm"
                            style="float: right;">Back</a>

                    </div>
                    <div class="card-body">
                        <form id="class-section-form">
                            <div class="row">
                                <div class="form-group col-md-6">
                                    <label for="class_id" class="mt-2">Class <span class="text-danger">*</span></label>
                                    <input type="hidden" id="initialClassId" value="{{ old('initialClassId',request()->get('class_id') !== null ? request()->get('class_id') : '') }}">
                                    <select name="class" id="class_id"
                                        class="form-control @error('class') is-invalid @enderror" required>
                                        <option value="">Select Class</option>

                                    </select>
                                    @error('class')
                                        <span class="invalid-feedback form-invalid fw-bold"
                                            role="alert">{{ $message }}</span>
                                    @enderror
                                    <img src="{{ config('myconfig.myloader') }}" alt="Loading..." class="loader"
                                        id="loader" style="display:none; width:10%;">
                                </div>


                                <div class="form-group col-md-6">
                                    <label for="section_id" class="mt-2">Section <span
                                            class="text-danger">*</span></label>
                                            <input type="hidden" id="initialSectionId" value="{{ old('initialSectionId',request()->get('section_id') !== null ? request()->get('section_id') : '') }}">
                                    <select name="section" id="section_id"
                                        class="form-control @error('section') is-invalid @enderror" required>
                                        <option value="">Select Section</option>

                                    </select>
                                    @error('section')
                                        <span class="invalid-feedback form-invalid fw-bold"
                                            role="alert">{{ $message }}</span>
                                    @enderror
                                </div>
                            </div>


                            <div class="mt-3">
                                <button type="button" id="show-details" class="btn btn-primary">
                                    Show Details</button>
                            </div>

                        </form>


                        <div id="std-container" class="mt-4">
                            <form action="{{ route('admin.editSection.editStdInfoClass.store') }}" method="POST"
                                enctype="multipart/form-data" id="std-form">
                                @csrf
                                <table class="table table-responsible">
                                    <input type="hidden" name="current_session" value='' id="current_session">

                                    <thead>
                                        <tr>
                                            <th>Roll No.</th>
                                            <th>SRNO</th>
                                            <th>Name</th>
                                            <th>Father Name</th>
                                            <th>Mother Name</th>
                                            <th>Grand Father Name</th>
                                            <th>DOB</th>
                                            <th>Contact 1</th>
                                            <th>Contact 2</th>
                                            <th>Age Proof</th>
                                        </tr>
                                    </thead>
                                    <tbody>

                                    </tbody>
                                </table>
                                <div id="std-pagination"></div>
                                <div class="row">
                                    <div class="mt-3">
                                        <button type="submit" class="btn btn-primary"
                                            id="section-updateBtn">Update</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
@section('admin-scripts')
    <script>
       var initialClassId = '{{ old('initialClassId',request()->get('class_id') !== null ? request()->get('class_id') : '') }}';
        var initialSectionId = '{{ old('initialClassId',request()->get('section_id') !== null ? request()->get('section_id') : '') }}';
        getClassSection(initialClassId, initialSectionId);

        $(document).ready(function() {
            $('#std-form').hide();
            var loader = $('#loader');
            $('#show-details').on('click', function() {

                const classId = $('#class_id').val();
                const sectionId = $('#section_id').val();
                const sessionId = $('#current_session').val();
                const paginationContainer = $('#std-pagination');
                var page = 1;
                loader.show();

                function stdDetails(page) {
                    if (classId && sectionId && sessionId) {
                        $('#std-form').show();
                        $.ajax({
                            url: '{{ route('stdNameFather.get') }}',
                            type: 'GET',
                            dataType: 'JSON',
                            data: {
                                class_id: classId,
                                section_id: sectionId,
                                session_id: sessionId,
                                page: page,
                            },
                            success: function(students) {
                                let stdHtml = '';
                                $.each(students.data, function(index, std) {


                                    stdHtml += `<tr>
                                                <td>${std.rollno}</td>
                                                <td>${std.srno}</td>
                                                <td>
                                                    <input type="hidden" name="students[${index}][srno]" value="${std.srno}" class="std-srno" id="std-srno" data-index="${index}">
                                                    <input type="text" name="students[${index}][student_name]" value='${std.student_name}' class="form-control @error('students[${index}][student_name]') is-invalid @enderror std-name" data-index="${index}">
                                                        <span class="invalid-feedback form-invalid fw-bold error" id="std-name-error" role="alert">
                                                        </span>
                                                    @error('students[${index}][student_name]')
                                                        <span class="invalid-feedback form-invalid fw-bold error" role="alert">
                                                            {{ meaasge }}
                                                        </span>
                                                    @enderror
                                                </td>
                                                <td>
                                                    <input type="text" name="students[${index}][f_name]" value='${std.f_name}' class="form-control @error('students[${index}][f_name]') is-invalid @enderror f_name" data-index="${index}">
                                                        <span class="invalid-feedback form-invalid fw-bold error" id="std-fname-error" role="alert">
                                                        </span>
                                                    @error('students[${index}][f_name]')
                                                        <span class="invalid-feedback form-invalid fw-bold error" role="alert">
                                                            {{ meaasge }}
                                                        </span>
                                                    @enderror
                                                </td>
                                                <td>
                                                    <input type="text" name="students[${index}][m_name]" value='${std.m_name}' class="form-control @error('students[${index}][m_name]') is-invalid @enderror m_name" data-index="${index}">
                                                        <span class="invalid-feedback form-invalid fw-bold error" id="std-mname-error" role="alert">
                                                        </span>
                                                    @error('students[${index}][m_name]')
                                                        <span class="invalid-feedback form-invalid fw-bold error" role="alert">
                                                            {{ meaasge }}
                                                        </span>
                                                    @enderror
                                                </td>
                                                <td>
                                                    <input type="text" name="students[${index}][g_f_name]" value='${std.g_f_name}' class="form-control @error('students[${index}][g_f_name]') is-invalid @enderror g_f_name" data-index="${index}">
                                                        <span class="invalid-feedback form-invalid fw-bold error" id="std-gfname-error" role="alert">
                                                        </span>
                                                    @error('students[${index}][g_f_name]')
                                                        <span class="invalid-feedback form-invalid fw-bold error" role="alert">
                                                            {{ meaasge }}
                                                        </span>
                                                    @enderror
                                                </td>
                                                <td>
                                                    <input type="date" name="students[${index}][dob]" value='${std.dob}' class="form-control @error('students[${index}][dob]') is-invalid @enderror dob" data-index="${index}">
                                                        <span class="invalid-feedback form-invalid fw-bold error" id="std-dob-error" role="alert">
                                                        </span>
                                                    @error('students[${index}][dob]')
                                                        <span class="invalid-feedback form-invalid fw-bold error" role="alert">
                                                            {{ meaasge }}
                                                        </span>
                                                    @enderror
                                                </td>
                                                <td>
                                                    <input type="text" name="students[${index}][f_mobile]" value='${std.f_mobile}' class="form-control @error('students[${index}][f_mobile]') is-invalid @enderror contact1" data-index="${index}">
                                                        <span class="invalid-feedback form-invalid fw-bold error" id="std-contact1-error" role="alert">
                                                        </span>
                                                    @error('students[${index}][f_mobile]')
                                                        <span class="invalid-feedback form-invalid fw-bold error" role="alert">
                                                            {{ meaasge }}
                                                        </span>
                                                    @enderror
                                                </td>
                                                <td>
                                                    <input type="text" name="students[${index}][m_mobile]" value='${std.m_mobile ?? ''}' class="form-control @error('students[${index}][m_mobile]') is-invalid @enderror contact2" data-index="${index}">
                                                        <span class="invalid-feedback form-invalid fw-bold error" id="std-contact1-error" role="alert">
                                                        </span>
                                                    @error('students[${index}][contact2]')
                                                        <span class="invalid-feedback form-invalid fw-bold error" role="alert">
                                                            {{ meaasge }}
                                                        </span>
                                                    @enderror
                                                </td>
                                                <td>
                                                     <select name="students[${index}][age_proof]" id="age_proof_${index}" class="form-control @error('students[${index}][age_proof]')  'is-invalid' @enderror">
                                                        <option value="">Select Age Proof</option>
                                                        <option value="1" ${std.age_proof && std.age_proof == 1 ? 'selected' : ''}>Birth Certificate</option>
                                                        <option value="2" ${std.age_proof && std.age_proof == 2 ? 'selected' : ''}>Transfer Certificate</option>
                                                        <option value="3" ${std.age_proof && std.age_proof == 3 ? 'selected' : ''}>Affidavit</option>
                                                        <option value="4" ${std.age_proof && std.age_proof == 4 ? 'selected' : ''}>Aadhar Card</option>
                                                    </select>
                                                    <span class="invalid-feedback form-invalid fw-bold error" id="std-age-proof-error-${index}" role="alert"></span>
                                                    @error('students[${index}][age_proof]')
                                                        <span class="invalid-feedback form-invalid fw-bold error" role="alert">
                                                            {{ message }}
                                                        </span>
                                                    @enderror
                                                </td>

                                                </tr>`;

                                });
                                if (stdHtml === '') {
                                    stdHtml =
                                        '<tr><td colspan="10">No Student found</td></tr>';
                                }
                                $('#std-container table tbody').html(stdHtml);
                                updatePaginationControls(students);

                            },
                            complete: function() {
                                loader.hide();
                            },
                            error: function(xhr) {
                                console.error(xhr.responseText);

                            }
                        });
                    }
                }
                $(document).on('click', '#std-pagination .page-link', function(e) {
                    e.preventDefault();
                    var page = $(this).data('page');
                    stdDetails(page);
                });

                function updatePaginationControls(data) {
                    var paginationHtml = '';
                    if (data.last_page > 1) {
                        paginationHtml += '<ul class="pagination">';

                        if (data.current_page > 1) {
                            paginationHtml +=
                                `<li class="page-item"><a class="page-link" href="#" data-page="${data.current_page - 1}">Previous</a></li>`;
                        }

                        for (let i = 1; i <= data.last_page; i++) {
                            if (i == data.current_page) {
                                paginationHtml +=
                                    `<li class="page-item active"><span class="page-link">${i}</span></li>`;
                            } else {
                                paginationHtml +=
                                    `<li class="page-item"><a class="page-link" href="#" data-page="${i}">${i}</a></li>`;
                            }
                        }

                        if (data.current_page < data.last_page) {
                            paginationHtml +=
                                `<li class="page-item"><a class="page-link" href="#" data-page="${data.current_page + 1}">Next</a></li>`;
                        }

                        paginationHtml += '</ul>';
                    }
                    paginationContainer.html(paginationHtml);
                }

                stdDetails(page);
            });

        });
    </script>
@endsection
