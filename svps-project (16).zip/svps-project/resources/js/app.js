import './bootstrap';
import Swal from 'sweetalert2';
window.Swal = Swal;


// import './bootstrap';
// import Swal from 'sweetalert2';
// import 'sweetalert2/dist/sweetalert2.min.css';
// import { initializeDeleteButtons } from './delete-handler';

// // Make Swal available globally
// window.Swal = Swal;

// // Initialize delete buttons
// initializeDeleteButtons();