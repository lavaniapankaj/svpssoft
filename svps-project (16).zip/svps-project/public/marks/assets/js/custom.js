//set current session(marks)
var currentSession = $('#marks_current_session').val();
$('#current_session').val(currentSession);

// let loader = $('#loader');

function getStd() {
    let stdSelect = $('#std_id');
    $('#section_id').change(function() {
        let classId = $('#class_id').val();
        let sectionId = $('#section_id').val();
        let sessionId = $('#current_session').val();

        if (classId && sectionId && sessionId) {
            loader.show();

            $.ajax({
                url: siteUrl + '/std-name-father',
                type: 'GET',
                dataType: 'JSON',
                data: {
                    class_id: classId,
                    section_id: sectionId,
                    session_id: sessionId,
                },
                success: function(students) {
                    stdSelect.empty();
                    let options = '<option value="" selected>All Students</option>';
                    const allStudentSrnos = [];

                    if (students.length > 0) {
                        $.each(students, function(index, student) {
                            allStudentSrnos.push(student.srno);
                            options += '<option value="' + student.srno + '">' +
                                student.rollno + '. ' + student.student_name +
                                '/' +
                                student.f_name + '</option>';
                        });
                    } else {
                        // options += '<option value="">No students found</option>';
                        stdSelect.find('option[value=""]').text('No students found');
                    }

                    stdSelect.html(options);
                    stdSelect.find('option[value=""]').val(allStudentSrnos);

                },
                complete: function() {
                    loader.hide();
                },
                error: function(xhr) {
                    console.error(xhr.responseText);
                }
            });
        }
    });
}

function marksheetPrint() {
    let marksheetDiv = $('.marksheet-div');
    marksheetDiv.hide();
    $('#class-section-form').validate({
        rules: {
            exam: {
                required: true,
            },
            std_id: {
                required: true,
            },
            class: {
                required: true,
            },
            section: {
                required: true,
            },
        },
        messages: {
            exam: {
                required: "Please select a exam.",
            },
            std_id: {
                required: "Please select at least a student.",
            },
            class: {
                required: "Please select a class.",
            },
            section: {
                required: "Please select a section.",
            },
        },
    });

    $('#show-details').click(function() {
        if ($('#class-section-form').valid()) {
            let classId = $('#class_id').val();
            let sectionId = $('#section_id').val();
            let sessionId = $('#current_session').val();
            let examId = $('#exam_id').val();
            let stdId = $('#std_id').val();
            marksheetDiv.show();
            $.ajax({
                url: siteUrl + '/marks/marksheet-report',
                type: 'GET',
                dataType: 'JSON',
                data: {
                    class: classId,
                    section: sectionId,
                    session: sessionId,
                    exam: examId,
                    std_id: stdId,
                },
                success: function(response) {

                    if (response.data && response.data.student) {
                        let tableHtml = '';
                        $.each(response.data.student, function(key, value) {
                            tableHtml += `
                        <table class="table">
                            <thead>
                                <tr>
                                    <th colspan="2" class="border-start-0 border-end-0 border-bottom-0"><img src="${value.logo}" alt=""></th>
                                    <th colspan="4" class="border-start-0 border-end-0 border-bottom-0 fs-3 text-break">${value.school} <span class="fs-5 text-center">(English Medium) Vivekanand Chowk, Chirawa</span></th>
                                </tr>

                                <tr>
                                    <th colspan="6" class="text-center fs-5">Session: ${value.session || ''}</th>
                                </tr>
                                <tr>
                                    <th colspan="3" class="border-start-0 border-end-0 border-bottom-0">Name: ${value.name || ''}</th>
                                    <th colspan="3" class="border-start-0 border-end-0 border-bottom-0">SRNO: ${value.srno || ''}</th>
                                </tr>
                                <tr>
                                    <th colspan="3" class="border-start-0 border-end-0 border-bottom-0">Father's Name: ${value.father_name || ''}</th>
                                    <th colspan="3" class="border-start-0 border-end-0 border-bottom-0">DOB: ${value.dob || ''}</th>
                                </tr>
                                <tr>
                                    <th colspan="3" class="border-start-0 border-end-0 border-bottom-0">Class: ${value.class_name || ''}</th>
                                    <th colspan="3" class="border-start-0 border-end-0 border-bottom-0">Section: ${value.section_name || ''}</th>
                                </tr>
                                <tr>
                                    <th colspan="3" class="border-start-0 border-end-0 border-bottom-0">Roll No.: ${value.rollno || ''}</th>
                                    <th colspan="3" class="border-start-0 border-end-0 border-bottom-0">Exam: ${value.exam_name || ''}</th>
                                </tr>
                                <tr>
                                    <th colspan="6" class="text-center">Mark Sheet</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <th colspan="2">Subject</th>
                                    <th>Written</th>
                                    <th>Oral</th>
                                    <th>Practical</th>
                                    <th>Total</th>
                                </tr>
                            `;

                            if (value.subjects) {
                                $.each(value.subjects, function(subjectKey,
                                    subject) {
                                    if (subject.by_m_g == 1) {
                                        tableHtml += `
                                                <tr>
                                                    <td colspan="2">${subject.name || '--'}</td>
                                                    <td>${subject.written || '--'}</td>
                                                    <td>${subject.oral || '--'}</td>
                                                    <td>${subject.practical || '--'}</td>
                                                    <td>${subject.total || '--'}</td>
                                                </tr>
                                            `;
                                    }
                                });
                            }
                            // console.log(tableHtml);


                            tableHtml += `
                                    <tr>
                                        <th colspan="5">Grand Total</th>
                                        <td>${value.grand_total_marks || ''}</td>
                                    </tr>
                                     <tr>
                                        <th colspan="2">Subject</th>
                                        <th>Grade</th>
                                        <th>Grade</th>
                                        <th>Grade</th>
                                        <th>Grade</th>
                                    </tr>
                                    `;
                            if (value.subjects) {
                                $.each(value.subjects, function(subjectKey,
                                    subject) {
                                    console.log(subject);

                                    if (subject.by_m_g == 2) {

                                        tableHtml += `
                                            <tr>
                                                <td colspan="2">${subject.name || '--'}</td>
                                                <td>${subject.written || '--'}</td>
                                                <td>${subject.oral || '--'}</td>
                                                <td>${subject.practical || '--'}</td>
                                                <td>${subject.total || '--'}</td>
                                            </tr>
                                        `;
                                    }
                                });
                            }
                            tableHtml += `<tr>
                                        <th class="border-start-0 border-end-0 border-bottom-0" colspan="3">Class Teacher</th>
                                        <th class="border-start-0 border-end-0 border-bottom-0" colspan="2">Checked By</th>
                                        <th class="border-start-0 border-end-0 border-bottom-0"><span><img src="${siteUrl + '/public/marks/images/'+value.principle_sign}" alt=""></span>Principal</th>
                                    </tr>
                                </tbody>
                            </table>
                        `;
                        });

                        $('.marksheet').html(tableHtml);
                    } else {
                        $('.marksheet').html(
                            '<p>No data available for the selected criteria.</p>'
                        );
                    }
                },
                complete: function() {
                    $('#loader').hide();
                },
                error: function(xhr) {
                    console.log('Error:', xhr);
                    console.error(xhr.responseText);

                }
            });
        }
    });



    $('#print-marksheet').click(function() {
        // Create an iframe for printing
        const iframe = $('<iframe></iframe>').css({
            display: 'none'
        });
        $('body').append(iframe);

        const iframeDoc = iframe[0].contentWindow.document;
        iframeDoc.open();
        iframeDoc.write('<html><head><title>Print Marksheet</title>');

        // Include existing CSS styles
        $('link[rel="stylesheet"]').each(function() {
            iframeDoc.write(
                `<link rel="stylesheet" type="text/css" href="${$(this).attr('href')}">`
            );
        });

        // Add additional styles for printing
        iframeDoc.write(`
            <style>
                @media print {
                    .page-break {
                        page-break-before: always;
                    }
                }
            </style>
        `);

        iframeDoc.write('</head><body>');

        // Append each table separately
        $('.marksheet .table').each(function(index) {
            // Add a page break before each table except the first
            if (index > 0) {
                iframeDoc.write('<div class="page-break"></div>');
            }
            iframeDoc.write($(this)[0].outerHTML);
        });

        iframeDoc.write('</body></html>');
        iframeDoc.close();

        // Print the iframe content
        iframe[0].contentWindow.focus();
        iframe[0].contentWindow.print();

        // Remove the iframe after printing
        setTimeout(() => {
            iframe.remove();
        }, 1000);
    });
}