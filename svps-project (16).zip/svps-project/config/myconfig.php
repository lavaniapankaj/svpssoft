<?php

return [

    'myloader' => env('APP_URL') . env('MY_LOADER'),
    'mylogo' => env('APP_URL') . env('MY_LOGO'),
    'mysignature' => env('APP_URL') . env('MY_SIGNATURE'),

    'admin' => env('APP_URL') . env('MY_ADMIN'),
    'fee' => env('APP_URL') . env('MY_FEE'),
    'marks' => env('APP_URL') . env('MY_MARKS'),
    'student' => env('APP_URL') . env('MY_STD'),
    'inventory' => env('APP_URL') . env('MY_INVENTORY'),

    'blank' => env('APP_URL') . env('MY_BLANK_PHOTO'),


];
