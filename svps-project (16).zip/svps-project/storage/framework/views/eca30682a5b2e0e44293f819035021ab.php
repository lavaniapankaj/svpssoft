<?php $__env->startSection('sub-content'); ?>
    <div class="container">
        
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card">
                        <div class="card-header">
                            <?php echo e(isset($exam) && isset($exam->id) ? 'Edit Exam' : 'Add New Exam'); ?>

                           <a href="<?php echo e(route('admin.exam-master.index')); ?>" class="btn btn-warning btn-sm"
                                    style="float: right;">Back</a>

                        </div>

                        <div class="card-body">
                            <form action="<?php echo e(route('admin.exam-master.store')); ?>" method="POST"
                                enctype="multipart/form-data" id="basic-form">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="id" id="id"
                                    value="<?php echo e(isset($exam) ? $exam->id : ''); ?>">
                                <div class="row">
                                    <div class="form-group col-md-12">
                                        <label for="exam" class="mt-2"> Exam <span
                                                class="text-danger">*</span></label>
                                        <input type="text" name="exam"
                                            class="form-control <?php $__errorArgs = ['exam'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            placeholder="Exam"
                                            value="<?php echo e(old('exam', isset($exam) ? $exam->exam : '')); ?>" id="exam" required>
                                        <?php $__errorArgs = ['exam'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback form-invalid fw-bold" role="alert">
                                                <?php echo e($message); ?>

                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="form-group form-check col-md-6">
                                        <div class="form-check">
                                            <input class="form-check-input <?php $__errorArgs = ['show_y_n'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="0" type="radio" name="show_y_n"
                                                id="no"
                                                <?php echo e(old('show_y_n', isset($exam) && $exam->show_y_n == 0 ? 'checked=' . '"' . 'checked' . '"' : '')); ?>>
                                            <label class="form-check-label" for="no">
                                                No
                                            </label>
                                        </div>
                                    </div>
                                    <div class="form-group form-check col-md-6">
                                        <div class="form-check">
                                            <input class="form-check-input <?php $__errorArgs = ['show_y_n'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="1" type="radio" name="show_y_n"
                                                id="yes"
                                                <?php echo e(old('show_y_n', isset($exam) && $exam->show_y_n == 1 ? 'checked=' . '"' . 'checked' . '"' : '')); ?>>
                                            <label class="form-check-label" for="yes">
                                                Yes
                                            </label>
                                        </div>
                                    </div>
                                    <?php $__errorArgs = ['show_y_n'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback form-invalid fw-bold" role="alert">
                                            <?php echo e($message); ?>

                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="mt-3">
                                    <input class="btn btn-primary" type="submit"
                                        value="<?php echo e(isset($exam) && isset($exam->id) ? 'Update' : 'Save'); ?>">
                                </div>
                            </form>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\svps-project\resources\views/admin/exam/create.blade.php ENDPATH**/ ?>