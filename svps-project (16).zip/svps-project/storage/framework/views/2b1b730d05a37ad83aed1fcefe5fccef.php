<?php $__env->startSection('sub-content'); ?>
    <div class="container">

        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header"><?php echo e(__('RTE Student')); ?>

                        <a href="<?php echo e(route('admin.reports')); ?>" class="btn btn-warning btn-sm" style="float: right;">Back</a>
                    </div>

                    <div class="card-body">
                        <form action="" method="get" id="class-form">
                            <div class="row mt-2">
                                <div class="form-group col-md-6">
                                    <label for="class_id" class="mt-2">Class <span class="text-danger">*</span></label>
                                    <input type="hidden" name="current_session" value='' id="current_session">
                                    <input type="hidden" id="initialClassId" name="initialClassId"
                                        value="<?php echo e(old('initialClassId', request()->get('class_id') !== null ? request()->get('class_id') : '')); ?>">
                                    <select name="class_id" id="class_id"
                                        class="form-control mx-1 <?php $__errorArgs = ['class_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                        <option value="">All Class</option>
                                    </select>
                                    <?php $__errorArgs = ['class_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback form-invalid fw-bold" role="alert">
                                            <?php echo e($message); ?>

                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    <img src="<?php echo e(config('myconfig.myloader')); ?>" alt="Loading..." class="loader"
                                        id="loader" style="display:none; width:10%;">
                                </div>

                            </div>

                            <div class="mt-3">
                                <button class="btn btn-primary" type="button" id="show-report">Show Report</button>

                            </div>
                        </form>

                        <div class="super-div">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>S.No.</th>
                                        <th>SRNO</th>
                                        <th>Name</th>
                                        <th>Gurdian Name</th>
                                        <th>Category(WS/DG)</th>
                                        <th>Sign. of Certifier </th>
                                        <th>Remark</th>
                                    </tr>
                                </thead>
                                <tbody id="report-body">
                                </tbody>
                            </table>
                            <div id="std-pagination"></div>
                            <div class="export-div">
                                <button type="button" class="btn btn-info" id="export-button">Export</button>
                            </div>
                        </div>


                    </div>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('admin-scripts'); ?>
    <script>
        $(document).ready(function() {
            getClassDropDownWithAll();
            let superDiv = $('.super-div');
            superDiv.hide();
            function getReport(page = 1) {

                superDiv.show();
                let classId = $('#class_id').val();
                console.log(classId);
                let sessionId = $('#current_session').val();
                if (classId) {
                    $.ajax({
                        url: '<?php echo e(route('admin.reports.rteStudentReport')); ?>',
                        type: 'GET',
                        dataType: 'JSON',
                        data: {
                            class: classId,
                            session: sessionId,
                            page: page,

                        },
                        success: function(response) {
                            console.log(response);

                            let tableHtml = '';
                            updatePaginationControls(response.pagination);
                            if (response.data.length > 0) {
                                let displayIndex = (response.pagination.current_page - 1) * response.pagination
                                .per_page + 1;
                                $.each(response.data, function(index, std) {
                                    // Create row for boys
                                    tableHtml += `
                                            <tr>
                                                 <td>${displayIndex}</td>
                                                 <td>${std.srno}</td>
                                                 <td>${std.name}</td>
                                                 <td>${std.f_name}</td>
                                                 <td>-</td>
                                                 <td>-</td>
                                                 <td>-</td>
                                            </tr>`;

                                });
                            }else {
                                tableHtml += `
                                            <tr>
                                                 <td colspan="7" class='text-center'>No Students Found</td>
                                            </tr>`;
                            }
                            $('#report-body').html(tableHtml);
                        },
                        complete: function() {

                            loader.hide();
                        },
                        error: function(data, xhr) {
                            var message = data.responseJSON.message;
                            $('.cdate-error').hide().html('');
                            if (message.date) {
                                $('.cdate-error').show().html(message.date);
                            }
                            console.log(xhr);

                        },
                    });
                }
            }
            $('#show-report').click(() => {
                getReport();
            });

            // Pagination controls
            $(document).on('click', '#std-pagination .page-link', function(e) {
                e.preventDefault();
                let page = $(this).data('page');
                getReport(page);
            });
            $('#class_id').change(() => {
                superDiv.hide();
            });
            $('#export-button').on('click', function() {
                let session = $('#current_session').val();
                let classId = $('#class_id').val();
                
                const exportUrl = "<?php echo e(route('admin.reports.rteStudentReport.excel')); ?>?class=" + classId + "&session=" + session;
                window.location.href = exportUrl;
            });


        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\svps-project\resources\views/admin/reports/rte_std_report.blade.php ENDPATH**/ ?>