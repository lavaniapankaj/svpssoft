<?php $__env->startSection('sub-content'); ?>
    <div class="container">
        <?php if(Session::has('success')): ?>
            <?php $__env->startSection('scripts'); ?>
                <script>
                    swal("Good job!", "<?php echo e(Session::get('success')); ?>", "success").then(() => {
                                    location.reload();
                                });
                </script>
            <?php $__env->stopSection(); ?>
        <?php endif; ?>

        <?php if(Session::has('error')): ?>
            <?php $__env->startSection('scripts'); ?>
                <script>
                    swal("Oops...", "<?php echo e(Session::get('error')); ?>", "error");
                </script>
            <?php $__env->stopSection(); ?>
        <?php endif; ?>
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header"><?php echo e(__('Attendance-schedule')); ?>

                        <div class="col-lg-12 col-md-12">
                            <div class="right-item d-flex justify-content-end mt-4">
                                <form action="<?php echo e(route('admin.attendance_schedule.index')); ?>" method="get" class="d-flex">
                                    <input type="date" name="a_date" id="a_date" class="form-control"
                                        value="<?php echo e(old('a_date', request()->get('a_date') !== null ? request()->get('a_date') : '')); ?>"
                                        required>
                                    <input type="hidden" name="current_session" value='' id="current_session">
                                    <img src="<?php echo e(config('myconfig.myloader')); ?>" alt="Loading..." class="loader"
                                        id="loader" style="display:none; width:10%;">
                                    <button type="submit" class="btn btn-sm btn-info mx-2">Search</button>
                                </form>
                                <a href="<?php echo e(route('admin.attendance_schedule.index')); ?>" class="btn btn-warning">Reset</a>
                            </div>
                        </div>
                    </div>

                    <div class="card-body">

                        <a href="<?php echo e(route('admin.attendance_schedule.create')); ?>" class="btn btn-info">Create Attendance
                            Schedule</a>
                        <a href="<?php echo e(route('admin.attendance_schedule.editDateView')); ?>" class="btn btn-info">Edit Attendance
                            Schedule</a>
                        
                        <div class="table my-2 table-responsive">
                            <input type="hidden" name="current_session" value='' id="current_session">
                            <table id="example" class="table table-striped table-bordered">
                                <thead>
                                    <tr>
                                        <th>S No.</th>
                                        <th>Date</th>
                                        <th>Reason</th>
                                    </tr>
                                </thead>
                                <?php $i = ($data->currentpage()-1)* $data->perpage() + 1;?>

                                <?php if(count($data) > 0): ?>
                                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr data-entry-id="<?php echo e($value->id); ?>">
                                            <td><?php echo e($i++ ?? ''); ?></td>
                                            <td><?php echo e($value->a_date ?? ''); ?></td>
                                            <td><?php echo e($value->reason ?? '-'); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="5">No Data Found</td>
                                    </tr>
                                <?php endif; ?>
                            </table>

                            <?php if(request()->get('a_date') || request()->get('session_id')): ?>
                                <?php echo e($data->appends(['a_date' => request()->get('a_date'), 'session' => request()->get('session_id')])->links()); ?>

                            <?php else: ?>
                                <?php echo e($data->links()); ?>

                            <?php endif; ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\svps-project\resources\views/admin/attendance_schedule/index.blade.php ENDPATH**/ ?>