<?php $__env->startSection('sub-content'); ?>
    <div class="container">
        <?php if(Session::has('success')): ?>
            <?php $__env->startSection('scripts'); ?>
                <script>
                    swal("Good job!", "<?php echo e(Session::get('success')); ?>", "success").then(() => {
                        location.reload();
                    });
                </script>
            <?php $__env->stopSection(); ?>
        <?php endif; ?>

        <?php if(Session::has('error')): ?>
            <?php $__env->startSection('scripts'); ?>
                <script>
                    swal("Oops...", "<?php echo e(Session::get('error')); ?>", "error");
                </script>
            <?php $__env->stopSection(); ?>
        <?php endif; ?>
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">
                        <?php echo e('Edit/Remove Relative Students'); ?>

                        <a href="<?php echo e(route('admin.editSection.index')); ?>" class="btn btn-warning btn-sm"
                            style="float: right;">Back</a>

                    </div>
                    <div class="card-body">
                        <form method="get" action="">
                            <div class="row">
                                <div class="form-group col-md-4">
                                    <label for="class_id" class="mt-2">Class <span class="text-danger">*</span></label>
                                    <input type="hidden" name="current_session" value='' id="current_session">
                                    <input type="hidden" id="initialClassId" name="initialClassId"
                                        value="<?php echo e(old('initialClassId', request()->get('class_id') !== null ? request()->get('class_id') : '')); ?>">
                                    <select name="class_id" id="class_id"
                                        class="form-control mx-1 <?php $__errorArgs = ['class_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                        <option value="">Select Class</option>
                                    </select>
                                    <?php $__errorArgs = ['class_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback form-invalid fw-bold" role="alert">
                                            <?php echo e($message); ?>

                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="form-group col-md-4">
                                    <label for="section_id" class="mt-2">Section<span class="text-danger">*</span></label>
                                    <input type="hidden" id="initialSectionId" name="initialSectionId"
                                        value="<?php echo e(old('initialSectionId', request()->get('section_id') !== null ? request()->get('section_id') : '')); ?>">
                                    <select name="section_id" id="section_id"
                                        class="form-control mx-1 <?php $__errorArgs = ['section_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                        <option value="">Select Section</option>
                                    </select>
                                    <?php $__errorArgs = ['section_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback form-invalid fw-bold" role="alert">
                                            <?php echo e($message); ?>

                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="form-group col-md-4">
                                    <label for="std_id" class="mt-2">Student<span class="text-danger">*</span></label>
                                    <input type="hidden" id="initialStdId" name="initialStdId"
                                        value="<?php echo e(old('initialStdId', request()->get('std_id') !== null ? request()->get('std_id') : '')); ?>">
                                    <select name="std_id" id="std_id"
                                        class="form-control mx-1 <?php $__errorArgs = ['std_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                        <option value="">Select Student</option>
                                    </select>
                                    <?php $__errorArgs = ['std_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback form-invalid fw-bold" role="alert">
                                            <?php echo e($message); ?>

                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <img src="<?php echo e(config('myconfig.myloader')); ?>" alt="Loading..." class="loader" id="loader"
                                    style="display:none; width:10%;">
                            </div>
                            <div class="row mt-4">
                                <div class="table" id="std-container" style="display: none;">
                                    <table id="example" class="table table-striped table-bordered">
                                        <thead>
                                            <tr>
                                                <th>SRNO</th>
                                                <th>Name</th>
                                                <th>Father's Name</th>
                                                <th>Mother's Name</th>
                                                <th>Class</th>
                                                <th>Section</th>
                                                <th class="text-center">Action</th>
                                            </tr>
                                        </thead>
                                        <tbody class="">
                                        </tbody>
                                    </table>

                                </div>
                            </div>
                        </form>
                        <form action="<?php echo e(route('admin.editSection.editRemoveRelativeStd.store')); ?>" method="POST" id="add-relative-form">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="form-group col-md-4 ">
                                    <label for="second_class_id" class="mt-2">Class <span
                                            class="text-danger">*</span></label>
                                    <select name="second_class_id" id="second_class_id"
                                        class="form-control mx-1 <?php $__errorArgs = ['second_class_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                        <option value="">Select Class</option>
                                    </select>
                                    <?php $__errorArgs = ['second_class_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback form-invalid fw-bold" role="alert">
                                            <?php echo e($message); ?>

                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="form-group col-md-4">
                                    <label for="section_id" class="mt-2">Section<span class="text-danger">*</span></label>
                                    <select name="second_section_id" id="second_section_id"
                                        class="form-control mx-1 <?php $__errorArgs = ['second_section_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                        <option value="">Select Section</option>
                                    </select>
                                    <?php $__errorArgs = ['second_section_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback form-invalid fw-bold" role="alert">
                                            <?php echo e($message); ?>

                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="form-group col-md-4">
                                    <label for="second_std_id" class="mt-2">Student<span
                                            class="text-danger">*</span></label>
                                    <select name="second_std_id" id="second_std_id"
                                        class="form-control mx-1 <?php $__errorArgs = ['second_std_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                        <option value="">Select Student</option>
                                    </select>
                                    <span class="invalid-feedback form-invalid fw-bold second-std-select-error"
                                        id="second-std-select-error" role="alert"></span>
                                    <?php $__errorArgs = ['second_std_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback form-invalid fw-bold second-std-select-error"
                                            id="second-std-select-error" role="alert">
                                            <?php echo e($message); ?>

                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    
                                    <input type="hidden" id="hidden_std_id" name = "std_id" value="">

                                </div>
                                <img src="<?php echo e(config('myconfig.myloader')); ?>" alt="Loading..." class="loader"
                                    id="loader" style="display:none; width:10%;">
                            </div>
                            <div class="mt-3">
                                <button type="submit" id="relative-std-btn" class="btn btn-primary">Add as Relative
                                    Student</button>
                            </div>

                        </form>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('admin-scripts'); ?>
    <script>
        var initialClassId =
            '<?php echo e(old('initialClassId', request()->get('class_id') !== null ? request()->get('class_id') : '')); ?>';
        var initialSectionId =
            '<?php echo e(old('initialSectionId', request()->get('section_id') !== null ? request()->get('section_id') : '')); ?>';
        var initialStdId = '<?php echo e(old('initialStdId', request()->get('std_id') !== null ? request()->get('std_id') : '')); ?>';

        var initialSecondClassId = '<?php echo e(old('second_class_id' ?? '')); ?>';
        var initialSecondSectionId = '<?php echo e(old('second_section_id' ?? '')); ?>';
        var initialSecondStdId = '<?php echo e(old('second_std_id' ?? '')); ?>';

        var secondClassSelect = $('#second_class_id');
        var secondSectionSelect = $('#second_section_id');
        getClassSection(initialClassId, initialSectionId);
        getClassSection(initialSecondClassId, initialSecondSectionId, secondClassSelect, secondSectionSelect);

        $(document).ready(function() {

            const classFirst = $('#class_id');
            const classSecond = $('#second_class_id');
            const sectionFirst = $('#section_id');
            const sectionSecond = $('#second_section_id');
            const sessionSelect = $('#current_session').val();
            const stdSelect = $('#std_id');
            const stdSecondSelect = $('#second_std_id');

            function populateDropdowns(data, dropdown) {
                dropdown.empty();
                dropdown.append('<option value="">Select Student</option>');
                $.each(data, function(id, value) {
                    dropdown.append('<option value="' + value.srno + '">' +
                        ++id + '. ' + value.student_name + '/SH. ' + value.f_name +
                        '</option>');
                });
            }


            function fetchStdNameFather(classId, sectionId, stdDropdown) {
                if (classId && sectionId) {
                    $.ajax({
                        url: '<?php echo e(route('stdNameFather.get')); ?>',
                        type: 'GET',
                        dataType: 'JSON',
                        data: {
                            class_id: classId,
                            section_id: sectionId,
                            session_id: sessionSelect,
                        },
                        success: function(data) {
                            populateDropdowns(data, stdDropdown);
                            stdWithRelative(data);
                        },
                        error: function(xhr) {
                            console.error('Error fetching student details:', xhr);
                        }
                    });

                }
            }

            function stdWithRelative(data) {

                stdSelect.change(function(e) {
                    $('#hidden_std_id').val($(this).val());
                    const selectedStdId = $(this).val();

                    var rowsHtml = '';
                    $.ajax({
                        url: '<?php echo e(route('admin.getStdWithRelativeStd')); ?>',
                        type: 'GET',
                        dataType: 'JSON',
                        data: {
                            srno: selectedStdId
                        },
                        success: function(data) {
                            $.each(data.data, function(id, value) {
                                console.log(value);

                                if (value) {

                                    rowsHtml += `
                                                    <tr>
                                                        <td>${value.srno}</td>
                                                        <td>${value.student_name}</td>
                                                        <td>SH. ${value.f_name}</td>
                                                        <td>${value.m_name}</td>
                                                        <td>${value.class_name}</td>
                                                        <td>${value.section_name}</td>
                                                        <td>

                                                                ${value.srno === selectedStdId ?
                                                                    `<a href="#" class="btn btn-sm btn-icon p-1 edit-section-editBtn" disabled>
                                                                    <i class="mdi mdi-delete edit-section-editBtn" data-bs-toggle="tooltip" data-bs-offset="0,4" data-bs-placement="top" title="Delete" disabled></i>
                                                                    </a>` :
                                                                    `<form action="${siteUrl}/admin/edit-section/edit-relative-std/${value.srno}/remove" method="POST" style="display:inline;">
                                                                                <?php echo csrf_field(); ?>
                                                                                <button type="submit" class="btn btn-sm btn-icon p-1 delete-form-btn"
                                                                                    data-bs-toggle="tooltip" data-bs-offset="0,4"
                                                                                    data-bs-placement="top" data-bs-html="true" title="Delete">
                                                                                    <i class="mdi mdi-delete"></i>
                                                                                </button>
                                                                            </form>`

                                                                }
                                                        </td>
                                                    </tr>`;
                                    $('#std-container table tbody').html(rowsHtml);
                                    $('#std-container').show();
                                } else {
                                    $('#std-container').hide();
                                }
                            });
                        },
                        error: function(xhr) {

                            console.error('Error fetching student details:', xhr);
                        }
                    });
                    if (selectedStdId === stdSecondSelect.val()) {
                        e.preventDefault();
                        console.log('error');
                        $('#second-std-select-error').show().text(
                            "Please Select different student for relation");
                    } else {
                        $('#second-std-select-error').hide();
                }


                });
            }

            sectionFirst.change(function() {
                fetchStdNameFather(classFirst.val(), sectionFirst.val(), stdSelect);
            });
            sectionSecond.change(function() {
                fetchStdNameFather(classSecond.val(), sectionSecond.val(), stdSecondSelect);
            });
            stdSecondSelect.change(function(e){
                if ($(this).val() === stdSelect.val()) {
                        e.preventDefault();
                        console.log('error');
                        $('#second-std-select-error').show().text(
                            "Please Select different student for relation");
                    } else {
                        $('#second-std-select-error').hide();
                }
            });
            $('#relative-std-btn').on('click', function(event) {
                if ($('#second-std-select-error').is(':visible')) {
                    event.preventDefault();
                } else {
                    location.reload(true);
                }
            });
            $('#add-relative-form').validate();

        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\svps-project\resources\views/admin/editSections/edit_remove_relative_students.blade.php ENDPATH**/ ?>