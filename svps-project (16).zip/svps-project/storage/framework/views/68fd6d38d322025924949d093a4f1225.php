<?php $__env->startSection('sub-content'); ?>
    <div class="container">
        <?php if(Session::has('success')): ?>
            <?php $__env->startSection('scripts'); ?>
                <script>
                    swal("Good job!", "<?php echo e(Session::get('success')); ?>", "success").then(() => {
                        $('#std-form').hide();
                        location.reload();
                    });
                </script>
            <?php $__env->stopSection(); ?>
        <?php endif; ?>

        <?php if(Session::has('error')): ?>
            <?php $__env->startSection('scripts'); ?>
                <script>
                    swal("Oops...", "<?php echo e(Session::get('error')); ?>", "error");
                </script>
            <?php $__env->stopSection(); ?>
        <?php endif; ?>
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">
                        <?php echo e('Edit Fee Entry'); ?>

                        <a href="<?php echo e(route('admin.editSection.index')); ?>" class="btn btn-warning btn-sm"
                            style="float: right;">Back</a>

                    </div>
                    <div class="card-body">
                        <form action="" method="get" id="slip-form">
                            <div class="row">
                                <div class="form-group col-md-6">
                                    <label for="fee-type" class="mt-2">Fee Type<span class="text-danger">*</span></label>
                                    <select name="fee-type" id="fee-type" class="form-control">
                                        <option value="1">Academic</option>
                                        <option value="2">Transport</option>
                                    </select>

                                </div>

                            </div>
                            <div class="row">
                                <div class="form-group col-md-6">
                                    <label for="computer-slip" class="mt-2">Academic Fee Slip Number (Computer) <span
                                            class="text-danger">*</span></label>
                                    <input type="text" name="computer_slip" id="computer-slip" class="form-control">
                                    <span class="invalid-feedback form-invalid fw-bold computer-slip-error"
                                        role="alert"></span>
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="school-slip" class="mt-2">Academic Fee Slip Number (School) <span
                                            class="text-danger">*</span></label>
                                    <input type="text" name="school_slip" id="school-slip" class="form-control">
                                    <span class="invalid-feedback form-invalid fw-bold school-slip-error"
                                        role="alert"></span>
                                </div>
                            </div>
                            <div class="mt-3">
                                <button type="button" id="show-details" class="btn btn-primary">
                                    Show Details</button>
                                <span class="invalid-feedback form-invalid fw-bold show-details-error"
                                    role="alert"></span>
                            </div>
                        </form>

                        <form id="class-section-form" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="form-group col-md-6">
                                    <label for="class_id" class="mt-2">Class <span class="text-danger">*</span></label>
                                    <input type="hidden" id="initialClassId"
                                        value="<?php echo e(old('initialClassId', request()->get('class_id') !== null ? request()->get('class_id') : '')); ?>">
                                    <select name="class" id="class_id" class="form-control " required>
                                        <option value="">Select Class</option>
                                    </select>
                                    <span class="invalid-feedback form-invalid fw-bold" id="class-error"
                                        role="alert"></span>
                                    <img src="<?php echo e(config('myconfig.myloader')); ?>" alt="Loading..." class="loader"
                                        id="loader" style="display:none; width:10%;">
                                </div>


                                <div class="form-group col-md-6">
                                    <label for="section_id" class="mt-2">Section <span
                                            class="text-danger">*</span></label>
                                    <input type="hidden" id="initialSectionId"
                                        value="<?php echo e(old('initialSectionId', request()->get('section_id') !== null ? request()->get('section_id') : '')); ?>">
                                    <select name="section" id="section_id" class="form-control  " required>
                                        <option value="">Select Section</option>
                                    </select>
                                    <span class="invalid-feedback form-invalid fw-bold" id="section-error"
                                        role="alert"></span>
                                </div>
                            </div>
                            <div class="row">
                                <div class="form-group col-md-6">
                                    <input type="hidden" name="current_session" value='' id="current_session">
                                    <label for="std_id" class="mt-2">Student <span class="text-danger">*</span></label>
                                    <select name="std_id" id="std_id" class="form-control " required>
                                        <option value="">Select Students</option>
                                    </select>
                                    <span class="invalid-feedback form-invalid fw-bold" id="std-error"
                                        role="alert"></span>
                                </div>


                                <div class="form-group col-md-6">
                                    <label for="fee_date" class="mt-2">Enter Date <span
                                            class="text-danger">*</span></label>
                                    <input type="date" name="fee_date" id="fee_date" class="form-control "
                                        value="<?php echo e(old('fee_date)')); ?>" required>
                                    <span class="invalid-feedback form-invalid fw-bold" id="fee-date-error"
                                        role="alert"></span>
                                </div>
                            </div>
                            <div class="row">
                                <div class="form-group col-md-6">
                                    <label for="total_amount" class="mt-2">Enter Total Amount <span
                                            class="text-danger">*</span></label>
                                    <input type="text" name="total_amount" id="total_amount" class="form-control "
                                        value="<?php echo e(old('total_amount')); ?>" required>
                                    
                                </div>


                                <div class="form-group col-md-6">
                                    <label for="ref_slip" class="mt-2">Enter Ref. Slip No. <span
                                            class="text-danger">*</span></label>
                                    <input type="text" name="ref_slip" id="ref_slip" class="form-control "
                                        value="<?php echo e(old('ref_slip')); ?>" required>
                                    <span class="invalid-feedback form-invalid fw-bold" id="ref-slip-error"
                                        role="alert"></span>
                                </div>
                            </div>

                            <div class="mx-2 my-2 p-3 row bg-warning bg-opacity-10 border border-warning rounded">
                                <div class="row">

                                    <div class="form-group col-md-4 admission-div">
                                        <label for="admission_fee" class="mt-2">Admission Fee</label>
                                        <input type="text" name="admission_fee" id="admission_fee"
                                            class="form-control " value="<?php echo e(old('admission_fee')); ?>">
                                        <span class="invalid-feedback form-invalid fw-bold" id="admission-fee-error"
                                            role="alert"></span>
                                    </div>
                                    <div class="form-group col-md-4">
                                        <label for="first_inst_fee" class="mt-2">Ist Installment</label>
                                        <input type="text" name="first_inst_fee" id="first_inst_fee"
                                            class="form-control " value="<?php echo e(old('first_inst_fee')); ?>">
                                        <span class="invalid-feedback form-invalid fw-bold" id="first-inst-fee-error"
                                            role="alert"></span>
                                    </div>
                                    <div class="form-group col-md-4">
                                        <label for="second_inst_fee" class="mt-2">IInd Installment</label>
                                        <input type="text" name="second_inst_fee" id="second_inst_fee"
                                            class="form-control " value="<?php echo e(old('second_inst_fee')); ?>">
                                        <span class="invalid-feedback form-invalid fw-bold" id="second-inst-fee-error"
                                            role="alert"></span>
                                    </div>
                                </div>
                                <div class="row">

                                    <div class="form-group col-md-6">
                                        <input type="hidden" name="session" id="session"
                                            value="<?php echo e(old('session')); ?>">
                                        <input type="hidden" name="cSlip" id="cSlip"
                                            value="<?php echo e(old('cSlip')); ?>">
                                        <input type="hidden" name="transport" id="transport"
                                            value="<?php echo e(old('transport')); ?>">
                                        <label for="complete_fee" class="mt-2">Complete Fee</label>
                                        <input type="text" name="complete_fee" id="complete_fee"
                                            class="form-control " value="<?php echo e(old('complete_fee')); ?>">
                                        <span class="invalid-feedback form-invalid fw-bold" id="complete-fee-error"
                                            role="alert"></span>
                                    </div>
                                    
                                </div>
                            </div>

                            <div class="mt-3">
                                <button type="button" id="submit-fee" class="btn btn-primary">
                                    Submit</button>
                                <span class="invalid-feedback form-invalid fw-bold" id="total-amount-error"
                                    role="alert"></span><span class="invalid-feedback form-invalid fw-bold"
                                    id="not-applicable-error" role="alert"></span>
                            </div>

                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('admin-scripts'); ?>
    <script>
        $(document).ready(function() {
            let initialClassId = $('#class_id').val();
            let initialSectionId = $('#section_id').val();
            getClassSection(initialClassId);
            let classSelected = $('#class_id');
            let sectionSelected = $('#section_id');
            $('#std-form').hide();
            $('#class-section-form').hide();
            // getStdDropdown();

            function fetchSections(classId, selectedSectionId) {
                if (classId) {
                    $.ajax({
                        url: siteUrl + '/sections',
                        type: 'GET',
                        dataType: 'JSON',
                        data: {
                            class_id: classId
                        },
                        success: function(data) {
                            sectionSelected.empty();
                            sectionSelected.append('<option value="">Select Section</option>');
                            $.each(data.data, function(id, name) {
                                sectionSelected.append('<option value="' + id + '">' + name +
                                    '</option>');
                            });

                            // Set the selected section after populating options
                            if (selectedSectionId) {
                                sectionSelected.val(selectedSectionId);
                            } else if (initialSectionId) {
                                sectionSelected.val(initialSectionId);
                            }
                        },
                        error: function(data) {
                            $.each(data.message, function(error) {
                                console.error('Error fetching sections:', error);
                            });
                        }
                    });
                } else {
                    sectionSelected.empty();
                    sectionSelected.append('<option value="">Select Section</option>');
                }
            }

            function getStdDropdown(classId, sectionId, selectedStudentId) {
                let sessionId = $('#current_session').val();
                let stdSelect = $('#std_id');

                if (classId && sectionId && sessionId) {
                    loader.show();
                    $.ajax({
                        url: siteUrl + '/std-name-father',
                        type: 'GET',
                        dataType: 'JSON',
                        data: {
                            class_id: classId,
                            section_id: sectionId,
                            session_id: sessionId,
                        },
                        success: function(students) {
                            stdSelect.empty();
                            let options = '<option value="">Select Students</option>';

                            if (students.length > 0) {
                                $.each(students, function(index, student) {
                                    options += '<option value="' + student.srno + '">' +
                                        student.rollno + '. ' + student.student_name +
                                        '/SH. ' + student.f_name + '</option>';
                                });
                            } else {
                                options += '<option value="">No students found</option>';
                            }
                            stdSelect.html(options);

                            // Set the selected student if provided
                            if (selectedStudentId) {
                                stdSelect.val(selectedStudentId);
                            }
                        },
                        complete: function() {
                            loader.hide();
                        },
                        error: function(xhr) {
                            console.error(xhr.responseText);
                        }
                    });
                } else {
                    stdSelect.empty();
                    stdSelect.append('<option value="">Select Students</option>');
                }
            }

            classSelected.change(function() {
                let classId = $(this).val();
                fetchSections(classId);
            });
            $('#section_id').change(function() {
                let classId = $('#class_id').val();
                let sectionId = $('#section_id').val();
                // let sessionId = $('#current_session').val();
                // let stdSelect = $('#std_id');
                getStdDropdown(classId, sectionId);
            });

            $('#show-details').click(function() {
                let transport = $('#fee-type').val();
                let computerSlip = $('#computer-slip').val();
                let schoolSlip = $('#school-slip').val();
                let sessionId = $('#current_session').val();
                $('.show-details-error').hide().html('');
                if (transport == 2) {
                    $('.admission-div').remove();
                }
                $.ajax({
                    url: '<?php echo e(route('admin.editSection.getStdFeeInfo1')); ?>',
                    type: 'GET',
                    dataType: 'JSON',
                    data: {
                        transport: transport,
                        computer_slip: computerSlip,
                        school_slip: schoolSlip,
                        session: sessionId,
                    },
                    success: function(response) {
                        // Select the class
                        $('#class-section-form').show();
                        $('#cSlip').val(computerSlip);
                        $('#transport').val(transport);
                        classSelected.val(response.class).change();
                        // Fetch sections with the selected section id
                        fetchSections(response.class, response.section);
                        getStdDropdown(response.class, response.section);
                        $.each(response.data, function(index, st) {
                            getStdDropdown(response.class, response.section, st.srno);
                            $('#session').val(st.session_id);
                            if (st.fee_of == 1) {
                                $('#admission_fee').val(st.amount);
                            }
                            if (st.fee_of == 2) {
                                $('#first_inst_fee').val(st.amount);
                            }
                            if (st.fee_of == 3) {
                                $('#second_inst_fee').val(st.amount);
                            }
                            if (st.fee_of == 4) {
                                $('#complete_fee').val(st.amount);
                            }
                        });
                    },
                    complete: function() {
                        loader.hide();
                    },
                    error: function(xhr, status, error) {
                        $('.show-details-error').hide().html('');
                        $('#class-section-form').hide();

                        if (xhr.responseJSON && xhr.responseJSON.message) {
                            let message = xhr.responseJSON.message;

                            if (typeof message === 'object') {
                                // Handle multiple error messages
                                let errorMessage = '';
                                for (let key in message) {
                                    if (message.hasOwnProperty(key)) {
                                        errorMessage += message[key] + '<br>';
                                    }
                                }
                                $('.show-details-error').show().html(errorMessage);
                            } else {
                                // Handle single error message
                                $('.show-details-error').show().html(message);
                            }
                        } else {
                            // Generic error message if no specific message is available
                            $('.show-details-error').show().html(
                                'An error occurred. Please try again.');
                        }

                        console.error('Error:', xhr.responseText);
                    },
                });
            });

            $('#submit-fee').click(function(e) {
                if ($('#class-section-form').valid()) {
                    e.preventDefault();
                    const totalAmount = parseFloat($('#total_amount').val()) || 0;
                    const admissionFee = parseFloat($('#admission_fee').val()) || 0;
                    const firstInstFee = parseFloat($('#first_inst_fee').val()) || 0;
                    const secondInstFee = parseFloat($('#second_inst_fee').val()) || 0;
                    const completeFee = parseFloat($('#complete_fee').val()) || 0;
                    const mercyFee = parseFloat($('#mercy_fee').val()) || 0;
                    const total = admissionFee + firstInstFee + secondInstFee + completeFee + mercyFee;

                    if (total > totalAmount) {
                        $('#total-amount-error').show().html(
                            'You have entered an amount greater than the total amount');
                    } else {
                        $('#total-amount-error').hide().html('');
                        $.ajax({
                            data: $('#class-section-form').serialize(),
                            url: '<?php echo e(route('admin.editSection.editStdFeeStore')); ?>',
                            // url: siteUrl + '/fee/academic-fee-entry',
                            type: "POST",
                            dataType: 'JSON',
                            success: function(data) {
                                console.log(data);
                                Swal.fire({
                                    title: 'Good job!',
                                    text: data.message,
                                    icon: 'success',
                                    confirmButtonColor: 'rgb(122 190 255)',
                                }).then(() => {
                                    location.reload();
                                });
                            },
                            error: function(data) {
                                console.log(data);
                                var message = data.responseJSON.message;

                                $('#class-error').hide().html('');
                                $('#section-error').hide().html('');
                                $('#session-error').hide().html('');
                                $('#std-error').hide().html('');
                                $('#fee-date-error').hide().html('');
                                $('#ref-slip-error').hide().html('');
                                $('#admission-fee-error').hide().html('');
                                $('#first-inst-fee-error').hide().html('');
                                $('#second-inst-fee-error').hide().html('');
                                $('#complete-fee-error').hide().html('');
                                $('#mercy-fee-error').hide().html('');
                                // $('#not-applicable-error').hide().html();

                                if (message.class_id) {
                                    $('#class-error').show().html(message.class_id);
                                }
                                if (message.section_id) {
                                    $('#section-error').show().html(message.section_id);
                                }
                                if (message.std_id) {
                                    $('#std-error').show().html(message.std_id);

                                }
                                if (message.fee_date) {
                                    $('#fee-date-error').show().html(message.fee_date);
                                }
                                if (message.ref_slip) {
                                    $('#ref-slip-error').show().html(message.ref_slip);
                                }
                                if (message.admission_fee) {
                                    $('#admission-fee-error').show().html(message
                                        .admission_fee);
                                }
                                if (message.first_inst_fee) {
                                    $('#first-inst-fee-error').show().html(message
                                        .first_inst_fee);
                                }
                                if (message.second_inst_fee) {
                                    $('#second-inst-fee-error').show().html(message
                                        .second_inst_fee);
                                }
                                if (message.complete_fee) {
                                    $('#complete-fee-error').show().html(message
                                        .complete_fee);
                                }
                                if (message.mercy_fee) {
                                    $('#mercy-fee-error').show().html(message.mercy_fee);
                                }

                                if (message ==
                                    'No Transport Fee Applicable For This Student.') {
                                    // $('#not-applicable-error').show().html(message);
                                    $('#total-amount-error').show().html(message);
                                }
                            }
                        });
                    }


                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\svps-project\resources\views/admin/editSections/edit_fee_details_std.blade.php ENDPATH**/ ?>