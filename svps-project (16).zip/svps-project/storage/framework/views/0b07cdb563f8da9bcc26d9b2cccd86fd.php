<?php $__env->startSection('content'); ?>
    <div class="d-flex">
        <div class="py-4 col-md-2 navbar-light bg-white shadow-sm"
            style="height: 900px !important; background-color:#fe7c3e !important; color:white ;">
            <ul class="navbar-nav me-auto px-3">
                <li class="nav-item">
                    <a class="nav-link fs-5 fw-medium" href="<?php echo e(route('fee.changePass')); ?>">
                        <i class="mdi mdi-lock-reset"></i>
                        <span class="menu-title">Change Password</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link fs-5 fw-medium" href="<?php echo e(route('fee.fee-entry.index')); ?>">
                        <i class="mdi mdi-book"></i>
                        <span class="menu-title">Fee Entry</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link fs-5 fw-medium" href="<?php echo e(route('fee.fee-detail')); ?>">
                        <i class="mdi mdi-book"></i>
                        <span class="menu-title">Fee Detail</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link fs-5 fw-medium" href="<?php echo e(route('fee.fee-detail-relaive-wise')); ?>">
                        <i class="mdi mdi-book"></i>
                        <span class="menu-title">Relative Wise Fee Report</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link fs-5 fw-medium" href="<?php echo e(route('fee.back-session-fee-detail')); ?>">
                        <i class="mdi mdi-book"></i>
                        <span class="menu-title">Fee Details Back Sessions</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link fs-5 fw-medium" href="<?php echo e(route('fee.print-due-receipt')); ?>">
                        <i class="mdi mdi-printer"></i>
                        <span class="menu-title">Print Due Receipt</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link fs-5 fw-medium" href="<?php echo e(route('fee.due-fee-report')); ?>">
                        <i class="mdi mdi-receipt"></i>
                        <span class="menu-title">Due Fee Report</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link fs-5 fw-medium" href="<?php echo e(route('fee.due-fee-report-sms')); ?>">
                        <i class="mdi mdi-message"></i>
                        <span class="menu-title">Due Fee SMS</span>
                    </a>
                </li>
                <li class="nav-item">
                    
                </li>
                <li class="nav-item">
                    <a class="nav-link fs-5 fw-medium" href="<?php echo e(route('fee.current-session.index')); ?>">
                        <i class="mdi mdi-cog"></i>
                        <span class="menu-title">Setting</span>
                    </a>
                </li>


            </ul>
        </div>
        <main class="py-4 col-md-8">

            <?php echo $__env->yieldContent('sub-content'); ?>
        </main>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('current-session'); ?>
    <li class="mx-2 my-2 fw-bold border border-1 py-2 px-2 rounded-pill bg-black-subtle">
        <?php if(Session::has('fee_current_session')): ?>
            <?php echo e(Session::get('fee_current_session')->session); ?>

            <input type="hidden" name="fee_current_session" id="fee_current_session" value="<?php echo e(Session::get('fee_current_session')->id); ?>">
        <?php else: ?>
            No current session found.
        <?php endif; ?>
    </li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('public/fee/assets/js/custom.js')); ?>" type="text/javascript"></script>
    <?php echo $__env->yieldContent('fee-scripts'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\svps-project\resources\views/fee/index.blade.php ENDPATH**/ ?>