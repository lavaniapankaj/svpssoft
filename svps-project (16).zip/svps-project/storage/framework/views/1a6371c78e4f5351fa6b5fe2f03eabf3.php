<?php $__env->startSection('sub-content'); ?>
    <div class="container">

        <div class="row justify-content-center">
            <div class="col-md-14">
                <div class="card">
                    <div class="card-header">
                        <?php echo e('Fee Details (Relative Wise)'); ?>

                        <a href="<?php echo e(route('fee.fee-detail-relaive-wise')); ?>" class="btn btn-warning btn-sm"
                            style="float: right;">Back</a>

                    </div>
                    <div class="card-body">
                        <form id="class-section-form">
                            <div class="row">
                                <div class="form-group col-md-6">
                                    <label for="class_id" class="mt-2">Class <span class="text-danger">*</span></label>
                                    <input type="hidden" id="initialClassId"
                                        value="<?php echo e(old('initialClassId', request()->get('class_id') !== null ? request()->get('class_id') : '')); ?>">
                                    <select name="class" id="class_id" class="form-control " required>
                                        <option value="">Select Class</option>
                                    </select>
                                    <span class="invalid-feedback form-invalid fw-bold" id="class-error"
                                        role="alert"></span>
                                    <img src="<?php echo e(config('myconfig.myloader')); ?>" alt="Loading..." class="loader"
                                        id="loader" style="display:none; width:10%;">
                                </div>


                                <div class="form-group col-md-6">
                                    <label for="section_id" class="mt-2">Section <span
                                            class="text-danger">*</span></label>
                                    <input type="hidden" id="initialSectionId"
                                        value="<?php echo e(old('initialSectionId', request()->get('section_id') !== null ? request()->get('section_id') : '')); ?>">
                                    <select name="section" id="section_id" class="form-control  " required>
                                        <option value="">Select Section</option>
                                    </select>
                                    <span class="invalid-feedback form-invalid fw-bold" id="section-error"
                                        role="alert"></span>
                                </div>
                            </div>
                            <div class="row">
                                <div class="form-group col-md-6">
                                    <input type="hidden" name="current_session" value='' id="current_session">
                                    <label for="std_id" class="mt-2">Student <span class="text-danger">*</span></label>
                                    <select name="std_id" id="std_id" class="form-control " required>
                                        <option value="">Select Students</option>
                                    </select>
                                    <span class="invalid-feedback form-invalid fw-bold" id="std-error"
                                        role="alert"></span>
                                </div>
                            </div>
                        </form>
                        <div class="table mt-4">
                            <table class="table table-striped table-bordered">
                                <thead>
                                    <tr>
                                        <th colspan="3">Academic</th>
                                        <th colspan="3">Transport</th>
                                    </tr>
                                    <tr>
                                        <th>Total</th>
                                        <th>Paid</th>
                                        <th>Due</th>
                                        <th>Total</th>
                                        <th>Paid</th>
                                        <th>Due</th>
                                    </tr>

                                </thead>
                                <tbody>
                                    <tr>
                                        <td><?php echo e($feeMaster); ?></td>
                                        <td><?php echo e($totalAcademic); ?></td>
                                        <td><?php echo e($academicDue); ?></td>
                                        <td><?php echo e($std); ?></td>
                                        <td><?php echo e($totalTrans); ?></td>
                                        <td><?php echo e($transDue); ?></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                        <div id="std-fee-due-table" class="table-responsive">
                            <table class="table table-striped table-bordered">
                                <thead>
                                    <th>Class</th>
                                    <th>Section</th>
                                    <th>Name</th>
                                    <th>Father's Name</th>
                                    <th>Payable Amount(Ac.)</th>
                                    <th>Paid Amount(Ac.)</th>
                                    <th>Due Amount(Ac.)</th>
                                    <th>Payable Amount(Tr.)</th>
                                    <th>Paid Amount(Tr.)</th>
                                    <th>Due Amount(Tr.)</th>
                                    <th>Payable Amount(St.)</th>
                                    <th>Paid Amount(St.)</th>
                                    <th>Due Amount(St.)</th>
                                    <th>Details</th>
                                </thead>
                                <tbody>

                                </tbody>
                            </table>
                            <div class="export-div">
                                <button type="button" class="btn btn-info" id="export-button">Export</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('fee-scripts'); ?>
    <script>
        var initialClassId = '<?php echo e(old('class')); ?>';
        var initialSectionId = '<?php echo e(old('section')); ?>';

        $(document).ready(function() {
            // Call the original getClassSection function
            getClassSection(initialClassId, initialSectionId);

            // Add a mutation observer to watch for changes in the class dropdown
            var classDropdown = $('#class_id').get(0);
            var observer = new MutationObserver(function(mutations) {
                mutations.forEach(function(mutation) {
                    if (mutation.type === 'childList') {
                        addAllClassOption();
                        observer.disconnect(); // Stop observing once we've added the option
                    }
                });
            });

            observer.observe(classDropdown, { childList: true });

            function addAllClassOption() {
                var $classDropdown = $('#class_id');
                if ($classDropdown.find("option[value='all']").length === 0) {
                    $classDropdown.append('<option value="all">All Class</option>');
                }
            }

            $('#class_id').find('option').each(function() {
                    if ($(this).val() == 'all') {
                        if ($(this).val() !== '') {
                            $(this).attr('selected', true);
                        }
                    }
            });

            var stdSelect = $('#std_id');
            var stdFeeDueTable = $('#std-fee-due-table');
            var relativeStdFeeDueTable = $('#relative-std-fee-due-table');
            stdFeeDueTable.hide();
            relativeStdFeeDueTable.hide();

            stdSelect.change(function() {
                let sessionId = $('#current_session').val();
                stdFeeDueTable.show();
                $.ajax({
                    url: '<?php echo e(route('fee.fee-entry.academicFeeDueAmount')); ?>',
                    type: 'GET',
                    dataType: 'JSON',
                    data: {
                        srno: stdSelect.val(),
                        current_session: sessionId,
                    },
                    success: function(response) {
                        console.log(response);

                        let stdHtml = '';
                        let relativestdHtml = '';

                        // Process student data
                        const student = response.data;
                        console.log(student.sessions);

                        $.each(student.sessions, function(index, session) {
                            if (session.session_id == sessionId) {
                                stdHtml += `<tr>
                                        <td>${session.class}</td>
                                        <td>${session.section}</td>
                                        <td>${student.student_name}</td>
                                        <td>${student.father_name}</td>
                                        <td>${session.payable_amount}</td>
                                        <td>${session.paid_amount}</td>
                                        <td>${session.due_amount}</td>
                                        <td>${session.transport.payable_amount}</td>
                                        <td>${session.transport.paid_amount}</td>
                                        <td>${session.transport.due_amount}</td>
                                        <td>N/A</td>
                                        <td>N/A</td>
                                        <td>N/A</td>
                                        <td><a href='${siteUrl}/fee/individual-fee-details/${student.srno}/${session.session_id}'  class="btn btn-sm btn-icon p-1"> <i class="mdi mdi-eye mx-1" data-bs-toggle="tooltip"
                                                            data-bs-offset="0,4" data-bs-placement="top" title="View"></i></a></td>
                                    </tr>`;
                            }
                        });

                        // Process relatives data
                        if (student.relatives && student.relatives.length > 0) {
                            $.each(student.relatives, function(index, relative) {
                                // const encodedSrno = encodeURIComponent(relative.srno);
                                stdHtml += `<tr class="table-warning">
                                    <td>${relative.class}</td>
                                    <td>${relative.section}</td>
                                    <td>${relative.student_name}</td>
                                    <td>${relative.father_name}</td>
                                    <td>${relative.payable_amount}</td>
                                    <td>${relative.paid_amount}</td>
                                    <td>${relative.due_amount}</td>
                                    <td>${relative.transport.payable_amount}</td>
                                    <td>${relative.transport.paid_amount}</td>
                                    <td>${relative.transport.due_amount}</td>
                                    <td>N/A</td>
                                    <td>N/A</td>
                                    <td>N/A</td>
                                    <td><a href='${siteUrl}/fee/individual-fee-details/${relative.srno}/${relative.session_id}' class="btn btn-sm btn-icon p-1"> <i class="mdi mdi-eye mx-1" data-bs-toggle="tooltip"
                                                            data-bs-offset="0,4" data-bs-placement="top" title="View"></i></a></td>
                                    </tr>`;
                            });
                        }
                        if (stdHtml === '') {
                            stdHtml = '<tr><td colspan="14">No Student found</td></tr>';
                        }
                        $('#std-fee-due-table table tbody').html(stdHtml);
                    },
                    error: function(xhr) {
                        console.error(xhr.responseText);
                    }
                });
            });

            $('#export-button').on('click', function() {
                let session = $('#current_session').val();
                let stdSelect = $('#std_id').val();
                const exportUrl = "<?php echo e(route('fee.fee-detail-relaive-wise-excel')); ?>?srno=" +
                stdSelect + "&current_session=" + session;
                window.location.href = exportUrl;
            });
        });
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('fee.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\svps-project\resources\views/fee/fee_details/relativewise_fee_detail.blade.php ENDPATH**/ ?>