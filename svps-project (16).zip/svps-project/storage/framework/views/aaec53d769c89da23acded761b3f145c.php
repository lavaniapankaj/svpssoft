<?php $__env->startSection('sub-content'); ?>
    <div class="container">
        <?php if(Session::has('success')): ?>
            <?php $__env->startSection('scripts'); ?>
                <script>
                    swal("Good job!", "<?php echo e(Session::get('success')); ?>", "success").then(() => {
                        location.reload();
                    });
                </script>
            <?php $__env->stopSection(); ?>
        <?php endif; ?>
        <?php if(Session::has('error')): ?>
            <?php $__env->startSection('scripts'); ?>
                <script>
                    swal("Oops...", "<?php echo e(Session::get('error')); ?>", "error");
                </script>
            <?php $__env->stopSection(); ?>
        <?php endif; ?>
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">
                        <?php echo e('Edit Current/Previous Records'); ?>

                        <a href="<?php echo e(route('admin.editSection.index')); ?>" class="btn btn-warning btn-sm"
                            style="float: right;">Back</a>

                    </div>
                    <div class="card-body">
                        <form id="date-form">
                            <div class="row">
                                <div class="form-group col-md-6">
                                    <label for="srno" class="mt-2">Enter SRNO. <span
                                            class="text-danger">*</span></label>
                                    <input type="text" id="srno" name="srno"
                                        class="form-control <?php $__errorArgs = ['srno'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value=""
                                        placeholder="Enter SRNO. of Student ">
                                    <?php $__errorArgs = ['srno'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback form-invalid fw-bold"
                                            role="alert"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="form-group col-md-3">
                                    <button type="button" id="show-details" class="btn btn-primary mt-4">
                                        Show Details</button>
                                    <span id='no-std' class="invalid-feedback form-invalid fw-bold">No Student
                                        Found</span>
                                    <span class="invalid-feedback form-invalid fw-bold" id="srno-error" role="alert"></span>
                                    <img src="<?php echo e(config('myconfig.myloader')); ?>" alt="Loading..." class="loader"
                                        id="loader" style="display:none; width:10%;">
                                </div>
                                <div class="form-group col-md-3">
                                    <a href="<?php echo e(route('admin.student-master.search')); ?>" class="btn btn-sm btn-info mt-4"
                                        target="_blank" rel="noopener noreferrer">To Know SRNO Click Here</a>
                                </div>
                            </div>
                        </form>

                        <div class="mt-4" id="std-form">
                            <form action="<?php echo e(route('admin.editSection.editStdByPreSrno.store')); ?>" method="post"
                                id="student-form">
                                <?php echo csrf_field(); ?>
                                <div class="row">
                                    <div class="form-group col-md-6">
                                        <input type="hidden" name="std_srno" id="srno-inner" value="">
                                        <label for="std_name" class="mt-2">Name<span class="text-danger">*</span></label>
                                        <input type="text" id="std_name" name="std_name"
                                            class="form-control <?php $__errorArgs = ['std_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value=""
                                            placeholder="Enter Student Name" required>
                                        <?php $__errorArgs = ['std_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback form-invalid fw-bold"
                                                role="alert"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="form-group col-md-6">
                                        <label for="f_name" class="mt-2">Father's Name<span
                                                class="text-danger">*</span></label>
                                        <input type="text" id="f_name" name="f_name"
                                            class="form-control <?php $__errorArgs = ['f_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value=""
                                            placeholder="Enter Father's Name" required>
                                        <?php $__errorArgs = ['f_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback form-invalid fw-bold"
                                                role="alert"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="form-group col-md-6">
                                        <label for="m_name" class="mt-2">Mother's Name<span
                                                class="text-danger">*</span></label>
                                        <input type="text" id="m_name" name="m_name"
                                            class="form-control <?php $__errorArgs = ['m_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value=""
                                            placeholder="Enter Mother's Name" required>
                                        <?php $__errorArgs = ['m_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback form-invalid fw-bold"
                                                role="alert"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="form-group col-md-3">
                                        <label for="dob" class="mt-2">DOB<span class="text-danger">*</span></label>
                                        <input type="date" id="dob" name="dob"
                                            class="form-control <?php $__errorArgs = ['dob'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value=""
                                            placeholder="Enter DOB" required>
                                        <?php $__errorArgs = ['dob'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback form-invalid fw-bold"
                                                role="alert"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="form-group col-md-3">
                                        <label for="category" class="mt-2">Category<span
                                                class="text-danger">*</span></label>
                                        <select name="category" id="category"
                                            class="form-control <?php $__errorArgs = ['category'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                        </select>
                                        <?php $__errorArgs = ['category'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback form-invalid fw-bold"
                                                role="alert"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="form-group col-md-12">
                                        <label for="address">Address</label>
                                        <textarea name="address" id="address" class="form-control <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" rows="3"
                                            required></textarea>
                                        <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback form-invalid fw-bold"
                                                role="alert"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="mt-3">
                                    <button type="submit" class="btn btn-primary" id="update-std">Update</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('admin-scripts'); ?>
    <script>
        $(document).ready(function() {
            $('#std-form').hide();
            $('#change-date-container').hide();
            $('#no-std').hide();
            var loader = $('#loader');
            $('#show-details').on('click', function() {
                const srno = $('#srno').val();
                loader.show();
                $('#srno-error').hide();
                $('#std-form').hide();
                if (srno) {

                    $.ajax({
                        url: '<?php echo e(route('admin.getStdWithSrno')); ?>',
                        type: 'GET',
                        dataType: 'JSON',
                        data: {
                            srno: srno,
                        },
                        success: function(students) {
                            let stdHtml = '';
                            if (students.data.length > 0) {

                                $.each(students.data, function(index, std) {

                                    $('#srno-inner').val(std.srno);
                                    $('#std_name').val(std.student_name);
                                    $('#f_name').val(std.f_name);
                                    $('#m_name').val(std.m_name);
                                    $('#dob').val(std.dob);
                                    stdHtml +=
                                        `<option value="">Select Age Proof</option>
                                     <option value="1" ${std.category && std.category == 1 ? 'selected' : ''}>General</option>
                                     <option value="2" ${std.category && std.category == 2 ? 'selected' : ''}>OBC</option>
                                     <option value="3" ${std.category && std.category == 3 ? 'selected' : ''}>ST/SC</option>`;
                                    $('#category').append(stdHtml);
                                    $('#address').val(std.address);

                                });
                                $('#no-std').hide();
                                $('#std-form').show();
                            } else {
                                $('#std-form').hide();
                                $('#no-std').show();
                            }
                        },
                        complete: function() {

                            loader.hide();
                        },
                        error: function(xhr) {
                            if (xhr.status === 400) {
                                const response = xhr.responseJSON;
                                $.each(response.message, function(key, messages) {
                                    $.each(messages, function(index, message) {
                                       $('#srno-error').show().text(message);

                                    });
                                });
                            } else {
                                console.log('Request failed:', xhr);
                                $('#std-form').hide();
                            }
                            // $('#std-form').show();
                            // $('#no-std').hide();
                        },
                    });

                    $('#student-form').validate();
                }
            });


        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\svps-project\resources\views/admin/editSections/edit_std_prev_records.blade.php ENDPATH**/ ?>