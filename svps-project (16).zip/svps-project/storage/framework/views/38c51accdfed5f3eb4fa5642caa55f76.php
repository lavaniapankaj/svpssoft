<?php $__env->startSection('sub-content'); ?>
    <div class="container">
        <?php if(Session::has('success')): ?>
            <?php $__env->startSection('scripts'); ?>
                <script>
                    swal("Good job!", "<?php echo e(Session::get('success')); ?>", "success").then(() => {
                        $('#std-form').hide();
                        location.reload();
                    });
                </script>
            <?php $__env->stopSection(); ?>
        <?php endif; ?>

        <?php if(Session::has('error')): ?>
            <?php $__env->startSection('scripts'); ?>
                <script>
                    swal("Oops...", "<?php echo e(Session::get('error')); ?>", "error");
                </script>
            <?php $__env->stopSection(); ?>
        <?php endif; ?>
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">
                        <?php echo e('Edit Attendance Entry'); ?>

                        <a href="<?php echo e(route('admin.editSection.index')); ?>" class="btn btn-warning btn-sm"
                            style="float: right;">Back</a>

                    </div>
                    <div class="card-body">
                        <form id="class-section-form">

                            <div class="row">
                                <div class="form-group col-md-4">
                                    <label for="class_id" class="mt-2">Class <span class="text-danger">*</span></label>
                                    <input type="hidden" id="initialClassId"
                                        value="<?php echo e(old('initialClassId', request()->get('class_id') !== null ? request()->get('class_id') : '')); ?>">
                                    <select name="class" id="class_id"
                                        class="form-control <?php $__errorArgs = ['class'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                        <option value="">Select Class</option>
                                    </select>
                                    <?php $__errorArgs = ['class'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback form-invalid fw-bold"
                                            role="alert"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    <img src="<?php echo e(config('myconfig.myloader')); ?>" alt="Loading..." class="loader"
                                        id="loader" style="display:none; width:10%;">
                                </div>


                                <div class="form-group col-md-4">
                                    <label for="section_id" class="mt-2">Section <span
                                            class="text-danger">*</span></label>
                                    <input type="hidden" id="initialSectionId"
                                        value="<?php echo e(old('initialSectionId', request()->get('section_id') !== null ? request()->get('section_id') : '')); ?>">
                                    <select name="section" id="section_id"
                                        class="form-control <?php $__errorArgs = ['section'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                        <option value="">Select Section</option>

                                    </select>
                                    <?php $__errorArgs = ['section'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback form-invalid fw-bold"
                                            role="alert"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="form-group col-md-4">
                                    <input type="hidden" name="current_session" value='' id="current_session">
                                    <label for="std_id" class="mt-2">Student<span class="text-danger">*</span></label>
                                    <select name="std_id" id="std_id"
                                        class="form-control mx-1 <?php $__errorArgs = ['std_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                        <option value="">Select Student</option>
                                    </select>
                                    <span class="invalid-feedback form-invalid fw-bold student-error" role="alert"></span>

                                </div>
                            </div>


                            <div class="mt-3">
                                <button type="button" id="show-details" class="btn btn-primary">
                                    Show Details</button>
                            </div>

                        </form>


                        <div id="std-container" class="mt-4">
                            <table class="table table-responsible">
                                <thead>
                                    <tr>
                                        <th>Slip No.</th>
                                        <th>Entry Date</th>
                                        <th>Type</th>
                                        <th>Fee of</th>
                                        <th>Amount</th>
                                        <th>Paid / Mercy</th>
                                        <th>Show</th>
                                    </tr>
                                </thead>
                                <tbody>

                                </tbody>
                            </table>
                        </div>
                        <div id="edit-std-container" class="mt-4">
                            <form action="" method="post">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" id="hidden-srno" name="srno" value="">
                                <input type="hidden" id="hidden-session" name="session" value="">
                                <input type="hidden" id="hidden-feeOf" name="feeOf" value="">
                                <input type="hidden" id="hidden-academicTrans" name="academicTrans" value="">
                                <input type="hidden" id="hidden-paidMercy" name="paidMercy" value="">
                                <input type="hidden" id="hidden-refSlip" name="refSlip" value="">
                                <table class="table table-responsible">
                                    <thead>
                                        <tr>
                                            <th>Slip No.</th>
                                            <th>Entry Date</th>
                                            <th>Type</th>
                                            <th>Fee of</th>
                                            <th>Amount</th>
                                            <th>Paid / Mercy</th>
                                            <th>Show</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    </tbody>
                                </table>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('admin-scripts'); ?>
    <script>
        $(document).ready(function() {
            let initialClassId = $('#class_id').val();
            let initialSectionId = $('#section_id').val();
            getClassSection(initialClassId, initialSectionId);
            $('#std-form').hide();
            getStdDropdown();
            $('#class-section-form').validate({
                rules: {
                    class: {
                        required: true,
                    },
                    section: {
                        required: true,
                    },
                    std_id: {
                        required: true,
                    },
                },
                messages: {
                    class: {
                        required: "Please select a class.",
                    },
                    section: {
                        required: "Please select a section.",
                    },
                    std_id: {
                        required: "Please select a student.",
                    },
                },
            });
            $('#std-container').hide();
            $('#edit-std-container').hide();



            $('#show-details').on('click', function() {
                if ($('#class-section-form').valid()) {
                    let stdId = $('#std_id').val();
                    let sessionId = $('#current_session').val();
                    $.ajax({
                        url: '<?php echo e(route('admin.editSection.stdFeeDetailFetch')); ?>',
                        type: 'GET',
                        dataType: 'JSON',
                        data: {
                            srno: stdId,
                            session: sessionId,
                        },
                        success: function(response) {
                            let stdHtml = '';
                            if (response.data && response.data.length > 0) {
                                $.each(response.data, function(id, value) {
                                    stdHtml += `<tr>
                                        <td>${value.ref_slip_no ?? ''}</td>
                                        <td>${value.pay_date}</td>
                                        <td>${value.academic_trans == 1 ? 'Academic' : 'Transport'}</td>
                                        <td>${value.fee_of == 1 ? 'Admission Fee' : (value.fee_of == 2 ? 'Ist Installment' : value.fee_of == 3 ? 'IInd installment' : (value.fee_of == 4 && value.paid_mercy == 1 ? 'Complete' : 'Mercy Fee'))}</td>
                                        <td>${value.amount}</td>
                                        <td>${value.fee_of == 4 && value.paid_mercy == 2 ? 'Mercy' : 'Paid'}</td>
                                         <td>
                                            <button class="btn btn-sm btn-icon p-1 edit-btn"
                                                    data-srno="${value.srno}"
                                                    data-session="${sessionId}"
                                                    data-refslip="${value.ref_slip_no}"
                                                    data-fee-of="${value.fee_of}"
                                                    data-academic-trans="${value.academic_trans}"
                                                    data-paid-mercy="${value.paid_mercy}"
                                                    data-pay-date="${value.pay_date}">
                                                <i class="mdi mdi-pencil" data-bs-toggle="tooltip" data-bs-offset="0,4"
                                                data-bs-placement="top" title="Edit"></i>
                                            </button>
                                            <form action="${siteUrl}/admin/edit-section/std-fee-edit-remove/${value.id}"
                                                    method="POST" style="display:inline;">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit" class="btn btn-sm btn-icon p-1 delete-form-btn"
                                                        data-bs-toggle="tooltip" data-bs-offset="0,4"
                                                        data-bs-placement="top" data-bs-html="true" title="Delete">
                                                        <i class="mdi mdi-delete"></i>
                                                    </button>
                                            </form>

                                        </td>
                                </tr>`;
                                });
                            } else {
                                stdHtml =
                                    '<tr><td colspan="7" class="text-center">No Fee Details Found</td></tr>';
                                $('#edit-std-container').hide();
                            }
                            $('#std-container table tbody').html(stdHtml);
                            $('#std-container').show();
                        },
                        error: function(xhr) {
                            console.error('Error fetching student details:', xhr);

                        }
                    });
                }
            });

            // Add event listener for edit buttons
            $('#std-container').on('click', '.edit-btn', function() {
                const srno = $(this).data('srno');
                const sessionId = $(this).data('session');
                const feeOf = $(this).data('fee-of');
                const academicTrans = $(this).data('academic-trans');
                const paidMercy = $(this).data('paid-mercy');
                const payDate = $(this).data('pay-date');
                const refSlip = $(this).data('refslip');
                editFee(srno, sessionId, feeOf, academicTrans, paidMercy, payDate, refSlip);
                $('#hidden-srno').val(srno);
                $('#hidden-session').val(sessionId);
                $('#hidden-feeOf').val(feeOf);
                $('#hidden-academicTrans').val(academicTrans);
                $('#hidden-paidMercy').val(paidMercy);
                $('#hidden-refSlip').val(refSlip);

            });
            $(document).on('click', '.delete-form-btn', function(event) {
                event.preventDefault();
                console.log('Delete button clicked'); // Debug log

                Swal.fire({
                    title: 'Are you sure?',
                    text: "You won't be able to revert this!",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Yes, delete it!'
                }).then((result) => {
                    console.log('SweetAlert result:', result); // Debug log
                    if (result.isConfirmed) {
                        var form = $(this).closest('form');
                        var url = form.attr('action');
                        var token = form.find('input[name="_token"]').val();

                        $.ajax({
                            url: url,
                            type: 'DELETE',
                            headers: {
                                'Content-Type': 'application/json',
                                'X-CSRF-TOKEN': token
                            },
                            success: function(data) {
                                console.log('Ajax success:', data); // Debug log
                                if (data.status === 'success') {
                                    Swal.fire(
                                        'Deleted!',
                                        data.message,
                                        'success'
                                    ).then(() => {
                                        location.reload();
                                    });
                                } else {
                                    Swal.fire(
                                        'Error!',
                                        data.message,
                                        'error'
                                    );
                                }
                            },
                            error: function(xhr, status, error) {
                                console.error('Ajax error:', xhr, status,
                                error); // Debug log
                                Swal.fire(
                                    'Error!',
                                    'An error occurred while deleting.',
                                    'error'
                                );
                            }
                        });
                    }
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\svps-project\resources\views/admin/editSections/edit_remove_std_fee_entry.blade.php ENDPATH**/ ?>