<?php $__env->startSection('sub-content'); ?>
    <div class="container">
        <?php if(Session::has('success')): ?>
            <?php $__env->startSection('scripts'); ?>
                <script>
                    swal("Good job!", "<?php echo e(Session::get('success')); ?>", "success").then(() => {
                        location.reload();
                    });

                </script>
            <?php $__env->stopSection(); ?>
        <?php endif; ?>

        <?php if(Session::has('error')): ?>
            <?php $__env->startSection('scripts'); ?>
                <script>
                    swal("Oops...", "<?php echo e(Session::get('error')); ?>", "error");
                </script>
            <?php $__env->stopSection(); ?>
        <?php endif; ?>
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">
                        <?php echo e('Edit Result Date'); ?>

                        <a href="<?php echo e(route('admin.editSection.index')); ?>" class="btn btn-warning btn-sm"
                            style="float: right;">Back</a>

                    </div>
                    <div class="card-body">
                        <form action="<?php echo e(route('admin.editSection.editResultStore')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="form-group col-md-6">
                                    <label for="session_id" class="mt-2">Session <span
                                            class="text-danger">*</span></label>
                                    <input type="hidden" id="initialSesstionId"
                                        value="<?php echo e(old('session_id', isset($data) ? $data->id : '')); ?>">
                                    <select name="session_id" id="session_id"
                                        class="form-control <?php $__errorArgs = ['session_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                        <option value="">Select session</option>
                                    </select>
                                    <?php $__errorArgs = ['session_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback form-invalid fw-bold" role="alert">
                                            <?php echo e($message); ?>

                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    <img src="<?php echo e(config('myconfig.myloader')); ?>" alt="Loading..." class="loader"
                                        id="loader" style="display:none; width:10%;">
                                </div>


                                <div class="form-group col-md-6">
                                    <label for="resultDate" class="mt-2">Enter Result Date <span
                                            class="text-danger">*</span></label>
                                    <input type="date" id="resultDate" name="resultDate" value="<?php echo e(old('resultDate')); ?>" class="form-control <?php $__errorArgs = ['resultDate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">

                                    <?php $__errorArgs = ['resultDate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback form-invalid fw-bold"
                                            role="alert"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="mt-3">
                                
                                <input class="btn btn-primary" type="submit" value="Update">
                            </div>

                        </form>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('admin-scripts'); ?>
    <script>
         var initialSessionId = $('#initialSesstionId').val();
         getSession(initialSessionId);
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\svps-project\resources\views/admin/editSections/edit_result.blade.php ENDPATH**/ ?>