<?php $__env->startSection('sub-content'); ?>
    <div class="container">
      <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card">
                        <div class="card-header">
                            <?php echo e(isset($fee) && isset($fee->id) ? 'Edit Academic Fee' : 'Add New Academic Fee'); ?>

                            <a href="<?php echo e(route('admin.academic-fee-master.index')); ?>" class="btn btn-warning btn-sm"
                                style="float: right;">Back</a>

                        </div>

                        <div class="card-body">
                            <form action="<?php echo e(route('admin.academic-fee-master.store')); ?>" method="POST"
                                enctype="multipart/form-data" id="basic-form">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="id" id="id"
                                    value="<?php echo e(isset($fee) ? $fee->id : ''); ?>">

                                <div class="row">
                                    <div class="form-group col-md-6">
                                        <label for="session_id" class="mt-2"> Session <span
                                                class="text-danger">*</span></label>
                                        <input type="hidden" id="initialSectionId" value="<?php echo e($fee->session_id ?? ''); ?>">
                                        <select name="session_id" id="session_id"
                                            class="form-control <?php $__errorArgs = ['session_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                            <option value="">Select Session</option>

                                        </select>
                                        <?php $__errorArgs = ['session_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback form-invalid fw-bold" role="alert">
                                                <?php echo e($message); ?>

                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="form-group col-md-6">
                                        <label for="class_id" class="mt-2">Class <span
                                                class="text-danger">*</span></label>
                                        <input type="hidden" id="initialClassId"
                                            value="<?php echo e(isset($fee) ? $fee->class_id : ''); ?>">
                                        <select name="class_id" id="class_id"
                                            class="form-control <?php $__errorArgs = ['class_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                            <option value="">Select Class</option>
                                        </select>
                                        <?php $__errorArgs = ['class_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback form-invalid fw-bold" role="alert">
                                                <?php echo e($message); ?>

                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <img src="<?php echo e(config('myconfig.myloader')); ?>" alt="Loading..." class="loader"
                                        id="loader" style="display:none; width:10%;">
                                </div>

                                <div class="row">

                                    <div class="row">
                                        <div class="form-group col-md-2">
                                            <label for="admission_fee">Admission + Security Fee</label>
                                            <input type="text" name="admission_fee" id="admission_fee"
                                                class="form-control <?php $__errorArgs = ['admission_fee'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                value="<?php echo e(old('admission_fee', isset($fee) ? $fee->admission_fee : '')); ?>"
                                                required>
                                            <?php $__errorArgs = ['admission_fee'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback form-invalid fw-bold"
                                                    role="alert"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="form-group col-md-2">
                                            <label for="inst_1">1st Installment</label>
                                            <input type="text" name="inst_1" id="inst_1"
                                                class="form-control <?php $__errorArgs = ['inst_1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                value="<?php echo e(old('inst_1', isset($fee) ? $fee->inst_1 : '')); ?>" required>
                                            <?php $__errorArgs = ['inst_1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback form-invalid fw-bold"
                                                    role="alert"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="form-group col-md-2">
                                            <label for="inst_2">2nd Installment</label>
                                            <input type="text" name="inst_2" id="inst_2"
                                                class="form-control <?php $__errorArgs = ['inst_2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                value="<?php echo e(old('inst_2', isset($fee) ? $fee->inst_2 : '')); ?>" required>
                                            <?php $__errorArgs = ['inst_2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback form-invalid fw-bold"
                                                    role="alert"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="form-group col-md-2">
                                            <label for="ins_discount">Discount</label>
                                            <input type="text" name="ins_discount" id="ins_discount"
                                                class="form-control <?php $__errorArgs = ['ins_discount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                value="<?php echo e(old('ins_discount', isset($fee) ? $fee->ins_discount : '')); ?>"
                                                required>
                                            <?php $__errorArgs = ['ins_discount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback form-invalid fw-bold"
                                                    role="alert"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="form-group col-md-2">
                                            <label for="inst_total">Total</label>
                                            <input type="text" name="inst_total" id="inst_total"
                                                class="form-control <?php $__errorArgs = ['inst_total'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                value="<?php echo e(old('inst_total', isset($fee) ? $fee->inst_total : '')); ?>"
                                                readonly>
                                            <?php $__errorArgs = ['inst_total'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback form-invalid fw-bold"
                                                    role="alert"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>

                                    </div>
                                </div>

                                <div class="mt-3">
                                    <input class="btn btn-primary" type="submit"
                                        value="<?php echo e(isset($fee) && isset($fee->id) ? 'Update' : 'Save'); ?>">
                                </div>
                            </form>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('admin-scripts'); ?>
    <script>
        document.addEventListener("DOMContentLoaded", (event) => {

            var initialSessionId = '<?php echo e(old('session_id', isset($fee) ? $fee->session_id : '')); ?>';
            var initialClassId = '<?php echo e(old('class_id', isset($fee) ? $fee->class_id : '')); ?>';
            getClassSection(initialClassId);
            getSession(initialSessionId);
        });
        $(document).ready(function() {

            function calculateTotal() {
                let admission = parseFloat($('#inst_admission').val()) || 0;
                let firstInstall = parseFloat($('#inst_1').val()) || 0;
                let secondInstall = parseFloat($('#inst_2').val()) || 0;
                let discount = parseFloat($('#inst_discount').val()) || 0;

                let total = admission + firstInstall + secondInstall - discount;

                $('#inst_total').val(total.toFixed(2));
            }

            $('#inst_admission, #inst_1 ,#inst_2, #inst_discount').on('input', calculateTotal);

            calculateTotal();
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\svps-project\resources\views/admin/academic_fee/create.blade.php ENDPATH**/ ?>