<?php $__env->startSection('sub-content'); ?>
    <div class="container">

        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header"><?php echo e(__('New Admission Report By Religion')); ?>

                        <a href="<?php echo e(route('admin.reports.newAdmissionReport')); ?>" class="btn btn-warning btn-sm"
                            style="float: right;">Back</a>
                    </div>

                    <div class="card-body">
                        <form action="" method="get" id="report-form">
                            <div class="row mt-2">
                                <div class="form-group col-md-6">
                                    <label for="session_id" class="mt-2">Session <span
                                            class="text-danger">*</span></label>
                                    <input type="hidden" id="initialSesstionId"
                                        value="<?php echo e(old('session_id', isset($data) ? $data->id : '')); ?>">
                                    <select name="session_id" id="session_id"
                                        class="form-control <?php $__errorArgs = ['session_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                        <option value="">Select session</option>
                                    </select>
                                    <span class="invalid-feedback form-invalid fw-bold session-error" role="alert"></span>

                                    <img src="<?php echo e(config('myconfig.myloader')); ?>" alt="Loading..." class="loader"
                                        id="loader" style="display:none; width:10%;">
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="class_id" class="mt-2">Class <span class="text-danger">*</span></label>
                                    <input type="hidden" name="current_session" value='' id="current_session">
                                    <input type="hidden" id="initialClassId" name="initialClassId"
                                        value="<?php echo e(old('initialClassId', request()->get('class_id') !== null ? request()->get('class_id') : '')); ?>">
                                    <select name="class_id" id="class_id"
                                        class="form-control mx-1 <?php $__errorArgs = ['class_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                        <option value="">All Class</option>
                                    </select>
                                    <?php $__errorArgs = ['class_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback form-invalid fw-bold" role="alert">
                                            <?php echo e($message); ?>

                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    <img src="<?php echo e(config('myconfig.myloader')); ?>" alt="Loading..." class="loader"
                                        id="loader" style="display:none; width:10%;">
                                </div>
                            </div>

                            <div class="row">
                                <div class="form-group col-md-6">
                                    <label for="start-date" class="mt-2">Enter Start Date</label>
                                    <input type="date" name="startDate" id="start-date" class="form-control"
                                        value="">
                                    <span class="invalid-feedback form-invalid fw-bold start-date-error"
                                        role="alert"></span>
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="end-date" class="mt-2">Enter End Date</label>
                                    <input type="date" name="endDate" id="end-date" class="form-control" value="">
                                    <span class="invalid-feedback form-invalid fw-bold end-date-error"
                                        role="alert"></span>
                                </div>
                            </div>

                            <div class="mt-3">
                                <button class="btn btn-primary" type="button" id="show-report">Show Report</button>

                            </div>
                        </form>

                        <div class="super-div">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>Class</th>
                                        <th>Gender</th>
                                        <th>Total</th>
                                    </tr>
                                </thead>
                                <tbody id="report-body">
                                </tbody>
                            </table>
                            <div class="export-div">
                                <button type="button" class="btn btn-info" id="export-button">Export</button>
                            </div>
                        </div>

                    </div>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('admin-scripts'); ?>
    <script>
        $(document).ready(function() {
            let initialSessionId = $('#initialSesstionId').val();
            getSession(initialSessionId);
            getClassDropDownWithAll();
            $('.super-div').hide();

            function getReport(sd = '', ed = '') {
                let sessionId = $('#session_id').val();
                let classId = $('#class_id').val();
                $.ajax({
                    url: '<?php echo e(route('admin.reports.newAdmissionReportByBetweenDates')); ?>',
                    type: 'GET',
                    dataType: 'JSON',
                    data: {
                        session_id: sessionId,
                        class: classId,
                        startDate: sd,
                        endDate: ed,
                    },
                    success: function(response) {
                        let tableHtml = '';
                        $.each(response.data, function(index, value) {

                            tableHtml += `
                                    <tr>
                                        <td rowspan="2">${value.class}</td>
                                                <td>Boys --> </td>
                                                <td>${value.boys}</td>
                                    </tr>`;
                            tableHtml += ` <tr>
                                                    <td>Girls --> </td>
                                                    <td>${value.girls}</td>
                                        </tr>`;
                        });
                        $('#report-body').html(tableHtml);
                    },
                    complete: function() {

                        loader.hide();
                    },
                    error: function(xhr) {
                        console.log(xhr);

                    },
                });

            }

            $('#show-report').click(function() {
                if ($('#report-form').valid() && $('.start-date-error').css('display') !== 'inline' && $('.end-date-error').css('display') !== 'inline') {

                    $('.super-div').show();
                    let stDate = $('#start-date').val();
                    let enDate = $('#end-date').val();
                    getReport(stDate, enDate);
                    getExcelReport(stDate, enDate);
                }


            });
            $('#start-date').on('change', function() {
                const startDate = $(this).val();
                const endDate = $('#end-date').val();
                if (startDate && endDate && startDate > endDate) {
                    $('.start-date-error').show().html('Start date must not be greater than end date');
                }  else if (!endDate) {
                    $('.end-date-error').show().html('Please select the end date also');

                }
                else {
                    $('.start-date-error').hide().html('');
                }
            });

            $('#end-date').on('change', function() {
                const startDate = $('#start-date').val();
                const endDate = $(this).val();

                if (endDate && startDate && endDate < startDate) {
                    $('.end-date-error').show().html('End date must not be less than start date');
                } else if (!startDate) {
                    $('.end-date-error').show().html('Please select the satrt date also');

                }
                else {
                    $('.end-date-error').hide().html('');
                }
            });

            // Add event listeners for form field changes
            $('#class_id, #session_id, #start-date, #end-date').change(function() {
                $('.super-div').hide();
            });

            function getExcelReport(st = '', ed = '') {
                $('#export-button').on('click', function() {
                    const session = $('#session_id').val();
                    const classId = $('#class_id').val();
                    let startDate = st;
                    let endDate = ed;

                    const exportUrl =
                        "<?php echo e(route('admin.reports.exportReportByBetweenDates')); ?>?session_id=" +
                        session +
                        "&class=" + classId + "&startDate=" + startDate + "&endDate=" + endDate;
                    window.location.href = exportUrl;
                });
            }


        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\svps-project\resources\views/admin/reports/new_admission_report_between_dates.blade.php ENDPATH**/ ?>