<?php $__env->startSection('sub-content'); ?>
    <div class="container">

        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card">
                        <div class="card-header">
                            <?php echo e(isset($marks) && isset($marks->id) ? 'Edit Marks' : 'Add New Marks'); ?>

                            <a href="<?php echo e(route('admin.marks-master.index')); ?>" class="btn btn-warning btn-sm"
                                    style="float: right;">Back</a>

                        </div>

                        <div class="card-body">
                            <form action="<?php echo e(route('admin.marks-master.store')); ?>" method="POST"
                                enctype="multipart/form-data" id="basic-form">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="id" id="id"
                                    value="<?php echo e(isset($marks) ? $marks->id : ''); ?>">

                                <div class="row">
                                    <div class="form-group col-md-4">
                                        <input type="hidden" name="current_session" value='' id="current_session">
                                        <label for="class_id" class="mt-2">Class <span
                                                class="text-danger">*</span></label>
                                        <input type="hidden" id="initialClassId"
                                            value="<?php echo e(isset($marks) ? $marks->class_id : ''); ?>">
                                        <select name="class_id" id="class_id"
                                            class="form-control <?php $__errorArgs = ['class_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                            <option value="">Select Class</option>

                                        </select>
                                        <?php $__errorArgs = ['class_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback form-invalid fw-bold" role="alert">
                                                <?php echo e($message); ?>

                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="form-group col-md-4">

                                        <label for="subject_id" class="mt-2">Subject <span
                                                class="text-danger">*</span></label>
                                        <input type="hidden" id="initialClassId"
                                            value="<?php echo e(isset($marks) ? $marks->subject_id : ''); ?>">
                                        <select name="subject_id" id="subject_id"
                                            class="form-control <?php $__errorArgs = ['subject_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                            <option value="">Select Subject</option>
                                        </select>
                                        <?php $__errorArgs = ['subject_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback form-invalid fw-bold" role="alert">
                                                <?php echo e($message); ?>

                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="form-group col-md-4">
                                        <label for="exam_id" class="mt-2">Exam <span
                                                class="text-danger">*</span></label>
                                        <input type="hidden" id="initialExamId"
                                            value="<?php echo e(isset($marks) ? $marks->exam_id : ''); ?>">
                                        <select name="exam_id" id="exam_id"
                                            class="form-control <?php $__errorArgs = ['exam_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                            <option value="">Select Exam</option>
                                            
                                        </select>
                                        <?php $__errorArgs = ['exam_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback form-invalid fw-bold" role="alert">
                                                <?php echo e($message); ?>

                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <img src="<?php echo e(config('myconfig.myloader')); ?>" alt="Loading..." class="loader"
                                        id="loader" style="display:none; width:10%;">
                                </div>

                                <div class="row">
                                    <div class="form-group col-md-6">
                                        <label for="min_marks" class="mt-2">Enter Minimum Marks <span
                                                class="text-danger">*</span></label>
                                        <input type="text" name="min_marks"
                                            class="form-control <?php $__errorArgs = ['min_marks'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            placeholder="Minimum Marks"
                                            value="<?php echo e(old('min_marks', isset($marks) ? $marks->min_marks : '')); ?>" id="min_marks" required>
                                        <?php $__errorArgs = ['min_marks'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback form-invalid fw-bold" role="alert">
                                                <?php echo e($message); ?>

                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="form-group col-md-6">
                                        <label for="max_marks" class="mt-2">Enter Maximum Marks <span
                                                class="text-danger">*</span></label>
                                        <input type="text" name="max_marks"
                                            class="form-control <?php $__errorArgs = ['max_marks'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            placeholder="Maximum Marks"
                                            value="<?php echo e(old('max_marks', isset($marks) ? $marks->max_marks : '')); ?>" id="max_marks" required>
                                        <?php $__errorArgs = ['max_marks'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback form-invalid fw-bold" role="alert">
                                                <?php echo e($message); ?>

                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="mt-3">
                                    <input class="btn btn-primary" type="submit"
                                        value="<?php echo e(isset($marks) && isset($marks->id) ? 'Update' : 'Save'); ?>">
                                </div>
                            </form>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('admin-scripts'); ?>
    <script>
        var initialClassId = '<?php echo e(old('class_id', isset($marks) ? $marks->class_id : '')); ?>';
        getClassSection(initialClassId);
        var initialSubjectId = '<?php echo e(old('subject_id', isset($marks) ? $marks->subject_id : '')); ?>';
        getClassSubject(initialClassId,initialSubjectId);
        var initialExamId = '<?php echo e(old('exam_id', isset($marks) ? $marks->exam_id : '')); ?>';
        getExams(initialExamId);
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\svps-project\resources\views/admin/marks/create.blade.php ENDPATH**/ ?>