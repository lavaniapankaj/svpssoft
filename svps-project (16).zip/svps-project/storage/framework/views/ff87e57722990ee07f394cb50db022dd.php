
<?php $__env->startSection('sub-content'); ?>
    <div class="container">

        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header"><?php echo e(__('SR Register')); ?>

                        <a href="<?php echo e(route('admin.reports')); ?>" class="btn btn-warning btn-sm" style="float: right;">Back</a>
                    </div>

                    <div class="card-body">

                        <div class="row mt-2">
                            <div class="form-group col-md-6">
                                <label for="session_id" class="mt-2">Session <span class="text-danger">*</span></label>
                                <input type="hidden" id="initialSesstionId"
                                    value="<?php echo e(old('session_id', isset($data) ? $data->id : '')); ?>">
                                <select name="session_id" id="session_id"
                                    class="form-control <?php $__errorArgs = ['session_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                    <option value="">Select session</option>
                                </select>
                                <?php $__errorArgs = ['session_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback form-invalid fw-bold" role="alert">
                                        <?php echo e($message); ?>

                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <img src="<?php echo e(config('myconfig.myloader')); ?>" alt="Loading..." class="loader" id="loader"
                                    style="display:none; width:10%;">
                            </div>

                            <div class="form-group col-md-6">
                                <label for="std-type" class="mt-2">Student Type <span class="text-danger">*</span></label>
                                <select name="std_type" id="std-type" class="form-control" required>
                                    <option value="1,2,3,4,5">All</option>
                                    <option value="1">Present</option>
                                    <option value="4">TC Issued</option>
                                    <option value="5">Left Out</option>
                                </select>
                                <span class="invalid-feedback form-invalid fw-bold" role="alert"></span>
                            </div>

                        </div>
                        

                        <div class="super-div">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>Sr. No.</th>
                                        <th>Class</th>
                                        <th>Student Name</th>
                                        <th>Father's Name</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody id="student-report-body">
                                    <!-- Student Report Data will be loaded here -->
                                </tbody>
                            </table>
                            <div id="std-pagination"></div>
                        </div>

                        

                        



                        <div class="table mt-4" id="prev_record">
                            <h4 class="text-danger fw-bold">Previous Details</h4>
                            <table id="example" class="table table-striped table-bordered">
                                <thead id="previous-header">

                                </thead>
                                <tbody id="previous-body"></tbody>

                            </table>


                        </div>
                       

                        

                        <div class="table table-responsive" id="current_details">
                            <h4 class="text-danger fw-bold">Current Details</h4>
                            <table id="example" class="table table-striped table-bordered">
                                <thead id="st-details-body">

                                </thead>
                                <tbody id="st-details-body"></tbody>

                            </table>
                            <table id="example" class="table table-striped table-bordered">
                                <thead id="parent-details-body">

                                </thead>
                                <tbody id="parent-details-body"></tbody>

                            </table>
                            <table id="example" class="table table-striped table-bordered">
                                <thead id="academic-details-body">
                                </thead>
                                <tbody id="academic-details-body"></tbody>

                            </table>



                        </div>

                        

                        

                    </div>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('admin-scripts'); ?>
    <script>
        $(document).ready(function() {
            let initialSessionId = $('#initialSesstionId').val();
            getSession(initialSessionId);
            let view = $('#edit-section-editBtn');
            // let view = $('.show');
            let prevRecord = $('#prev_record');
            let currentDetail = $('#current_details');
            let stdFormConatiner = $('#super-div');
            var loader = $('#loader');
            prevRecord.hide();
            currentDetail.hide();
            stdFormConatiner.hide();

            function getStdTbale(page = 1) {
                let stdType = $('#std-type').val();
                let sessionId = $('#session_id').val();
                stdFormConatiner.show();
                $.ajax({
                    url: '<?php echo e(route('admin.reports.reportSrRegisterWise')); ?>',
                    type: 'GET',
                    dataType: 'JSON',
                    data: {
                        session_id: sessionId,
                        type: stdType,
                        page: page,
                    },
                    success: function(response) {
                        let tableHtml = '';

                        if (response.data.data && Array.isArray(response.data.data)) {
                            response.data.data.forEach(function(student, index) {
                                tableHtml += `<tr>
                            <td>${student.srno}</td>
                            <td>${student.class_name}</td>
                            <td>${student.student_name}</td>
                            <td>${student.f_name}</td>
                            <td>
                                <a href="#" class="btn btn-sm btn-icon p-1" id="edit-section-editBtn" data-id=${student.prev_srno} data-id-srno="${student.srno}">
                                    <i class="mdi mdi-eye" data-bs-toggle="tooltip" data-bs-offset="0,4"
                                        data-bs-placement="top" title="View"></i>
                                </a>
                            </td>
                        </tr>`;
                            });
                        }
                        if (tableHtml === '') {
                            tableHtml = '<tr><td colspan="5">No data found</td></tr>';
                        }
                        $('#student-report-body').html(tableHtml);
                        updatePaginationControls(response.data);
                    },
                    complete: function() {

                        loader.hide();
                    },
                    error: function(xhr) {
                        console.log(xhr);

                    },

                });
            }
            $('#session_id').change(function() {
                getStdTbale();
            });
            $('#std-type').change(function() {
                getStdTbale();
            });


            $(document).on('click', '#std-pagination .page-link', function(e) {
                e.preventDefault();
                let page = $(this).data('page');
                getStdTbale(page);
            });

            function getStCurrentDetails(srno) {
                $.ajax({
                    url: '<?php echo e(route('admin.reports.tcStCurrentDetails')); ?>',
                    method: 'GET',
                    data: {
                        srno: srno
                    },
                    dataType: 'JSON',
                    success: function(response) {
                        if (response.status === 'success') {
                            // Process each table in the response
                            response.tables.forEach(table => {
                                let tableHtml = '';
                                let headerHtml = '';

                                // Create table headers
                                headerHtml = '<tr>';
                                table.headers.forEach(header => {
                                    headerHtml += `<th>${header}</th>`;
                                });
                                headerHtml += '</tr>';

                                // Create table rows with data
                                if (table.title === 'Attendance') {
                                    // Handle attendance date separately
                                    if (table.data && table.data.date) {
                                        $('#last-attendance-date').text(table.data.date);
                                    } else {
                                        $('#last-attendance-date').text('No date available');
                                    }
                                    // Skip the rest of the processing for attendance
                                    return;
                                }
                                tableHtml = '<tr>';
                                if (table.data.length > 0) {
                                    const rowData = table.data[0];
                                    switch (table.title) {
                                        case 'Student Details':
                                            tableHtml += `
                                                <td>${rowData.srno}</td>
                                                <td>${rowData.name}</td>
                                                <td>${rowData.dob}</td>
                                                <td>${rowData.address}</td>
                                                <td>${rowData.category}</td>
                                                <td>${rowData.email}</td>
                                                <td>${rowData.mobile}</td>
                                            `;
                                            break;

                                        case 'Parent Details':
                                            tableHtml += `
                                                    <td>${rowData.father_name}</td>
                                                    <td>${rowData.mother_name}</td>
                                                    <td>${rowData.address}</td>
                                                    <td>${rowData.father_mobile}</td>
                                                    <td>${rowData.mother_mobile}</td>
                                                    <td>${rowData.father_occupation}</td>
                                                    <td>${rowData.mother_occupation}</td>
                                                `;
                                            break;

                                        case 'Academic Details':
                                            tableHtml += `
                                                <td>${rowData.session}</td>
                                                <td>${rowData.class}</td>
                                                <td>${rowData.section}</td>
                                                <td>${rowData.rollno}</td>
                                                <td>${rowData.gender}</td>
                                                <td>${rowData.religion}</td>
                                                <td>${rowData.admission_date}</td>
                                            `;
                                            break;
                                            // case 'Attendance':
                                            //     if (table.data && table.data.date) {
                                            //         // Set the attendance date in the header
                                            //         console.log(table.data.date);

                                            //         $('#last-attendance-date').text(table.data.date);

                                            //     } else {
                                            //         // If no date, show 'No date available' in the header and status in the body
                                            //         $('#last-attendance-date').text(
                                            //             'No date available');
                                            //     }
                                            //     break;
                                    }
                                    tableHtml += '</tr>';
                                }

                                // Insert the headers and data into appropriate tables
                                switch (table.title) {
                                    case 'Student Details':
                                        $('#st-details-body').html(headerHtml + tableHtml);
                                        break;
                                    case 'Parent Details':
                                        $('#parent-details-body').html(headerHtml + tableHtml);
                                        break;
                                    case 'Academic Details':
                                        $('#academic-details-body').html(headerHtml +
                                            tableHtml);
                                        break;
                                        // case 'Attendance':
                                        //     $('#last-attendance-date').text(attendanceHtml);
                                        //     break;
                                }
                            });
                        } else {
                            console.error('Error in API response:', response);
                        }
                    },
                    error: function(xhr) {
                        alert('Failed to retrieve data. Please try again.');
                    }
                });
            }

            // Previous Records

            function getPreviousRecords(srno) {
                $.ajax({
                    url: '<?php echo e(route('admin.reports.tcStPreviousDetails')); ?>', // The API endpoint
                    method: 'GET',
                    data: {
                        srno: srno
                    }, // Pass srno as part of the GET request
                    dataType: 'JSON',
                    success: function(response) {
                        let tblheaders = '';
                        let tblbody = '';

                        // Ensure the response is structured as expected
                        if (response.status === 'success') {
                            let headers = response.tables[0].headers;
                            let data = response.tables[0].data;

                            // Generate table headers
                            tblheaders = '<tr>';
                            $.each(headers, function(index, header) {
                                tblheaders +=
                                    `<th>${header}</th>`; // Wrap headers with <th>
                            });
                            tblheaders += '</tr>';

                            // Generate table body rows
                            $.each(data, function(index, item) {
                                tblbody += `<tr>
                                    <td>${item.session}</td>
                                    <td>${item.class}</td>
                                    <td>${item.section}</td>
                                    <td>${item.rollno}</td>
                                    <td>${item.gender}</td>
                                    <td>${item.religion}</td>
                                    <td>${item.admission_date}</td>
                                </tr>`;
                            });

                            // Populate the table in HTML
                            $('#previous-header').html(tblheaders); // Append table headers
                            $('#previous-body').html(tblbody); // Append table body
                        } else {
                            console.log('No data found for the given SRNO');
                        }
                    },
                    error: function(xhr) {
                        alert('Failed to retrieve data. Please try again.');
                    }
                });
            }

            $(document).on('click', '#edit-section-editBtn', function() {
                var prevsrno = $(this).data("id");
                var srno = $(this).data("id-srno");
                prevRecord.show();
                currentDetail.show();
                getPreviousRecords(srno);
                getStCurrentDetails(srno);
                // if (prevsrno == null) {
                //     prevsrno = srno;
                // }

                // loader.show();

                // if (prevsrno) {
                //     prevRecord.show();
                //     $.ajax({
                //         url: '<?php echo e(route('admin.getStdWithSrno')); ?>',
                //         type: 'GET',
                //         data: {
                //             srno: prevsrno
                //         },
                //         success: function(students) {
                //             let stdHtml = '';
                //             $.each(students.data, function(index, std) {
                //                 stdHtml += `<tr>
                //                     <td>${std.session_name}</td>
                //                     <td>${std.class_name}</td>
                //                     <td>${std.section_name}</td>
                //                     <td>${std.rollno}</td>
                //                     <td>${std.gender === 1 ? 'Male' : std.gender === 2 ? 'Female' : 'Others'}</td>
                //                     <td>${std.religion === 1 ? 'Hinduism' : std.religion === 2 ? 'Christianity' : 'Islam'}</td>
                //                     <td>${std.form_submit_date ?? ''}</td>
                //                 </tr>`;
                //             });
                //             $('#prev_record table tbody').html(stdHtml);
                //         },
                //         complete: function() {
                //             loader.hide();
                //         },
                //         error: function(xhr) {
                //             console.error(xhr.responseText);
                //         }
                //     });
                // } else {
                //     prevRecord.hide();

                // }

                // if (srno) {
                //     currentDetail.show();
                //     $.ajax({
                //         url: '<?php echo e(route('admin.getStdWithSrno')); ?>',
                //         type: 'GET',
                //         data: {
                //             srno: srno
                //         },
                //         success: function(students) {
                //             let std = students.data[0];
                //             let stdHtml = '';
                //             stdHtml += `<tr>
                //                     <td>${std.srno}</td>
                //                     <td>${std.student_name}</td>
                //                     <td>${std.dob}</td>
                //                     <td>${std.address}</td>
                //                     <td>${std.category === 1 ? 'General' : std.category === 2 ? 'OBC' : 'SC/ST'}</td>
                //                     <td>${std.student_email}</td>
                //                     <td>${std.student_mobile}</td>
                //                     <td>${std.f_name}</td>
                //                     <td>${std.m_name}</td>
                //                     <td>${std.parent_address}</td>
                //                     <td>${std.f_mobile ?? 'N/A'}</td>
                //                     <td>${std.m_mobile ?? 'N/A'}</td>
                //                     <td>${std.f_occupation}</td>
                //                     <td>${std.m_occupation}</td>
                //                 </tr>`;
                //             $('#current_details table tbody').html(stdHtml);
                //         },
                //         complete: function() {
                //             loader.hide();
                //         },
                //         error: function(xhr) {
                //             console.error(xhr.responseText);
                //         }
                //     });
                // } else {
                //     currentDetail.hide();
                // }
            });



        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\svps-project\resources\views/admin/reports/sr_register_report.blade.php ENDPATH**/ ?>