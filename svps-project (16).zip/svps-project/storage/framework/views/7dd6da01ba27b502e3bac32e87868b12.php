<?php $__env->startSection('sub-content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <?php echo e('Print Report Exam Wise'); ?>

                        <a href="<?php echo e(route('marks.marksheet')); ?>" class="btn btn-warning btn-sm" style="float: right;">Back</a>
                    </div>
                    <div class="card-body">
                        <form id="class-section-form">
                            <div class="row">
                                <div class="form-group col-md-4">
                                    <input type="hidden" name="current_session" value='' id="current_session">
                                    <label for="class_id" class="mt-2">Class <span class="text-danger">*</span></label>
                                    <input type="hidden" id="initialClassId"
                                        value="<?php echo e(old('initialClassId', request()->get('class_id') !== null ? request()->get('class_id') : '')); ?>">
                                    <select name="class" id="class_id"
                                        class="form-control <?php $__errorArgs = ['class'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                        <option value="">Select Class</option>
                                    </select>
                                    <?php $__errorArgs = ['class'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback form-invalid fw-bold"
                                            role="alert"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    <img src="<?php echo e(config('myconfig.myloader')); ?>" alt="Loading..." class="loader"
                                        id="loader" style="display:none; width:10%;">
                                </div>
                                <div class="form-group col-md-4">
                                    <label for="section_id" class="mt-2">Section <span
                                            class="text-danger">*</span></label>
                                    <input type="hidden" id="initialSectionId"
                                        value="<?php echo e(old('initialSectionId', request()->get('section_id') !== null ? request()->get('section_id') : '')); ?>">
                                    <select name="section" id="section_id"
                                        class="form-control <?php $__errorArgs = ['section'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                        <option value="">Select Section</option>

                                    </select>
                                    <?php $__errorArgs = ['section'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback form-invalid fw-bold"
                                            role="alert"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="form-group col-md-4">
                                    <label for="std_id" class="mt-2">Student <span class="text-danger">*</span></label>
                                    <select name="std_id" id="std_id"
                                        class="form-control <?php $__errorArgs = ['std_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                        <option value="">All Students</option>
                                    </select>
                                    <?php $__errorArgs = ['std_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback form-invalid fw-bold"
                                            role="alert"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="row">
                                <div class="form-group col-md-6">
                                    <label for="result-date-message" class="mt-2">Result Date Message <span class="text-danger">*</span></label>
                                    <input type="text" name="result_date_message" value="" id="result-date-message" class="form-control">
                                    <span class="invalid-feedback form-invalid fw-bold result-date-message-error" role="alert"></span>
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="session-start-message" class="mt-2">Session Start Message<span class="text-danger">*</span></label>
                                    <input type="text" name="session_start_message" value="" id="session-start-message" class="form-control">
                                    <span class="invalid-feedback form-invalid fw-bold session-start-message-error" role="alert"></span>
                                </div>
                            </div>
                            <div class="mt-3">
                                <button type="button" id="show-details" class="btn btn-primary">
                                    Show Details</button>
                            </div>

                        </form>
                        <div class="row">
                            <div class="marksheet-div">
                                <div class="marksheet">
                                    <div class="container mt-4 mb-4">
                                        <!-- Header -->
                                        <div class="text-center mb-4">
                                            <img src="/api/placeholder/60/60" alt="School Logo" class="rounded-circle mb-2">
                                            <h2 class="fs-2 fw-bold">St. Vivekanand Play House</h2>
                                            <p class="fs-5">(English Medium)</p>
                                            <p class="mb-1">Vivekanand Chowk, Chirawa, 01596 - 220877</p>
                                            <p class="mb-3">Session: 2024-25</p>
                                        </div>

                                        <!-- Student Details -->
                                        <div class="row mb-4">
                                            <div class="col-md-6">
                                                <div class="row mb-2">
                                                    <div class="col-5 fw-bold">Name of Student:</div>
                                                    <div class="col-7">Abhita pareek</div>
                                                </div>
                                                <div class="row mb-2">
                                                    <div class="col-5 fw-bold">Father's Name:</div>
                                                    <div class="col-7">SUNIL PAREEK</div>
                                                </div>
                                                <div class="row mb-2">
                                                    <div class="col-5 fw-bold">Class:</div>
                                                    <div class="col-7">KG</div>
                                                </div>
                                                <div class="row mb-2">
                                                    <div class="col-5 fw-bold">Section:</div>
                                                    <div class="col-7">Daisy</div>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="row mb-2">
                                                    <div class="col-5 fw-bold">S.R.No.:</div>
                                                    <div class="col-7">2806</div>
                                                </div>
                                                <div class="row mb-2">
                                                    <div class="col-5 fw-bold">Date of Birth:</div>
                                                    <div class="col-7">12-Apr-2019</div>
                                                </div>
                                                <div class="row mb-2">
                                                    <div class="col-5 fw-bold">Roll No.:</div>
                                                    <div class="col-7">1</div>
                                                </div>
                                            </div>
                                        </div>

                                        <!-- Academic Performance -->
                                        <div class="table-responsive mb-4">
                                            <table class="table table-bordered">
                                                <thead>
                                                    <tr class="table-light">
                                                        <th rowspan="2">Subject</th>
                                                        <th colspan="2">First Terminal Examination</th>
                                                        <th colspan="2">Second Terminal Examination</th>
                                                        <th colspan="2">Final Examination</th>
                                                        <th colspan="2">Grand Total</th>
                                                        <th rowspan="2">Attendance</th>
                                                    </tr>
                                                    <tr class="table-light">
                                                        <th>MM.</th>
                                                        <th>M. Obtd.</th>
                                                        <th>MM.</th>
                                                        <th>M. Obtd.</th>
                                                        <th>MM.</th>
                                                        <th>M. Obtd.</th>
                                                        <th>MM.</th>
                                                        <th>M. Obtd.</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr>
                                                        <td>English</td>
                                                        <td>50</td>
                                                        <td>50</td>
                                                        <td>50</td>
                                                        <td>50</td>
                                                        <td></td>
                                                        <td></td>
                                                        <td></td>
                                                        <td></td>
                                                        <td rowspan="4">3166</td>
                                                    </tr>
                                                    <tr>
                                                        <td>Mathematics</td>
                                                        <td>50</td>
                                                        <td>50</td>
                                                        <td>50</td>
                                                        <td>50</td>
                                                        <td></td>
                                                        <td></td>
                                                        <td></td>
                                                        <td></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Hindi</td>
                                                        <td>50</td>
                                                        <td>50</td>
                                                        <td>50</td>
                                                        <td>50</td>
                                                        <td></td>
                                                        <td></td>
                                                        <td></td>
                                                        <td></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Total</td>
                                                        <td>150</td>
                                                        <td>150</td>
                                                        <td>150</td>
                                                        <td>150</td>
                                                        <td></td>
                                                        <td></td>
                                                        <td></td>
                                                        <td></td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>

                                        <!-- Grades -->
                                        <div class="table-responsive mb-4">
                                            <table class="table table-bordered">
                                                <thead>
                                                    <tr class="table-light">
                                                        <th>Subject</th>
                                                        <th>First Terminal</th>
                                                        <th>Second Terminal</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr>
                                                        <td>General Knowledge</td>
                                                        <td>A+</td>
                                                        <td>A+</td>
                                                    </tr>
                                                    <tr>
                                                        <td>Drawing</td>
                                                        <td>A+</td>
                                                        <td>A+</td>
                                                    </tr>
                                                    <tr>
                                                        <td>Recitation</td>
                                                        <td>A+</td>
                                                        <td>A+</td>
                                                    </tr>
                                                    <tr>
                                                        <td>English Conversation</td>
                                                        <td>A+</td>
                                                        <td>A+</td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>

                                        <!-- Result Summary -->
                                        <div class="row mb-4">
                                            <div class="col-md-4 text-center">
                                                <p class="fw-bold mb-1">Percentage</p>
                                                <p>100</p>
                                            </div>
                                            <div class="col-md-4 text-center">
                                                <p class="fw-bold mb-1">Result</p>
                                                <p>Pass</p>
                                            </div>
                                        </div>

                                        <!-- Signatures -->
                                        <div class="row mt-5">
                                            <div class="col-md-4 text-center">
                                                <hr class="w-75 mx-auto">
                                                <p>Sign of Class Teacher</p>
                                            </div>
                                            <div class="col-md-4 text-center">
                                                <hr class="w-75 mx-auto">
                                                <p>Sign of Checker</p>
                                            </div>
                                            <div class="col-md-4 text-center">
                                                <hr class="w-75 mx-auto">
                                                <p>Sign of Principal</p>
                                            </div>
                                        </div>
                                </div>
                                <div class="mt-3">
                                    <button type="button" id="print-marksheet" class="btn btn-primary">Print
                                        Marksheet</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('marks-scripts'); ?>
    <script>
        $(document).ready(function() {
            let initialClassId = $('#initialClassId').val();
            let initialSectionId = $('#initialSectionId').val();
            getClassSection(initialClassId, initialSectionId);
            getStd();
            // marksheetPrint();
            // $('#class_id, #section_id, #exam_id, #std_id').change(function() {
            //     let marksheetDiv = $('.marksheet-div');
            //     marksheetDiv.hide();
            // });

        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('marks.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\svps-project\resources\views/marks/marksheet/marksheet_final_kg.blade.php ENDPATH**/ ?>