<div class="container">
    <div class="flex">
        <div class="align-center">
            <a href="<?php echo e(route('admin.login')); ?>" class="ml-5 fs-1"
                style="font-size: -webkit-xxx-large;
            margin: 150px;"><img src="<?php echo e(config('myconfig.admin')); ?>"
                    alt="Admin"></a>
            <a href="<?php echo e(route('fee.login')); ?>" class="ml-5fs-1"
                style="font-size: -webkit-xxx-large;
            margin: 150px;"><img src="<?php echo e(config('myconfig.fee')); ?>"
                    alt="Fee"></a>
            <a href="<?php echo e(route('student.login')); ?>" class="ml-5 fs-1"
                style="font-size: -webkit-xxx-large;
            margin: 150px;"><img
                    src="<?php echo e(config('myconfig.student')); ?>" alt="Std"></a>
            <a href="<?php echo e(route('marks.login')); ?>" class="ml-5 fs-1"
                style="font-size: -webkit-xxx-large;
            margin: 150px;"><img
                    src="<?php echo e(config('myconfig.marks')); ?>" alt="Marks"></a>
            <a href="<?php echo e(route('inventory.login')); ?>" class="ml-5 fs-1"
                style="font-size: -webkit-xxx-large;
            margin: 150px;"><img
                    src="<?php echo e(config('myconfig.inventory')); ?>" alt="Inventory"></a>
        </div>
    </div>
</div>


<script>
    window.onload = function() {
        // Try to clear the browser cache using JavaScript (browser specific)
        if ('caches' in window) {
            caches.keys().then(function(cacheNames) {
                cacheNames.forEach(function(cacheName) {
                    caches.delete(cacheName);
                });
            });
        }
    };
</script>
<?php /**PATH C:\xampp\htdocs\svps-project\resources\views/index.blade.php ENDPATH**/ ?>