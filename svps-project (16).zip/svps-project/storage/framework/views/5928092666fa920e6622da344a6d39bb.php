<?php $__env->startSection('sub-content'); ?>
    <div class="container">

        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card">
                        <div class="card-header">
                            <?php echo e(isset($subject) && isset($subject->id) ? 'Edit Subject Group' : 'Create New Subject Group'); ?>

                            <a href="<?php echo e(route('admin.subject-group-master.index')); ?>" class="btn btn-warning btn-sm"
                                    style="float: right;">Back</a>
                        </div>

                        <div class="card-body">
                            <form action="<?php echo e(route('admin.subject-group-master.store')); ?>" method="POST"
                                enctype="multipart/form-data" id="basic-form">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="id" id="id"
                                    value="<?php echo e(isset($subject) ? $subject->id : ''); ?>">

                                <div class="row">
                                    <div class="form-group col-md-6">
                                        <label for="class_id" class="mt-2">Class <span
                                                class="text-danger">*</span></label>
                                        <input type="hidden" id="initialClassId"
                                            value="<?php echo e(isset($subject) ? $subject->class_id : ''); ?>">
                                        <select name="class_id" id="class_id"
                                            class="form-control" required>
                                            <option value="">Select Class</option>

                                        </select>
                                    </div>
                                    <div class="form-group col-md-6">
                                        <input type="hidden" name="subjectGroup_controller" id="subjectGroup-controller" value="SubjectGroupSection">
                                        <label for="subject_id" class="mt-2">Subject <span
                                                class="text-danger">*</span></label>
                                        <input type="hidden" id="initialClassId"
                                            value="<?php echo e(isset($subject) ? $subject->subject_id : ''); ?>">
                                        <select name="subject_id" id="subject_id"
                                            class="form-control" required>
                                            <option value="">Select Subject</option>

                                        </select>
                                    </div>
                                    <img src="<?php echo e(config('myconfig.myloader')); ?>" alt="Loading..." class="loader"
                                        id="loader" style="display:none; width:10%;">
                                </div>

                                <div class="row">
                                    <div class="form-group col-md-6">
                                        <label for="subject" class="mt-2">Enter Sub Subject Name <span
                                                class="text-danger">*</span></label>
                                        <input type="text" name="subject"
                                            class="form-control <?php $__errorArgs = ['subject'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            placeholder="Sub Subject"
                                            value="<?php echo e(old('subject', isset($subject) ? $subject->subject : '')); ?>" id="subject" required>
                                        <?php $__errorArgs = ['subject'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback form-invalid fw-bold" role="alert">
                                                <?php echo e($message); ?>

                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="form-group col-md-6">
                                        <label for="priority" class="mt-2">Enter Display Priority <span
                                                class="text-danger">*</span></label>
                                        <input type="text" name="priority"
                                            class="form-control <?php $__errorArgs = ['priority'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            placeholder="Priority"
                                            value="<?php echo e(old('priority', isset($subject) ? $subject->priority : '')); ?>" id="priority" required>
                                        <?php $__errorArgs = ['priority'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback form-invalid fw-bold" role="alert">
                                                <?php echo e($message); ?>

                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="form-group form-check col-md-6">
                                        <div class="form-check">
                                            <input class="form-check-input <?php $__errorArgs = ['by_m_g'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="1" type="radio" name="by_m_g"
                                                id="by_marks"
                                                <?php echo e(old('by_m_g', isset($subject) && $subject->by_m_g == 1 ? 'checked=' . '"' . 'checked' . '"' : '')); ?>>
                                            <label class="form-check-label" for="by_marks">
                                                Result By Marks
                                            </label>
                                        </div>
                                    </div>
                                    <div class="form-group form-check col-md-6">
                                        <div class="form-check">
                                            <input class="form-check-input <?php $__errorArgs = ['by_m_g'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="2" type="radio" name="by_m_g"
                                                id="by_grade"
                                                <?php echo e(old('by_m_g', isset($subject) && $subject->by_m_g == 2 ? 'checked=' . '"' . 'checked' . '"' : '')); ?>>
                                            <label class="form-check-label" for="by_grade">
                                                Result By Grade
                                            </label>
                                        </div>
                                    </div>
                                    <?php $__errorArgs = ['by_m_g'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback form-invalid fw-bold" role="alert">
                                                <?php echo e($message); ?>

                                            </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="mt-3">
                                    <input class="btn btn-primary" type="submit"
                                        value="<?php echo e(isset($subject) && isset($subject->id) ? 'Update' : 'Save'); ?>">
                                </div>
                            </form>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('admin-scripts'); ?>
    <script>
        var initialClassId = '<?php echo e(old('class_id', isset($subject) ? $subject->class_id : '')); ?>';
        getClassSection(initialClassId);
        var initialSubjectId = '<?php echo e(old('subject_id', isset($subject) ? $subject->subject_id : '')); ?>';
        getClassSubject(initialClassId,initialSubjectId,$('#subjectGroup-controller'));
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\svps-project\resources\views/admin/subject_group/create.blade.php ENDPATH**/ ?>