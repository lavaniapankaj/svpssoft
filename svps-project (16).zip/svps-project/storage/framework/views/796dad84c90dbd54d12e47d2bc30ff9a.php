<?php $__env->startSection('sub-content'); ?>
    <div class="container">
        <?php if(Session::has('success')): ?>
            <?php $__env->startSection('scripts'); ?>
                <script>
                    swal("Good job!", "<?php echo e(Session::get('success')); ?>", "success").then(() => {
                        $('#std-form').hide();
                        location.reload();
                    });
                </script>
            <?php $__env->stopSection(); ?>
        <?php endif; ?>
        <?php if(Session::has('error')): ?>
            <?php $__env->startSection('scripts'); ?>
                <script>
                    swal("Oops...", "<?php echo e(Session::get('error')); ?>", "error");
                </script>
            <?php $__env->stopSection(); ?>
        <?php endif; ?>
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">
                        <?php echo e('Set New Roll No. and Section'); ?>

                        <a href="<?php echo e(route('admin.editSection.index')); ?>" class="btn btn-warning btn-sm"
                            style="float: right;">Back</a>

                    </div>
                    <div class="card-body">
                        <form id="class-section-form">
                            <div class="row">
                                <div class="form-group col-md-6">
                                    <label for="class_id" class="mt-2">Class <span class="text-danger">*</span></label>
                                    <input type="hidden" id="initialClassId" value="<?php echo e(old('initialClassId',request()->get('class_id') !== null ? request()->get('class_id') : '')); ?>">
                                    <select name="class" id="class_id"
                                        class="form-control <?php $__errorArgs = ['class'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                        <option value="">Select Class</option>

                                    </select>
                                    <?php $__errorArgs = ['class'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback form-invalid fw-bold"
                                            role="alert"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    <img src="<?php echo e(config('myconfig.myloader')); ?>" alt="Loading..." class="loader"
                                        id="loader" style="display:none; width:10%;">
                                </div>


                                <div class="form-group col-md-6">
                                    <label for="section_id" class="mt-2">Section <span
                                            class="text-danger">*</span></label>
                                    <input type="hidden" id="initialSectionId" value="<?php echo e(old('initialSectionId',request()->get('section_id') !== null ? request()->get('section_id') : '')); ?>">
                                    <select name="section" id="section_id"
                                        class="form-control <?php $__errorArgs = ['section'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                        <option value="">Select Section</option>

                                    </select>
                                    <?php $__errorArgs = ['section'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback form-invalid fw-bold"
                                            role="alert"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>


                            <div class="mt-3">
                                <button type="button" id="show-details" class="btn btn-primary">
                                    Show Details</button>
                            </div>

                        </form>
                        

                        <div id="std-container" class="mt-4">
                            <form action="<?php echo e(route('admin.editSection.editStdRollSection.store')); ?>" method="POST"
                                enctype="multipart/form-data" id="std-form">
                                <?php echo csrf_field(); ?>
                                <table class="table table-responsible">
                                    <input type="hidden" name="current_session" value='' id="current_session">

                                    <thead>
                                        <tr>
                                            <th>Name</th>
                                            <th>New Roll No.</th>
                                            <th>Select for Section</th>
                                        </tr>
                                    </thead>
                                    <tbody>

                                    </tbody>
                                </table>
                                <div class="row">

                                    <div class="form-group col-md-6" id="update-section-container">
                                        <label for="section_id2" class="mt-2">Section <span
                                                class="text-danger">*</span></label>
                                        <input type="hidden" id="initialSectionId" value="<?php echo e($student->section ?? ''); ?>">
                                        
                                        <?php $__errorArgs = ['sectionSecond'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback form-invalid fw-bold"
                                                role="alert"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="mt-3">
                                        <button type="submit" class="btn btn-primary"
                                            id="section-updateBtn">Update</button>
                                        <span id="error" class="invalid-feedback form-invalid fw-bold">Select at least
                                            one Student for Section Change</span>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('admin-scripts'); ?>
    <script>
        var initialClassId = '<?php echo e(old('initialClassId',request()->get('class_id') !== null ? request()->get('class_id') : '')); ?>';
        var initialSectionId = '<?php echo e(old('initialClassId',request()->get('section_id') !== null ? request()->get('section_id') : '')); ?>';
        getClassSection(initialClassId, initialSectionId);

        $(document).ready(function() {
            $('#std-form').hide();
            $('#error').hide();
            var loader = $('#loader');

            $('#show-details').on('click', function() {
                const classId = $('#class_id').val();
                const sectionId = $('#section_id').val();
                const sessionId = $('#current_session').val();
                loader.show();
                $('#class-section-form').validate();

                const previousFormData = $('#std-form').find('input, select').serialize();

                if (classId && sectionId && sessionId) {
                    $('#std-form').show();
                    $.ajax({
                        url: '<?php echo e(route('stdNameFather.get')); ?>',
                        type: 'GET',
                        dataType: 'JSON',
                        data: {
                            class_id: classId,
                            section_id: sectionId,
                            session_id: sessionId,
                        },
                        success: function(students) {
                            let stdHtml = '';
                            $.each(students, function(index, std) {
                                stdHtml += `<tr>
                                            <td>${std.student_name}</td>
                                            <td>
                                                <input type="hidden" name="students[${index}][srno]" value="${std.srno}" class="std-srno" id="std-srno" data-index="${index}">
                                                <input type="text" name="students[${index}][rollno]" value='${std.rollno}' class="form-control <?php $__errorArgs = ['students[${index}][rollno]'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> std-rollno" data-index="${index}">
                                                    <span class="invalid-feedback form-invalid fw-bold error" id="roll-error" role="alert">
                                                    </span>
                                                <?php $__errorArgs = ['students[${index}][rollno]'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="invalid-feedback form-invalid fw-bold roll-error error" role="alert">
                                                        <?php echo e(meaasge); ?>

                                                    </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </td>
                                            <td>
                                                <input type="checkbox" name="students[${index}][sectionCheck]" value="1" class="section-checkbox" data-index="${index}">
                                                <input type="hidden" name="students[${index}][sectionSecond]" value="" class="section-hidden" data-index="${index}">
                                            </td>
                                            </tr>`;
                            });
                            if (stdHtml === '') {
                                stdHtml =
                                    '<tr><td colspan="3">No Student found</td></tr>';
                            }
                            $('#std-container table tbody').html(stdHtml);
                        },
                        complete: function() {
                            loader.hide();
                        },
                        error: function(xhr) {
                            console.error(xhr.responseText);

                        }
                    });
                }
                $('#update-section-container').find("select").remove();
                var ddl = $("#section_id").clone();
                ddl.attr("name", "sectionSecond");
                ddl.attr("id", "section_id2");
                const selectedValue = $("#section_id").val();
                ddl.find("option").each(function() {
                    if ($(this).val() == selectedValue) {
                        $(this).prop("selected", true);
                    } else {
                        $(this).prop("selected", false);
                    }
                });
                $("#update-section-container").append(ddl);
                $('#std-container').on('change', '.section-checkbox', function(event) {
                    if ($(this).is(':checked') && $('#section_id2').val() == '') {
                        // $(this).val('1');
                        $('#error').show();
                        $('#error').text('Select Section');
                        event.preventDefault();

                    } else {
                        $('#error').hide();
                    }
                    if ($(this).is(':checked')) {
                        const sectionSecondValue = $('#section_id2').prop("selected", true).val();
                        $('section-hidden').val(sectionSecondValue);
                    }
                });
                $('#section_id2').on('change', function(event) {
                    const selectedSectionId = $(this).val();
                    $('.section-checkbox').each(function() {
                        const index = $(this).data('index');
                        $(`input[name="students[${index}][sectionSecond]"]`).val(
                            selectedSectionId);
                    });

                });
                $('#std-container').on('input', '.std-rollno', function(event) {
                    if (!(/^\d+$/.test($(this).val()))) {
                        event.preventDefault();
                        $(this).siblings('#roll-error').show().text('Only Numbers are allowed.');
                    } else {
                        $(this).siblings('#roll-error').hide();
                    }
                });


                $('#std-container').on('submit', function(event) {
                    if ($('#error').is(':visible') || $('#roll-error').is(':visible')) {
                        event.preventDefault();
                    } else {
                        location.reload(true);
                    }

                });
            });

        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\svps-project\resources\views/admin/editSections/std_set_section_rollno.blade.php ENDPATH**/ ?>